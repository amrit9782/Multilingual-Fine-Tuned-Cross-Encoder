import os
import pandas as pd
import torch
from transformers import AutoConfig, AutoTokenizer, AutoModelForSequenceClassification, TrainingArguments
from datasets import Dataset
from comparison.investigation_v9 import (
    load_data, oversample_minority, tokenize_dynamic, WeightedCORALTrainer,
    get_optimizer_grouped_parameters, metrics_regression, unfreeze_top_layers,
    MODELS
)

# ── Configuration (Update these with your best grid search values) ─────────────
MODEL_KEY = "xlm-roberta-base"        # "xlm-roberta-base" or "mdeberta-v3-base"
LR = 1e-5                             # Best learning rate (e.g. 3e-5 with FGM, or 1e-5 without FGM)
UNFREEZE_LAYERS = 10                  # Best number of top layers to unfreeze
LAYOUT_COLS = ["rubric", "answer"]    # Best layout columns (e.g. ["rubric", "answer"])
EPOCHS = 6                            # Average epoch where early stopping converged
USE_FGM = False                       # Set to True to enable FGM (best accuracy), or False (lowest RMSE)

# Best optimized decision thresholds from the optimal run
T1 = 0.25
T2 = 0.75

def main():
    # 1. Load full dataset
    df = load_data()
    train_df_balanced = oversample_minority(df)

    # 2. Set up model & tokenizer
    model_name = MODELS[MODEL_KEY]
    config = AutoConfig.from_pretrained(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name, config=config)

    def make_ds(dataframe):
        dataframe["labels"] = dataframe["target_score"].astype(float)
        ds = Dataset.from_pandas(dataframe[LAYOUT_COLS + ["labels"]].reset_index(drop=True))
        ds = ds.map(lambda b: tokenize_dynamic(b, tokenizer, LAYOUT_COLS), batched=True)
        return ds.remove_columns(LAYOUT_COLS)

    train_ds = make_ds(train_df_balanced)

    # 3. Load model for sequence classification
    config.num_labels = 2
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, config=config, ignore_mismatched_sizes=True
    )
    unfreeze_top_layers(model, num_layers_to_unfreeze=UNFREEZE_LAYERS, unfreeze_embeddings=USE_FGM)

    out_dir = "/tmp/final_model_train"

    # 4. Training Arguments
    args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=LR,
        per_device_train_batch_size=8,
        gradient_accumulation_steps=2,
        num_train_epochs=EPOCHS,
        weight_decay=0.01,
        save_strategy="no",
        report_to="none",
        bf16=torch.cuda.is_bf16_supported() and torch.cuda.is_available(),
        max_grad_norm=1.0,
    )

    # 5. Trainer
    trainer = WeightedCORALTrainer(
        model=model, 
        args=args, 
        train_dataset=train_ds, 
        processing_class=tokenizer,
        fgm_epsilon=0.5 if USE_FGM else 0.0,
        fgm_emb_name="embeddings.word_embeddings"
    )
    
    print(f"\n>>> Starting final training on full dataset (epochs={EPOCHS}, lr={LR}, unfreeze={UNFREEZE_LAYERS})...")
    trainer.train()

    # 6. Save model directly into the app folder for Docker packaging
    save_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "app/best_model"))
    os.makedirs(save_path, exist_ok=True)
    model.save_pretrained(save_path)
    tokenizer.save_pretrained(save_path)
    
    # Save optimized thresholds as metadata file in best_model folder
    with open(os.path.join(save_path, "thresholds.txt"), "w") as f:
        f.write(f"T1={T1}\nT2={T2}\nLAYOUT={','.join(LAYOUT_COLS)}")
        
    print(f"\n>>> Final model successfully saved to {save_path}")
    
    # Cleanup tmp directory
    import shutil
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)

if __name__ == "__main__":
    main()
