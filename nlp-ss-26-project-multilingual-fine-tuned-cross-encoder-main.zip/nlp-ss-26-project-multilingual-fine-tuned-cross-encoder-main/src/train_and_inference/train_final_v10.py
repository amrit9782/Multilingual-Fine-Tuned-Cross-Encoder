"""
train_final.py - Train the production model on ALL data (no validation split).

Uses the v10 full_config settings (the best result from the entire project):
  - xlm-roberta-large
  - CORAL ordinal loss + LLRD + FGM adversarial training
  - LR=5e-5, unfreeze=8, 10 epochs (TB shows overfitting after epoch 10)
  - [rubric, question, answer] field ordering
  - is_ternary prefix on rubric text
  - Oversampling + WeightedCORAL loss

After training, uploads the model to HuggingFace Hub for the Docker grader.

Usage on the cluster:
    source venv/bin/activate
    python train_final.py --data_dir ./data --hf_token hf_xxx --repo_id your-user/asag-model

    # Or train only (upload later):
    python train_final.py --data_dir ./data --save_dir ./final_model
"""

import os
import sys
import random
import html
import re
import gc
import json
import time
import shutil
import argparse
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.utils import resample
from datasets import Dataset
from transformers import (
    AutoConfig,
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    DataCollatorWithPadding,
    get_linear_schedule_with_warmup,
)

# =============================================================================
# CONFIG - v10 full_config (best result from entire project)
# =============================================================================
MODEL_NAME  = "FacebookAI/xlm-roberta-large"
FIELD_COLS  = ["rubric", "question", "answer"]
LR          = 5e-5
UNFREEZE    = 8
EPOCHS      = 10          # TB curves show best val loss at epoch 8-10, overfitting after
BATCH_SIZE  = 2           # large model VRAM constraint
GRAD_ACCUM  = 8           # effective batch = 16
FGM_EPSILON = 0.5
LR_DECAY    = 0.88        # LLRD decay factor
SEED        = 42

# Type-aware thresholds from v10 cross-validation
# Update these with the actual optimized values from your v10 run
BINARY_THRESHOLD = 0.30
TERNARY_T1       = 0.20
TERNARY_T2       = 0.65

SCORE_COL     = "target_score"
ANSWER_ID_COL = "answer_id"
ALL_TEXT_COLS  = ["rubric", "answer", "solution", "question"]

CLASS_WEIGHTS = {}


def set_seed(s):
    """Set all random seeds for reproducibility."""
    random.seed(s); np.random.seed(s); torch.manual_seed(s)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(s)


# =============================================================================
# DATA LOADING
# =============================================================================
def normalize_text(text):
    """Clean text: unescape HTML, remove markdown, collapse whitespace."""
    if pd.isna(text): return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###","").replace("##","").replace("#","")
    text = text.replace("\n"," ").replace("\r"," ")
    return " ".join(text.strip().split())


def load_data(data_dir):
    """Load all 4 datasets, normalize, add is_ternary prefix, compute class weights."""
    global CLASS_WEIGHTS
    datasets = ["WuS-WS25", "DAV-SS2425", "NLP-SS2425", "WuS-SS24"]
    dfs = []

    print("\n>>> Loading datasets...")
    for name in datasets:
        path = os.path.join(data_dir, name)
        if not os.path.exists(path):
            print(f"  WARNING: {path} not found, skipping")
            continue
        q  = pd.read_csv(os.path.join(path, "questions.csv"))
        a  = pd.read_csv(os.path.join(path, "answers.csv"))
        r  = pd.read_csv(os.path.join(path, "rubrics.csv"))
        ar = pd.read_csv(os.path.join(path, "answer_rubrics.csv"))

        prefix = f"{name}_"
        for frame in [q, a, r, ar]:
            for id_col in ["question_id", "answer_id", "rubric_id"]:
                if id_col in frame.columns:
                    frame[id_col] = prefix + frame[id_col].astype(str)

        a = a.rename(columns={"score": "answer_total_score"})
        r = r.rename(columns={"score": "rubric_score"})
        if "is_ternary" not in r.columns:
            r["is_ternary"] = True

        merged = ar.merge(
            a[["question_id","answer_id","answer","answer_total_score"]],
            on=["question_id","answer_id"], how="left"
        ).merge(
            r[["question_id","rubric_id","rubric","rubric_score","is_ternary"]],
            on=["question_id","rubric_id"], how="left"
        ).merge(
            q[["question_id","question","solution","max_score"]],
            on="question_id", how="left"
        )
        merged["target_score"] = merged["label"].astype(float) * merged["rubric_score"]
        print(f"  {name}: {len(merged)} rows")
        dfs.append(merged)

    df = pd.concat(dfs, ignore_index=True)
    for col in ALL_TEXT_COLS:
        df[col] = df[col].apply(normalize_text)

    # is_ternary prefix (Jannen improvement)
    df["rubric"] = df.apply(
        lambda row: ("ternary: " if row["is_ternary"] else "binary: ") + row["rubric"],
        axis=1
    )

    total = len(df)
    counts = df[SCORE_COL].value_counts().to_dict()
    CLASS_WEIGHTS = {s: total / counts.get(s, 1.0) for s in [0.0, 0.5, 1.0]}
    print(f"  Combined: {total} rows, {df[ANSWER_ID_COL].nunique()} answers")
    print(f"  Class weights: {CLASS_WEIGHTS}")
    return df


def oversample_minority(df):
    """Oversample minority classes to match the largest class."""
    classes = [df[(df[SCORE_COL] - s).abs() < 0.01] for s in [0.0, 0.5, 1.0]]
    max_size = max(len(c) for c in classes)
    balanced = pd.concat([
        resample(c, replace=True, n_samples=max_size, random_state=SEED)
        if len(c) < max_size else c for c in classes
    ])
    balanced = balanced.sample(frac=1, random_state=SEED).reset_index(drop=True)
    print(f"  [Oversampling] {len(df)} -> {len(balanced)} samples")
    return balanced


# =============================================================================
# TOKENIZATION
# =============================================================================
def tokenize_dynamic(batch, tokenizer, field_cols, max_length=512):
    """Dynamic budget tokenization: rubric never truncated, answer truncated first."""
    all_ids, all_masks = [], []
    special_count = len(field_cols) + 1
    for i in range(len(batch[field_cols[0]])):
        encoded = {col: tokenizer.encode(batch[col][i], add_special_tokens=False) for col in field_cols}
        total = sum(len(v) for v in encoded.values()) + special_count
        if total > max_length:
            budget = max_length - special_count
            rubric_len = len(encoded.get("rubric", []))
            question_len = len(encoded.get("question", []))
            if "answer" in encoded:
                answer_budget = max(80, budget - rubric_len - question_len)
                encoded["answer"] = encoded["answer"][:answer_budget]
            new_total = sum(len(v) for v in encoded.values()) + special_count
            if new_total > max_length and "question" in encoded:
                used = rubric_len + len(encoded["answer"])
                encoded["question"] = encoded["question"][:max(30, budget - used)]

        ids = [tokenizer.cls_token_id]
        for col in field_cols:
            ids += encoded[col] + [tokenizer.sep_token_id]
        all_ids.append(ids)
        all_masks.append([1] * len(ids))
    return {"input_ids": all_ids, "attention_mask": all_masks}


# =============================================================================
# FGM + CORAL TRAINER
# =============================================================================
class FGM:
    """Fast Gradient Method adversarial perturbation."""
    def __init__(self, model, epsilon=0.5, emb_name="word_embeddings"):
        self.model, self.epsilon, self.emb_name = model, epsilon, emb_name
        self.backup = {}

    def attack(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad and self.emb_name in name:
                self.backup[name] = param.data.clone()
                norm = torch.norm(param.grad)
                if norm != 0 and not torch.isnan(norm):
                    param.data.add_(self.epsilon * param.grad / norm)

    def restore(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad and self.emb_name in name:
                param.data.copy_(self.backup[name])
        self.backup = {}


class WeightedCORALTrainer(Trainer):
    """CORAL ordinal loss + FGM adversarial training."""
    def __init__(self, *args, fgm_epsilon=0.0, fgm_emb_name="word_embeddings", **kwargs):
        super().__init__(*args, **kwargs)
        self.fgm_epsilon = fgm_epsilon
        self.fgm_emb_name = fgm_emb_name

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        inputs_copy = dict(inputs)
        labels = inputs_copy.pop("labels")
        outputs = model(**inputs_copy)
        logits = outputs.logits
        y1 = (labels >= 0.5).float()
        y2 = (labels >= 1.0).float()
        targets = torch.stack([y1, y2], dim=-1)
        bce = nn.BCEWithLogitsLoss(reduction="none")
        loss = bce(logits, targets)
        weights = torch.ones_like(labels)
        for sv, w in CLASS_WEIGHTS.items():
            weights[(labels - sv).abs() < 0.01] = w
        loss = (loss.sum(dim=-1) * weights).mean()
        return (loss, outputs) if return_outputs else loss

    def training_step(self, model, inputs, *args, **kwargs):
        model.train()
        inputs = self._prepare_inputs(inputs)
        loss = self.compute_loss(model, inputs)
        if self.args.gradient_accumulation_steps > 1:
            loss = loss / self.args.gradient_accumulation_steps
        self.accelerator.backward(loss)
        if self.fgm_epsilon > 0:
            fgm = FGM(model, self.fgm_epsilon, self.fgm_emb_name)
            fgm.attack()
            loss_adv = self.compute_loss(model, inputs)
            if self.args.gradient_accumulation_steps > 1:
                loss_adv = loss_adv / self.args.gradient_accumulation_steps
            self.accelerator.backward(loss_adv)
            fgm.restore()
        return loss.detach()


# =============================================================================
# LLRD + UNFREEZING
# =============================================================================
def get_llrd_param_groups(model, base_lr, lr_decay=0.88):
    """Layer-wise discriminative learning rates."""
    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_layer = max(
        (int(m.group(1)) for n, _ in model.named_parameters()
         for m in [layer_pattern.search(n)] if m), default=-1
    )
    groups = []
    head_params = [p for n, p in model.named_parameters()
                   if p.requires_grad and any(h in n for h in ["classifier","score","pooler"])]
    if head_params:
        groups.append({"params": head_params, "lr": base_lr, "weight_decay": 0.01})
    for idx in range(max_layer, -1, -1):
        layer_lr = base_lr * (lr_decay ** (max_layer - idx))
        lp = [p for n, p in model.named_parameters()
              if p.requires_grad and f"layer.{idx}." in n
              and not any(h in n for h in ["classifier","score","pooler"])]
        if lp:
            groups.append({"params": lp, "lr": layer_lr, "weight_decay": 0.01})
    base_params = [p for n, p in model.named_parameters()
                   if p.requires_grad and not layer_pattern.search(n)
                   and not any(h in n for h in ["classifier","score","pooler"])]
    if base_params:
        groups.append({"params": base_params, "lr": base_lr * (lr_decay ** (max_layer+1)), "weight_decay": 0.01})
    return groups


def unfreeze_top_layers(model, num_layers):
    """Freeze all, then unfreeze top N encoder layers + head."""
    for param in model.parameters():
        param.requires_grad = False
    for name, module in model.named_modules():
        if any(h in name for h in ["classifier","score","pooler"]):
            for param in module.parameters():
                param.requires_grad = True
    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_idx = max((int(m.group(1)) for n, _ in model.named_parameters()
                   for m in [layer_pattern.search(n)] if m), default=-1)
    if max_idx != -1:
        start = max(0, max_idx - num_layers + 1)
        for name, param in model.named_parameters():
            m = layer_pattern.search(name)
            if m and int(m.group(1)) >= start:
                param.requires_grad = True
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  [Params] {trainable:,} / {total:,} ({100*trainable/total:.1f}%)")


# =============================================================================
# MAIN
# =============================================================================
def main():
    parser = argparse.ArgumentParser(description="Train final production model")
    parser.add_argument("--data_dir", type=str, required=True)
    parser.add_argument("--save_dir", type=str, default="./final_model")
    parser.add_argument("--hf_token", type=str, default=None, help="HF write token to upload model")
    parser.add_argument("--repo_id", type=str, default=None, help="HF repo ID for upload")
    args = parser.parse_args()

    set_seed(SEED)
    t0 = time.time()
    print(f"GPU: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")

    # Load ALL data (no validation split for final training)
    df = load_data(args.data_dir)
    train_balanced = oversample_minority(df)

    # Tokenize
    hf_config = AutoConfig.from_pretrained(MODEL_NAME)
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, config=hf_config)

    def make_ds(dataframe):
        d = dataframe.copy()
        d["labels"] = d[SCORE_COL].astype(float)
        ds = Dataset.from_pandas(d[list(FIELD_COLS) + ["labels"]].reset_index(drop=True))
        ds = ds.map(lambda b: tokenize_dynamic(b, tokenizer, FIELD_COLS), batched=True)
        return ds.remove_columns(list(FIELD_COLS))

    train_ds = make_ds(train_balanced)

    # Model
    hf_config.num_labels = 2  # CORAL: 2 logits
    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_NAME, config=hf_config, ignore_mismatched_sizes=True, torch_dtype=torch.float32
    )
    if hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable()
    unfreeze_top_layers(model, UNFREEZE)

    # Optimizer with LLRD
    total_steps = int(EPOCHS * len(train_ds) / (BATCH_SIZE * GRAD_ACCUM))
    param_groups = get_llrd_param_groups(model, base_lr=LR, lr_decay=LR_DECAY)
    optimizer = torch.optim.AdamW(param_groups)
    scheduler = get_linear_schedule_with_warmup(optimizer, int(total_steps * 0.1), total_steps)

    out_dir = "/tmp/final_train"

    training_args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=LR,
        per_device_train_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM,
        num_train_epochs=EPOCHS,
        weight_decay=0.01,
        save_strategy="no",
        logging_steps=20,
        report_to="none",
        seed=SEED,
        bf16=torch.cuda.is_available() and torch.cuda.is_bf16_supported(),
        fp16=not torch.cuda.is_bf16_supported() and torch.cuda.is_available(),
        max_grad_norm=1.0,
    )

    trainer = WeightedCORALTrainer(
        model=model, args=training_args,
        train_dataset=train_ds,
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        optimizers=(optimizer, scheduler),
        fgm_epsilon=FGM_EPSILON,
        fgm_emb_name="embeddings.word_embeddings",
    )

    print(f"\n>>> Training on FULL dataset ({len(df)} rows, {len(train_balanced)} after oversampling)")
    print(f">>> Config: {MODEL_NAME}, LR={LR}, unfreeze={UNFREEZE}, epochs={EPOCHS}")
    print(f">>> CORAL + LLRD (decay={LR_DECAY}) + FGM (eps={FGM_EPSILON})")
    trainer.train()

    # Save model
    os.makedirs(args.save_dir, exist_ok=True)
    model.save_pretrained(args.save_dir)
    tokenizer.save_pretrained(args.save_dir)

    # Save thresholds
    thresholds = {
        "binary_threshold": BINARY_THRESHOLD,
        "ternary_t1": TERNARY_T1,
        "ternary_t2": TERNARY_T2,
    }
    with open(os.path.join(args.save_dir, "thresholds.json"), "w") as f:
        json.dump(thresholds, f, indent=2)

    print(f"\n>>> Model saved to {args.save_dir}")
    print(f">>> Runtime: {(time.time()-t0)/60:.1f} minutes")

    # Upload to HuggingFace Hub if credentials provided
    if args.hf_token and args.repo_id:
        from huggingface_hub import HfApi, create_repo
        try:
            create_repo(repo_id=args.repo_id, token=args.hf_token, private=True, exist_ok=True)
            api = HfApi()
            api.upload_folder(folder_path=args.save_dir, repo_id=args.repo_id, token=args.hf_token)
            print(f">>> Uploaded to https://huggingface.co/{args.repo_id}")
        except Exception as e:
            print(f">>> Upload failed: {e}")
            print(f">>> Model is saved locally at {args.save_dir}, upload manually later.")

    # Cleanup
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)


if __name__ == "__main__":
    main()