#!/usr/bin/env python3
"""
compare_models.py - Evaluate multiple models directly (no Docker, GPU-friendly).

Downloads each model from HuggingFace Hub, runs inference on all dataset
samples, and compares predictions against gold labels. Prints a comparison
table with RMSE and accuracy per model per dataset.

Designed for GPU cluster execution. Each model is loaded, evaluated,
then unloaded to free VRAM before loading the next.

Usage:
    # Compare all 4 models on all datasets
    python3 src/train_and_inference/compare_models.py \
        --data_dir ./data \
        --hf_token hf_YOUR_TOKEN \
        --output results/model_comparison.csv

    # Test on augmented data instead
    python3 src/train_and_inference/compare_models.py \
        --data_dir ./data_augmented \
        --hf_token hf_YOUR_TOKEN \
        --output results/model_comparison_augmented.csv

    # Limit samples per question for a quick estimate
    python3 src/train_and_inference/compare_models.py \
        --data_dir ./data \
        --hf_token hf_YOUR_TOKEN \
        --max_answers 5

    # Test only specific models
    python3 src/train_and_inference/compare_models.py \
        --data_dir ./data \
        --hf_token hf_YOUR_TOKEN \
        --models v10-large v11-large
"""

import argparse
import gc
import html
import json
import os
import sys
import time

import numpy as np
import pandas as pd
import torch
from huggingface_hub import snapshot_download
from transformers import AutoModelForSequenceClassification, AutoTokenizer

# =============================================================================
# MODEL CONFIGURATIONS
# =============================================================================
# Each model's training config determines how to run inference.
# field_cols: which fields to include and in what order
# use_prefix: whether to prepend "ternary: " / "binary: " to rubric text
# thresholds: how to map continuous scores to discrete decisions
MODEL_CONFIGS = {
    "v9-large": {
        "repo_id":    "amrit97/xlm-roberta-large-grader-v9",
        "field_cols": ["rubric", "answer"],
        "use_prefix": False,
        "t_binary":   0.45,
        "t1_ternary": 0.25,
        "t2_ternary": 0.75,
    },
    "v10-large": {
        "repo_id":    "jan024/asag-xlm-roberta-large-v10",
        "field_cols": ["rubric", "question", "answer"],
        "use_prefix": True,
        "t_binary":   0.33,
        "t1_ternary": 0.30,
        "t2_ternary": 0.70,
    },
    "v11-base": {
        "repo_id":    "amrit97/xlm-roberta-base-grader-v11",
        "field_cols": ["rubric", "answer"],
        "use_prefix": False,
        "t_binary":   0.45,
        "t1_ternary": 0.25,
        "t2_ternary": 0.75,
    },
    "v11-large": {
        "repo_id":    "amrit97/xlm-roberta-large-grader-v11",
        "field_cols": ["rubric", "answer"],
        "use_prefix": False,
        "t_binary":   0.45,
        "t1_ternary": 0.25,
        "t2_ternary": 0.75,
    },
}

DECISION_TO_SCORE = {"yes": 1.0, "half": 0.5, "no": 0.0}


# =============================================================================
# HELPERS
# =============================================================================
def normalize_text(text):
    """Match training preprocessing exactly."""
    if not text or pd.isna(text):
        return ""
    text = html.unescape(str(text))
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split())


def build_input_ids(tokenizer, rubric, question, answer, field_cols, max_length=512):
    """Dynamic budget tokenization matching training pipeline."""
    encoded = {
        "rubric":   tokenizer.encode(rubric,   add_special_tokens=False),
        "question": tokenizer.encode(question, add_special_tokens=False),
        "answer":   tokenizer.encode(answer,   add_special_tokens=False),
    }
    special_count = len(field_cols) + 1
    total = sum(len(encoded.get(c, [])) for c in field_cols) + special_count

    if total > max_length:
        budget = max_length - special_count
        rubric_len   = len(encoded.get("rubric", []))
        question_len = len(encoded.get("question", []))

        if "answer" in encoded:
            answer_budget = max(80, budget - rubric_len - question_len)
            encoded["answer"] = encoded["answer"][:answer_budget]

        new_total = sum(len(encoded.get(c, [])) for c in field_cols) + special_count
        if new_total > max_length and "question" in encoded:
            used = rubric_len + len(encoded["answer"])
            encoded["question"] = encoded["question"][:max(30, budget - used)]

    ids = [tokenizer.cls_token_id]
    for col in field_cols:
        ids += encoded.get(col, []) + [tokenizer.sep_token_id]
    return ids


def coral_score(logits):
    """CORAL 2-logit output -> continuous score [0, 1]."""
    probs = torch.sigmoid(logits)
    return (0.5 * probs[:, 0] + 0.5 * probs[:, 1])


def score_to_decision(score, is_ternary, t_binary, t1, t2):
    """Type-aware decision mapping."""
    if is_ternary:
        if score < t1:
            return "no"
        elif score <= t2:
            return "half"
        else:
            return "yes"
    else:
        return "yes" if score >= t_binary else "no"


# =============================================================================
# DATA LOADING
# =============================================================================
def load_dataset(dataset_dir):
    """Load and merge all CSVs from a dataset folder."""
    q  = pd.read_csv(os.path.join(dataset_dir, "questions.csv"))
    a  = pd.read_csv(os.path.join(dataset_dir, "answers.csv"))
    r  = pd.read_csv(os.path.join(dataset_dir, "rubrics.csv"))
    ar = pd.read_csv(os.path.join(dataset_dir, "answer_rubrics.csv"))

    for frame in [q, a, r, ar]:
        for col in ["question_id", "answer_id", "rubric_id"]:
            if col in frame.columns:
                frame[col] = frame[col].astype(str)

    if "is_ternary" not in r.columns:
        r["is_ternary"] = True

    return ar.merge(
        a[["question_id", "answer_id", "answer"]],
        on=["question_id", "answer_id"]
    ).merge(
        r[["question_id", "rubric_id", "rubric", "is_ternary"]],
        on=["question_id", "rubric_id"]
    ).merge(
        q[["question_id", "question"]],
        on="question_id"
    )


# =============================================================================
# MODEL EVALUATION
# =============================================================================
def evaluate_model(model_name, config, all_data, hf_token, device, max_answers=None):
    """
    Load a model and evaluate it on all provided dataset rows.

    Returns a list of per-row predictions with metadata for later aggregation.
    """
    print(f"\n{'#' * 70}")
    print(f"  MODEL: {model_name}")
    print(f"  Repo:  {config['repo_id']}")
    print(f"  Fields: {config['field_cols']}  Prefix: {config['use_prefix']}")
    print(f"{'#' * 70}")

    t_download_start = time.time()
    print(f"  Downloading model from HuggingFace Hub...")
    local_path = snapshot_download(
        repo_id=config["repo_id"],
        token=hf_token,
        cache_dir="/tmp/model_cache",
    )
    print(f"  Download complete in {time.time()-t_download_start:.1f}s")

    tokenizer = AutoTokenizer.from_pretrained(local_path)
    model = AutoModelForSequenceClassification.from_pretrained(local_path)
    model.to(device)
    model.eval()

    n_params = sum(p.numel() for p in model.parameters())
    print(f"  Loaded: {n_params:,} params on {device}")

    predictions = []
    t_eval_start = time.time()
    total_rows = sum(
        min(len(df), max_answers * df["question_id"].nunique() * 100) if max_answers else len(df)
        for df in all_data.values()
    )
    rows_done = 0
    last_report = time.time()

    with torch.no_grad():
        for dataset_name, df in all_data.items():
            # Optionally limit samples per question
            if max_answers:
                df = df.groupby("question_id").apply(
                    lambda g: g[g["answer_id"].isin(g["answer_id"].unique()[:max_answers])]
                ).reset_index(drop=True)

            print(f"\n  Dataset: {dataset_name} ({len(df)} pairs)")

            # Process in batches of 16
            batch_size = 16
            for batch_start in range(0, len(df), batch_size):
                batch = df.iloc[batch_start:batch_start + batch_size]

                all_ids = []
                all_masks = []
                meta = []
                for _, row in batch.iterrows():
                    rubric_text = normalize_text(row["rubric"])
                    if config["use_prefix"]:
                        prefix = "ternary: " if row["is_ternary"] else "binary: "
                        rubric_text = prefix + rubric_text

                    ids = build_input_ids(
                        tokenizer,
                        rubric_text,
                        normalize_text(row["question"]),
                        normalize_text(row["answer"]),
                        config["field_cols"],
                    )
                    all_ids.append(ids)
                    all_masks.append([1] * len(ids))
                    meta.append(row)

                # Pad to max length in batch
                max_len = max(len(ids) for ids in all_ids)
                pad_id = tokenizer.pad_token_id or 1
                padded_ids   = [ids + [pad_id] * (max_len - len(ids)) for ids in all_ids]
                padded_masks = [m   + [0]      * (max_len - len(m))   for m   in all_masks]

                ids_tensor  = torch.tensor(padded_ids).to(device)
                mask_tensor = torch.tensor(padded_masks).to(device)

                logits = model(input_ids=ids_tensor, attention_mask=mask_tensor).logits

                if model.config.num_labels == 2:
                    scores = coral_score(logits).cpu().numpy()
                else:
                    scores = torch.clamp(logits.squeeze(-1), 0.0, 1.0).cpu().numpy()

                for score, row in zip(scores, meta):
                    pred_decision = score_to_decision(
                        float(score), bool(row["is_ternary"]),
                        config["t_binary"], config["t1_ternary"], config["t2_ternary"]
                    )
                    pred_score = DECISION_TO_SCORE[pred_decision]
                    gold_score = float(row["label"])
                    predictions.append({
                        "model":       model_name,
                        "dataset":     dataset_name,
                        "question_id": str(row["question_id"]),
                        "answer_id":   str(row["answer_id"]),
                        "rubric_id":   str(row["rubric_id"]),
                        "is_ternary":  bool(row["is_ternary"]),
                        "gold":        gold_score,
                        "raw_score":   float(score),
                        "pred_decision": pred_decision,
                        "pred":        pred_score,
                        "correct":     int(pred_score == gold_score),
                    })

                rows_done += len(batch)
                if time.time() - last_report > 5:
                    rate = rows_done / (time.time() - t_eval_start)
                    print(f"    [{rows_done}/{total_rows}] "
                          f"{rate:.1f} pairs/s | "
                          f"{(time.time()-t_eval_start):.0f}s elapsed",
                          end="\r", flush=True)
                    last_report = time.time()

            print()  # newline after progress

    print(f"\n  Total: {len(predictions)} predictions in "
          f"{time.time()-t_eval_start:.1f}s "
          f"({len(predictions)/(time.time()-t_eval_start):.1f} pairs/s)")

    # Cleanup VRAM
    del model
    del tokenizer
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return predictions


# =============================================================================
# REPORTING
# =============================================================================
def print_comparison_table(all_predictions):
    """Print a comparison table of all models across all datasets."""
    df = pd.DataFrame(all_predictions)
    if df.empty:
        print("\nNo predictions to compare.")
        return

    models = df["model"].unique().tolist()
    datasets = df["dataset"].unique().tolist()

    print(f"\n{'=' * 90}")
    print(f"  MODEL COMPARISON: RMSE and Accuracy by Dataset")
    print(f"{'=' * 90}")

    # RMSE table
    print(f"\n  RMSE (lower is better):")
    header = f"  {'Dataset':<22} " + " ".join(f"{m:>14}" for m in models)
    print(header)
    print(f"  {'-' * (22 + 15 * len(models))}")
    for ds in datasets:
        row = f"  {ds:<22} "
        for m in models:
            sub = df[(df["dataset"] == ds) & (df["model"] == m)]
            if len(sub) > 0:
                rmse = float(np.sqrt(np.mean((sub["pred"] - sub["gold"]) ** 2)))
                row += f"{rmse:>14.4f} "
            else:
                row += f"{'-':>14} "
        print(row)
    # Overall RMSE
    row = f"  {'OVERALL':<22} "
    for m in models:
        sub = df[df["model"] == m]
        if len(sub) > 0:
            rmse = float(np.sqrt(np.mean((sub["pred"] - sub["gold"]) ** 2)))
            row += f"{rmse:>14.4f} "
        else:
            row += f"{'-':>14} "
    print(f"  {'-' * (22 + 15 * len(models))}")
    print(row)

    # Accuracy table
    print(f"\n  Accuracy (higher is better):")
    print(header)
    print(f"  {'-' * (22 + 15 * len(models))}")
    for ds in datasets:
        row = f"  {ds:<22} "
        for m in models:
            sub = df[(df["dataset"] == ds) & (df["model"] == m)]
            if len(sub) > 0:
                acc = float(sub["correct"].mean()) * 100
                row += f"{acc:>13.1f}% "
            else:
                row += f"{'-':>14} "
        print(row)
    row = f"  {'OVERALL':<22} "
    for m in models:
        sub = df[df["model"] == m]
        if len(sub) > 0:
            acc = float(sub["correct"].mean()) * 100
            row += f"{acc:>13.1f}% "
        else:
            row += f"{'-':>14} "
    print(f"  {'-' * (22 + 15 * len(models))}")
    print(row)

    # Binary vs ternary breakdown
    print(f"\n  Binary rubrics only:")
    binary_df = df[~df["is_ternary"]]
    for m in models:
        sub = binary_df[binary_df["model"] == m]
        if len(sub) > 0:
            rmse = float(np.sqrt(np.mean((sub["pred"] - sub["gold"]) ** 2)))
            acc = float(sub["correct"].mean()) * 100
            print(f"    {m:<15} RMSE={rmse:.4f}  Acc={acc:.1f}%  (n={len(sub)})")

    print(f"\n  Ternary rubrics only:")
    ternary_df = df[df["is_ternary"]]
    for m in models:
        sub = ternary_df[ternary_df["model"] == m]
        if len(sub) > 0:
            rmse = float(np.sqrt(np.mean((sub["pred"] - sub["gold"]) ** 2)))
            acc = float(sub["correct"].mean()) * 100
            print(f"    {m:<15} RMSE={rmse:.4f}  Acc={acc:.1f}%  (n={len(sub)})")


# =============================================================================
# MAIN
# =============================================================================
def main():
    parser = argparse.ArgumentParser(description="Compare multiple grader models")
    parser.add_argument("--data_dir", required=True,
                        help="Directory containing dataset subfolders")
    parser.add_argument("--datasets", nargs="+",
                        default=["NLP-SS2425", "WuS-WS25", "DAV-SS2425", "WuS-SS24"],
                        help="Dataset folder names within data_dir")
    parser.add_argument("--models", nargs="+",
                        default=list(MODEL_CONFIGS.keys()),
                        help="Which models to compare")
    parser.add_argument("--hf_token", required=True,
                        help="HuggingFace access token")
    parser.add_argument("--max_answers", type=int, default=None,
                        help="Limit answers per question (default: all)")
    parser.add_argument("--output", type=str, default="./results/model_comparison.csv",
                        help="CSV file to save per-row predictions")
    args = parser.parse_args()

    # Validate models
    for m in args.models:
        if m not in MODEL_CONFIGS:
            print(f"ERROR: Unknown model '{m}'. Available: {list(MODEL_CONFIGS.keys())}")
            sys.exit(1)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")

    # Load all datasets once (reused across models)
    print(f"\nLoading datasets from {args.data_dir}...")
    all_data = {}
    for ds in args.datasets:
        path = os.path.join(args.data_dir, ds)
        if not os.path.exists(path):
            print(f"  SKIP: {path} not found")
            continue
        all_data[ds] = load_dataset(path)
        print(f"  {ds}: {len(all_data[ds])} pairs")

    if not all_data:
        print("No datasets loaded. Exiting.")
        sys.exit(1)

    # Evaluate each model
    all_predictions = []
    for model_name in args.models:
        try:
            preds = evaluate_model(
                model_name, MODEL_CONFIGS[model_name],
                all_data, args.hf_token, device, args.max_answers,
            )
            all_predictions.extend(preds)
        except Exception as e:
            print(f"\n  ERROR evaluating {model_name}: {e}")
            continue

    # Final comparison
    print_comparison_table(all_predictions)

    # Save predictions
    if args.output and all_predictions:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        pd.DataFrame(all_predictions).to_csv(args.output, index=False)
        print(f"\n  Saved {len(all_predictions)} predictions to {args.output}")

    print(f"\n{'=' * 90}")
    print(f"  Done.")
    print(f"{'=' * 90}\n")


if __name__ == "__main__":
    main()