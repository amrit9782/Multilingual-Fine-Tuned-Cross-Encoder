#!/usr/bin/env python3
"""
Upload a trained model checkpoint to HuggingFace Hub.

Run this on the cluster after training is complete.
The production grader.py will download from this repo at startup.

Usage:
    python upload_model_to_hub.py \
        --model_dir ./saved_models/v10/fold_1 \
        --repo_id jannen-hbrs/asag-xlm-roberta-large \
        --token hf_xxxxxxxxxxxxxxxxxxxx

    # Or with thresholds:
    python upload_model_to_hub.py \
        --model_dir ./saved_models/v10/fold_1 \
        --repo_id jannen-hbrs/asag-xlm-roberta-large \
        --token hf_xxxxxxxxxxxxxxxxxxxx \
        --binary_threshold 0.30 \
        --ternary_t1 0.20 \
        --ternary_t2 0.65

Prerequisites:
    pip install huggingface_hub
"""

import argparse
import json
import os
from huggingface_hub import HfApi, create_repo


def main():
    parser = argparse.ArgumentParser(description="Upload model to HuggingFace Hub")
    parser.add_argument("--model_dir", type=str, required=True,
                        help="Local path to the trained model folder (contains config.json, model.safetensors, etc.)")
    parser.add_argument("--repo_id", type=str, required=True,
                        help="HuggingFace repo ID, e.g. 'jannen-hbrs/asag-xlm-roberta-large'")
    parser.add_argument("--token", type=str, required=True,
                        help="HuggingFace write access token")
    parser.add_argument("--private", action="store_true", default=True,
                        help="Make the repo private (default: True)")
    parser.add_argument("--binary_threshold", type=float, default=0.30,
                        help="Threshold for binary rubrics (default: 0.30)")
    parser.add_argument("--ternary_t1", type=float, default=0.20,
                        help="Lower threshold for ternary rubrics (default: 0.20)")
    parser.add_argument("--ternary_t2", type=float, default=0.65,
                        help="Upper threshold for ternary rubrics (default: 0.65)")
    args = parser.parse_args()

    # Verify model directory exists and has expected files
    assert os.path.isdir(args.model_dir), f"Not a directory: {args.model_dir}"
    expected_files = ["config.json"]
    for f in expected_files:
        path = os.path.join(args.model_dir, f)
        assert os.path.exists(path), f"Missing: {path}"

    # Save thresholds alongside the model
    thresholds = {
        "binary_threshold": args.binary_threshold,
        "ternary_t1": args.ternary_t1,
        "ternary_t2": args.ternary_t2,
    }
    thresholds_path = os.path.join(args.model_dir, "thresholds.json")
    with open(thresholds_path, "w") as f:
        json.dump(thresholds, f, indent=2)
    print(f"Saved thresholds to {thresholds_path}: {thresholds}")

    # Create repo if it doesn't exist
    api = HfApi()
    try:
        create_repo(
            repo_id=args.repo_id,
            token=args.token,
            private=args.private,
            exist_ok=True,
        )
        print(f"Repo ready: https://huggingface.co/{args.repo_id}")
    except Exception as e:
        print(f"Repo creation: {e}")

    # Upload entire model directory
    print(f"Uploading {args.model_dir} to {args.repo_id}...")
    api.upload_folder(
        folder_path=args.model_dir,
        repo_id=args.repo_id,
        token=args.token,
    )
    print(f"Done! Model available at: https://huggingface.co/{args.repo_id}")
    print(f"\nSet these in your .env:")
    print(f"  MODEL_REPO={args.repo_id}")
    print(f"  HF_TOKEN={args.token}")
    print(f"  USE_CORAL=true")


if __name__ == "__main__":
    main()