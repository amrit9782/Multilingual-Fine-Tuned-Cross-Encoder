"""
test_inference.py - Test model inference on real training samples.

Loads actual samples from the training data to verify model outputs
before pushing to HuggingFace Hub. Tests on YES, NO, and HALF cases
and suggests corrected thresholds based on the score distribution.

Usage:
    # Test default v9 and v10 models
    python test_inference.py

    # Test a specific model only
    python test_inference.py --model v9
    python test_inference.py --model v10

    # Test any custom checkpoint
    python test_inference.py --model custom --model_dir ./saved_models/v10/fold_4

    # Change how many samples per class
    python test_inference.py --n_samples 10

    # Change which dataset to sample from
    python test_inference.py --dataset WuS-WS25

    # Test v10 but with a different fold checkpoint
    python test_inference.py --model v10 --model_dir ./saved_models/v10/fold_2
"""

import argparse
import html
import os
import random
import numpy as np
import pandas as pd
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification


# =============================================================================
# DEFAULT MODEL CONFIGS
# =============================================================================
CONFIGS = {
    "v9": {
        "model_dir":  "./best_model_v9",
        "field_cols": ["rubric", "answer"],
        "use_prefix": False,
        "t_binary":   0.45,      # updated from real-data analysis (was 0.5)
        "t1_ternary": 0.25,
        "t2_ternary": 0.75,
        "label":      "v9 — xlm-roberta-base (colleague's model)",
    },
    "v10": {
        "model_dir":  "./final_model_v10",
        "field_cols": ["rubric", "question", "answer"],
        "use_prefix": True,
        "t_binary":   0.33,      # updated from real-data analysis
        "t1_ternary": 0.30,
        "t2_ternary": 0.70,
        "label":      "v10 — xlm-roberta-large (Jannen's model)",
    },
}

DATA_ROOT   = "./data"
DATASET_MAP = {
    "NLP-SS2425": "NLP-SS2425",
    "WuS-WS25":   "WuS-WS25",
    "DAV-SS2425":  "DAV-SS2425",
    "WuS-SS24":   "WuS-SS24",
}


# =============================================================================
# HELPERS
# =============================================================================
def normalize(text):
    """Match training preprocessing exactly."""
    if not text:
        return ""
    text = html.unescape(str(text))
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split())


def load_real_samples(dataset_name, n_per_class=5, seed=42):
    """Load n_per_class real samples for each label {0, 0.5, 1.0}."""
    path = os.path.join(DATA_ROOT, dataset_name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Dataset not found: {path}")

    df  = pd.read_csv(os.path.join(path, "answer_rubrics.csv"))
    a   = pd.read_csv(os.path.join(path, "answers.csv"))
    r   = pd.read_csv(os.path.join(path, "rubrics.csv"))
    q   = pd.read_csv(os.path.join(path, "questions.csv"))

    if "is_ternary" not in r.columns:
        r["is_ternary"] = True

    merged = df.merge(
        a[["question_id", "answer_id", "answer"]],
        on=["question_id", "answer_id"]
    ).merge(
        r[["question_id", "rubric_id", "rubric", "is_ternary"]],
        on=["question_id", "rubric_id"]
    ).merge(
        q[["question_id", "question"]],
        on="question_id"
    )

    # Sample n per class
    rng = random.Random(seed)
    samples = []
    for label_val in [1.0, 0.0, 0.5]:
        subset = merged[merged["label"] == label_val]
        if len(subset) == 0:
            print(f"  WARNING: no samples with label={label_val} in {dataset_name}")
            continue
        n = min(n_per_class, len(subset))
        chosen = subset.sample(n=n, random_state=seed)
        samples.append(chosen)

    return pd.concat(samples).reset_index(drop=True)


def build_input_ids(tokenizer, rubric_text, question_text, answer_text, field_cols):
    """Dynamic budget tokenization matching training pipeline."""
    encoded = {
        "rubric":   tokenizer.encode(rubric_text,   add_special_tokens=False),
        "question": tokenizer.encode(question_text, add_special_tokens=False),
        "answer":   tokenizer.encode(answer_text,   add_special_tokens=False),
    }
    special_count = len(field_cols) + 1
    total = sum(len(encoded[c]) for c in field_cols) + special_count

    if total > 512:
        budget = 512 - special_count
        rubric_len   = len(encoded.get("rubric", []))
        question_len = len(encoded.get("question", []))
        if "answer" in encoded:
            answer_budget = max(80, budget - rubric_len - question_len)
            encoded["answer"] = encoded["answer"][:answer_budget]
        new_total = sum(len(encoded[c]) for c in field_cols) + special_count
        if new_total > 512 and "question" in encoded:
            used = rubric_len + len(encoded["answer"])
            encoded["question"] = encoded["question"][:max(30, budget - used)]

    ids = [tokenizer.cls_token_id]
    for col in field_cols:
        ids += encoded[col] + [tokenizer.sep_token_id]
    return ids


def coral_score(logits):
    """2-logit CORAL output -> continuous score in [0, 1]."""
    probs = torch.sigmoid(logits)
    return (0.5 * probs[0, 0] + 0.5 * probs[0, 1]).item()


def score_to_decision(score, is_ternary, t_binary, t1_ternary, t2_ternary):
    """Type-aware threshold decision."""
    if is_ternary:
        if score < t1_ternary:
            return "no"
        elif score <= t2_ternary:
            return "half"
        else:
            return "yes"
    else:
        return "yes" if score >= t_binary else "no"


def label_to_expected(label):
    if label == 1.0: return "yes"
    if label == 0.0: return "no"
    return "half"


# =============================================================================
# THRESHOLD SUGGESTION
# =============================================================================
def suggest_thresholds(samples_df, all_scores):
    """Suggest better thresholds based on actual score distribution."""
    by_label = {}
    for i, (_, row) in enumerate(samples_df.iterrows()):
        lbl = label_to_expected(row["label"])
        by_label.setdefault(lbl, []).append(all_scores[i])

    print(f"\n  Score distribution by label:")
    for lbl in ["yes", "half", "no"]:
        if lbl in by_label:
            scores = by_label[lbl]
            print(f"    {lbl:>4}: min={min(scores):.3f}  max={max(scores):.3f}  "
                  f"mean={np.mean(scores):.3f}  ({len(scores)} samples)")

    suggestions = {}
    if "yes" in by_label and "no" in by_label:
        mid = (np.mean(by_label["yes"]) + np.mean(by_label["no"])) / 2
        suggestions["t_binary"] = round(mid, 2)

    if "half" in by_label:
        if "no" in by_label:
            t1 = (np.mean(by_label["half"]) + np.mean(by_label["no"])) / 2
            suggestions["t1_ternary"] = round(t1, 2)
        if "yes" in by_label:
            t2 = (np.mean(by_label["yes"]) + np.mean(by_label["half"])) / 2
            suggestions["t2_ternary"] = round(t2, 2)

    if suggestions:
        print(f"\n  Suggested thresholds from this distribution:")
        for k, v in suggestions.items():
            print(f"    {k} = {v}")

    return suggestions


# =============================================================================
# MAIN TEST FUNCTION
# =============================================================================
def test_model(config, samples_df, label_override=None):
    """Load model and test on provided samples."""
    model_dir  = config["model_dir"]
    field_cols = config["field_cols"]
    use_prefix = config["use_prefix"]
    t_binary   = config["t_binary"]
    t1_ternary = config["t1_ternary"]
    t2_ternary = config["t2_ternary"]
    display_label = label_override or config["label"]

    print(f"\n{'=' * 70}")
    print(f"  {display_label}")
    print(f"  Path:    {model_dir}")
    print(f"  Fields:  {field_cols}")
    print(f"  Prefix:  {use_prefix}")
    print(f"  Thresh:  binary={t_binary}  ternary=({t1_ternary}, {t2_ternary})")
    print(f"{'=' * 70}")

    if not os.path.exists(model_dir):
        print(f"\n  SKIP: directory not found: {model_dir}")
        return None

    tokenizer = AutoTokenizer.from_pretrained(model_dir)
    model = AutoModelForSequenceClassification.from_pretrained(model_dir)
    model.eval()

    n_labels = model.config.num_labels
    n_params = sum(p.numel() for p in model.parameters())
    print(f"  Architecture: {n_labels} label(s) ({'CORAL' if n_labels == 2 else 'MSE'})")
    print(f"  Parameters:   {n_params:,}\n")

    correct = 0
    all_scores = []

    header = (f"  {'Label':>6} {'Ternary':>8} "
              f"{'Rubric (40 chars)':<42} {'Score':>7} "
              f"{'Decision':>10} {'Expected':>10} {'':>6}")
    print(header)
    print(f"  {'-'*95}")

    with torch.no_grad():
        for _, row in samples_df.iterrows():
            rubric_text = normalize(row["rubric"])
            if use_prefix:
                rubric_text = ("ternary: " if row["is_ternary"] else "binary: ") + rubric_text

            ids = build_input_ids(
                tokenizer,
                rubric_text,
                normalize(row.get("question", "")),
                normalize(row["answer"]),
                field_cols,
            )

            logits = model(
                input_ids=torch.tensor([ids]),
                attention_mask=torch.ones(1, len(ids)),
            ).logits

            score    = coral_score(logits) if n_labels == 2 else max(0.0, min(1.0, logits.squeeze(-1).item()))
            decision = score_to_decision(score, row["is_ternary"], t_binary, t1_ternary, t2_ternary)
            expected = label_to_expected(row["label"])
            match    = "OK" if decision == expected else "WRONG"
            if match == "OK":
                correct += 1
            all_scores.append(score)

            rubric_short = str(row["rubric"])[:40]
            print(f"  {row['label']:>6}  {str(row['is_ternary']):>8} "
                  f"{rubric_short:<42} {score:>7.4f} "
                  f"{decision:>10} {expected:>10} {match:>6}")

    total = len(samples_df)
    print(f"\n  Result: {correct}/{total} correct ({100*correct/total:.0f}%)")
    print(f"  Score range: min={min(all_scores):.4f}  max={max(all_scores):.4f}  "
          f"mean={np.mean(all_scores):.4f}")

    suggest_thresholds(samples_df, all_scores)
    return correct, total


# =============================================================================
# MAIN
# =============================================================================
def main():
    parser = argparse.ArgumentParser(description="Test model inference on real training data")
    parser.add_argument("--model", choices=["v9", "v10", "both", "custom"], default="both",
                        help="Which model to test (default: both)")
    parser.add_argument("--model_dir", type=str, default=None,
                        help="Path to model checkpoint for --model custom")
    parser.add_argument("--field_cols", nargs="+", default=None,
                        help="Field columns for custom model (e.g. rubric question answer)")
    parser.add_argument("--use_prefix", action="store_true", default=False,
                        help="Add is_ternary prefix for custom model")
    parser.add_argument("--dataset", choices=list(DATASET_MAP.keys()), default="NLP-SS2425",
                        help="Which dataset to sample from (default: NLP-SS2425)")
    parser.add_argument("--n_samples", type=int, default=5,
                        help="Samples per label class (default: 5)")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for sampling (default: 42)")
    args = parser.parse_args()

    print(f"\n{'='*70}")
    print(f"  LOCAL INFERENCE TEST — real training samples")
    print(f"  Dataset: {args.dataset}  |  Samples per class: {args.n_samples}")
    print(f"{'='*70}")

    # Load real samples once (same samples used for both models)
    print(f"\nLoading {args.n_samples} real samples per label from {args.dataset}...")
    try:
        samples = load_real_samples(args.dataset, n_per_class=args.n_samples, seed=args.seed)
        label_counts = samples["label"].value_counts().to_dict()
        print(f"  Loaded {len(samples)} samples: {label_counts}")
    except FileNotFoundError as e:
        print(f"  ERROR: {e}")
        print(f"  Available datasets in {DATA_ROOT}: {os.listdir(DATA_ROOT) if os.path.exists(DATA_ROOT) else 'directory not found'}")
        return

    results = {}

    if args.model == "custom":
        if not args.model_dir:
            print("ERROR: --model_dir is required for --model custom")
            return
        custom_config = {
            "model_dir":  args.model_dir,
            "field_cols": args.field_cols or ["rubric", "question", "answer"],
            "use_prefix": args.use_prefix,
            "t_binary":   0.33,
            "t1_ternary": 0.30,
            "t2_ternary": 0.70,
            "label":      f"Custom: {args.model_dir}",
        }
        r = test_model(custom_config, samples)
        if r: results["custom"] = r

    else:
        models_to_run = ["v9", "v10"] if args.model == "both" else [args.model]
        for m in models_to_run:
            cfg = dict(CONFIGS[m])
            # Allow overriding model_dir even for named models
            if args.model_dir and args.model != "both":
                cfg["model_dir"] = args.model_dir
                cfg["label"] = f"{m} (custom dir: {args.model_dir})"
            r = test_model(cfg, samples)
            if r: results[m] = r

    # Final comparison
    if len(results) > 1:
        print(f"\n{'='*70}")
        print(f"  SUMMARY")
        print(f"{'='*70}")
        for name, (correct, total) in results.items():
            bar = "+" * correct + "-" * (total - correct)
            print(f"  {name:<10} {correct:>2}/{total} ({100*correct/total:>5.1f}%)  [{bar}]")
        winner = max(results, key=lambda k: results[k][0])
        print(f"\n  Better model: {winner}")
    print()


if __name__ == "__main__":
    main()