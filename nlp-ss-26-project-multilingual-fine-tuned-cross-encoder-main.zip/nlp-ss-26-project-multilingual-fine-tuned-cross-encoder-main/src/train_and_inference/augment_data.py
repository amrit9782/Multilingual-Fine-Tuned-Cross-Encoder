#!/usr/bin/env python3
"""
augment_data.py - Augment training data via back-translation.

For each (question, rubric, answer, label) row, generates an augmented
variant by back-translating the student answer through another language
and back. Rubric and labels are left untouched.

Translation paths:
    English answers:  EN -> DE -> EN
    German answers:   DE -> EN -> DE

Uses Helsinki-NLP Opus-MT models (small, fast, no API key needed).

The output is a doubled dataset:
    - Original rows are copied unchanged
    - Augmented rows get new answer_id (suffix "_aug") with the same labels

Usage:
    # Augment all 4 datasets
    python3 src/train_and_inference/augment_data.py \
        --data_dir ./data \
        --output_dir ./data_augmented

    # Augment a single dataset
    python3 src/train_and_inference/augment_data.py \
        --data_dir ./data \
        --output_dir ./data_augmented \
        --datasets NLP-SS2425

    # Limit number of answers to augment per question (for testing)
    python3 src/train_and_inference/augment_data.py \
        --data_dir ./data \
        --output_dir ./data_augmented \
        --max_answers 5

    # Force CPU (default uses GPU if available)
    python3 src/train_and_inference/augment_data.py \
        --data_dir ./data \
        --output_dir ./data_augmented \
        --device cpu

Estimated runtime on GPU: ~15-30 min for all 4 datasets.
Estimated runtime on CPU: ~1-2 hours.
"""

import argparse
import gc
import os
import shutil
import sys
import time

import pandas as pd
import torch
from transformers import MarianMTModel, MarianTokenizer

# =============================================================================
# TRANSLATION MODEL CONFIG
# =============================================================================
TRANSLATION_MODELS = {
    "en-de": "Helsinki-NLP/opus-mt-en-de",
    "de-en": "Helsinki-NLP/opus-mt-de-en",
}


# =============================================================================
# LANGUAGE DETECTION
# =============================================================================
def detect_language(text):
    """
    Heuristic language detection based on common German vs English words.

    Returns 'de' or 'en'. Defaults to 'en' if uncertain.
    """
    if not text or len(text) < 10:
        return "en"

    text_lower = text.lower()
    # Common German words that are rare in English
    de_markers = [" der ", " die ", " das ", " und ", " ist ", " nicht ",
                  " ein ", " eine ", " mit ", " sich ", " auf ", " sind ",
                  " werden ", "ä", "ö", "ü", "ß"]
    de_count = sum(1 for m in de_markers if m in text_lower)

    # Common English words that are rare in German
    en_markers = [" the ", " is ", " are ", " and ", " of ", " to ",
                  " in ", " a ", " that ", " this ", " with "]
    en_count = sum(1 for m in en_markers if m in text_lower)

    return "de" if de_count > en_count else "en"


# =============================================================================
# TRANSLATION
# =============================================================================
class Translator:
    """Loads and caches Marian MT models for EN<->DE translation."""

    def __init__(self, device):
        self.device = device
        self.models = {}
        self.tokenizers = {}

    def load(self, direction):
        """Load a translation model on demand."""
        if direction in self.models:
            return
        model_id = TRANSLATION_MODELS[direction]
        print(f"  Loading {model_id}...")
        self.tokenizers[direction] = MarianTokenizer.from_pretrained(model_id)
        self.models[direction] = MarianMTModel.from_pretrained(model_id).to(self.device)
        self.models[direction].eval()

    def translate_batch(self, texts, direction, max_length=512):
        """Translate a list of texts in one direction."""
        if direction not in self.models:
            self.load(direction)

        tokenizer = self.tokenizers[direction]
        model = self.models[direction]

        # Truncate inputs to avoid OOM on very long texts
        inputs = tokenizer(
            texts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_length,
        ).to(self.device)

        with torch.no_grad():
            out_ids = model.generate(
                **inputs,
                max_length=max_length,
                num_beams=2,        # small beam for speed
                early_stopping=True,
            )

        return [tokenizer.decode(ids, skip_special_tokens=True) for ids in out_ids]

    def back_translate(self, text, src_lang):
        """
        Back-translate a single text through the pivot language.

        EN: en -> de -> en
        DE: de -> en -> de
        """
        if src_lang == "en":
            mid = self.translate_batch([text], "en-de")[0]
            return self.translate_batch([mid], "de-en")[0]
        else:
            mid = self.translate_batch([text], "de-en")[0]
            return self.translate_batch([mid], "en-de")[0]

    def back_translate_batch(self, texts, src_lang, batch_size=8):
        """Back-translate a list of texts efficiently using batches."""
        results = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            if src_lang == "en":
                mid = self.translate_batch(batch, "en-de")
                final = self.translate_batch(mid, "de-en")
            else:
                mid = self.translate_batch(batch, "de-en")
                final = self.translate_batch(mid, "en-de")
            results.extend(final)
        return results


# =============================================================================
# AUGMENT A SINGLE DATASET
# =============================================================================
def augment_dataset(dataset_dir, output_dir, translator, max_answers=None):
    """
    Augment a single dataset folder.

    Copies questions.csv, rubrics.csv, answer_rubrics.csv as-is (with
    augmented entries added). Doubles answers.csv with back-translated
    variants.
    """
    name = os.path.basename(dataset_dir.rstrip("/"))
    print(f"\n{'=' * 65}")
    print(f"  AUGMENTING: {name}")
    print(f"{'=' * 65}")

    os.makedirs(output_dir, exist_ok=True)

    # Load all source CSVs
    q  = pd.read_csv(os.path.join(dataset_dir, "questions.csv"))
    a  = pd.read_csv(os.path.join(dataset_dir, "answers.csv"))
    r  = pd.read_csv(os.path.join(dataset_dir, "rubrics.csv"))
    ar = pd.read_csv(os.path.join(dataset_dir, "answer_rubrics.csv"))

    # IDs as strings for consistent suffixing
    for frame in [q, a, r, ar]:
        for col in ["question_id", "answer_id", "rubric_id"]:
            if col in frame.columns:
                frame[col] = frame[col].astype(str)

    print(f"  Original: {len(a)} answers, {len(ar)} answer-rubric pairs")

    # Optionally limit how many answers per question to augment
    if max_answers:
        kept_ids = (
            a.groupby("question_id")
              .apply(lambda g: g["answer_id"].head(max_answers).tolist())
              .explode().tolist()
        )
        to_augment = a[a["answer_id"].isin(kept_ids)].copy()
    else:
        to_augment = a.copy()

    print(f"  Augmenting {len(to_augment)} answers via back-translation...")

    # Group answers by detected language for batched translation
    to_augment["lang"] = to_augment["answer"].apply(
        lambda x: detect_language(str(x))
    )
    print(f"    EN answers: {(to_augment['lang']=='en').sum()}")
    print(f"    DE answers: {(to_augment['lang']=='de').sum()}")

    # Back-translate
    t_start = time.time()
    augmented_answers = []

    for lang in ["en", "de"]:
        subset = to_augment[to_augment["lang"] == lang]
        if subset.empty:
            continue

        texts = subset["answer"].astype(str).tolist()
        print(f"\n  Back-translating {len(texts)} {lang.upper()} answers...")

        translated = translator.back_translate_batch(texts, lang, batch_size=8)

        for (_, row), new_text in zip(subset.iterrows(), translated):
            augmented_answers.append({
                "question_id": row["question_id"],
                "answer_id":   row["answer_id"] + "_aug",
                "answer":      new_text,
                "score":       row.get("score", 0),
            })

        elapsed = time.time() - t_start
        rate = len([a for a in augmented_answers]) / max(elapsed, 1)
        print(f"  Progress: {len(augmented_answers)} done in {elapsed:.0f}s "
              f"({rate:.1f} answers/s)")

    aug_a = pd.DataFrame(augmented_answers)

    # Build augmented answer_rubrics: duplicate every original ar row with new answer_id
    aug_ar = ar.copy()
    aug_ar = aug_ar[aug_ar["answer_id"].isin(to_augment["answer_id"])].copy()
    aug_ar["answer_id"] = aug_ar["answer_id"].astype(str) + "_aug"

    # Combine original + augmented
    out_a  = pd.concat([a, aug_a], ignore_index=True)
    out_ar = pd.concat([ar, aug_ar], ignore_index=True)

    # Questions and rubrics stay the same (just copy)
    out_q = q
    out_r = r

    print(f"\n  Output: {len(out_a)} answers, {len(out_ar)} answer-rubric pairs "
          f"(2x original)")

    # Save
    out_q.to_csv(os.path.join(output_dir, "questions.csv"), index=False)
    out_a.drop(columns=["lang"], errors="ignore").to_csv(
        os.path.join(output_dir, "answers.csv"), index=False
    )
    out_r.to_csv(os.path.join(output_dir, "rubrics.csv"), index=False)
    out_ar.to_csv(os.path.join(output_dir, "answer_rubrics.csv"), index=False)

    total_time = time.time() - t_start
    print(f"\n  Saved to {output_dir}")
    print(f"  Time: {total_time:.0f}s")

    return {
        "dataset": name,
        "original_answers": len(a),
        "augmented_answers": len(augmented_answers),
        "total_answers": len(out_a),
        "time_seconds": total_time,
    }


# =============================================================================
# MAIN
# =============================================================================
def main():
    parser = argparse.ArgumentParser(description="Augment data via back-translation")
    parser.add_argument("--data_dir", required=True,
                        help="Source data directory")
    parser.add_argument("--output_dir", required=True,
                        help="Where to save augmented data")
    parser.add_argument("--datasets", nargs="+",
                        default=["NLP-SS2425", "WuS-WS25", "DAV-SS2425", "WuS-SS24"],
                        help="Dataset folders to augment")
    parser.add_argument("--max_answers", type=int, default=None,
                        help="Max answers per question to augment (default: all)")
    parser.add_argument("--device", choices=["cuda", "cpu", "auto"], default="auto",
                        help="Device for translation models")
    args = parser.parse_args()

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    print(f"Device: {device}")
    if device.type == "cuda":
        print(f"GPU: {torch.cuda.get_device_name(0)}")

    translator = Translator(device)

    results = []
    for ds in args.datasets:
        src = os.path.join(args.data_dir, ds)
        dst = os.path.join(args.output_dir, ds)
        if not os.path.exists(src):
            print(f"\nSKIP: {src} not found")
            continue

        try:
            r = augment_dataset(src, dst, translator, args.max_answers)
            results.append(r)
        except Exception as e:
            print(f"\nERROR augmenting {ds}: {e}")
            import traceback
            traceback.print_exc()

    # Summary
    print(f"\n{'=' * 65}")
    print(f"  AUGMENTATION SUMMARY")
    print(f"{'=' * 65}")
    print(f"  {'Dataset':<20} {'Original':>10} {'Augmented':>10} "
          f"{'Total':>10} {'Time':>8}")
    print(f"  {'-' * 60}")
    total_time = 0
    for r in results:
        print(f"  {r['dataset']:<20} {r['original_answers']:>10} "
              f"{r['augmented_answers']:>10} {r['total_answers']:>10} "
              f"{r['time_seconds']:>7.0f}s")
        total_time += r["time_seconds"]
    print(f"  {'-' * 60}")
    print(f"  Total runtime: {total_time:.0f}s ({total_time/60:.1f} min)")
    print(f"\n  Output saved to {args.output_dir}\n")


if __name__ == "__main__":
    main()