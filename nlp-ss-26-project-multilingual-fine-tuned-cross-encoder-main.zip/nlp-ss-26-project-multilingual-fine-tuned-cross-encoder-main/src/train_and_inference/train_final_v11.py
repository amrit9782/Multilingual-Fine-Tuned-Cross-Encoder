import os
import sys
import pandas as pd
import torch
from transformers import AutoConfig, AutoTokenizer, AutoModelForSequenceClassification, TrainingArguments
from datasets import Dataset

# Add project root and src directory to python search path
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(script_dir, "../.."))
sys.path.insert(0, project_root)
sys.path.insert(0, os.path.join(project_root, "src"))

from comparison.investigation_v11 import (
    load_data, oversample_minority, tokenize_dynamic, WeightedCORALTrainer,
    get_optimizer_grouped_parameters, metrics_regression, unfreeze_top_layers,
    MODELS
)

# ── Configuration (Ablation Grid Search v11 Best Parameters) ──────────────────
# Based on the results inside results/investigation_v11_results.csv:
# Best RMSE Run: T1=0.22, T2=0.69, RMSE=0.3660, Acc=72.17% (LR=5e-5, unfreeze=10)
# Best Acc Run:  T1=0.24, T2=0.67, RMSE=0.3717, Acc=73.95% (LR=5e-5, unfreeze=8)

MODEL_KEY = "xlm-roberta-base"        # "xlm-roberta-base" or "mdeberta-v3-base"
LR = 5e-5                             # Best learning rate (5e-5)
UNFREEZE_LAYERS = 10                  # Best number of top layers to unfreeze (10 for best RMSE, 8 for best Accuracy)
LAYOUT_COLS = ["rubric", "answer"]    # Best layout columns
EPOCHS = 12                           # Number of epochs
USE_FGM = False                       # Set to True if FGM is enabled (best runs used False)

# Best optimized decision thresholds (from the optimal RMSE run)
T1 = 0.22
T2 = 0.69

def main():
    # 1. Load full dataset
    df = load_data()
    train_df_balanced = oversample_minority(df)

    # 2. Set up model & tokenizer
    model_name = MODELS[MODEL_KEY]
    config = AutoConfig.from_pretrained(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name, config=config)

    def make_ds(dataframe):
        dataframe["labels"] = dataframe["label"].astype(float)
        ds = Dataset.from_pandas(dataframe[LAYOUT_COLS + ["labels"]].reset_index(drop=True))
        ds = ds.map(lambda b: tokenize_dynamic(b, tokenizer, LAYOUT_COLS), batched=True)
        return ds.remove_columns(LAYOUT_COLS)

    train_ds = make_ds(train_df_balanced)

    # 3. Load model for sequence classification
    config.num_labels = 2
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, config=config, ignore_mismatched_sizes=True
    )
    unfreeze_top_layers(model, num_layers_to_unfreeze=UNFREEZE_LAYERS, unfreeze_embeddings=USE_FGM)

    out_dir = "/tmp/final_model_train_v11"

    # 4. Training Arguments
    args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=LR,
        per_device_train_batch_size=8,
        gradient_accumulation_steps=2,
        num_train_epochs=EPOCHS,
        weight_decay=0.01,
        save_strategy="no",
        report_to="none",
        bf16=torch.cuda.is_bf16_supported() and torch.cuda.is_available(),
        max_grad_norm=1.0,
    )

    # 5. Trainer
    trainer = WeightedCORALTrainer(
        model=model, 
        args=args, 
        train_dataset=train_ds, 
        processing_class=tokenizer,
        fgm_epsilon=0.5 if USE_FGM else 0.0,
        fgm_emb_name="embeddings.word_embeddings"
    )
    
    print(f"\n>>> Starting final training on full dataset (epochs={EPOCHS}, lr={LR}, unfreeze={UNFREEZE_LAYERS})...")
    trainer.train()

    # 6. Save model directly into the app folder for Docker packaging
    save_path = os.path.abspath(os.path.join(project_root, "app/best_model"))
    os.makedirs(save_path, exist_ok=True)
    model.save_pretrained(save_path)
    tokenizer.save_pretrained(save_path)
    
    # Save optimized thresholds as metadata file in best_model folder
    with open(os.path.join(save_path, "thresholds.txt"), "w") as f:
        f.write(f"T1={T1}\nT2={T2}\nLAYOUT={','.join(LAYOUT_COLS)}")
        
    print(f"\n>>> Final model successfully saved to {save_path}")
    
    # Cleanup tmp directory
    import shutil
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)

if __name__ == "__main__":
    main()
