MODELS = {
    "xlm-roberta": "FacebookAI/xlm-roberta-base",
    "mdeberta": "microsoft/mdeberta-v3-base",
}

DATA_PATH = "DATA/final_grading_dataset.csv"

QUESTION_COL = "question"
SOLUTION_COL = "solution"
RUBRIC_COL = "rubric"
ANSWER_COL = "answer"
SCORE_COL = "target_score"

MAX_LENGTH = 512
BATCH_SIZE = 2
EPOCHS = 3
LEARNING_RATE = 2e-5
SEED = 42

# Per-field token budgets for the preprocessing pipeline.
# rubric(55) + answer(210) + solution(172) + question(70) + 5 special tokens = 512
# Well within the 512 MAX_LENGTH limit.
# These are your first hyperparameter to experiment with!
FIELD_BUDGETS = {
    "rubric":   55,
    "answer":   210,
    "solution": 172,
    "question": 70,
}