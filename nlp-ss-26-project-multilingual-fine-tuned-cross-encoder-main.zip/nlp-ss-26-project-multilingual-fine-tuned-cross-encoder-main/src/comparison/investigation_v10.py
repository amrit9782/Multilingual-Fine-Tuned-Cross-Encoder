# =============================================================================
# INVESTIGATION v10 - Ablation Study: xlm-roberta-large with all improvements
#
# Combines the best findings from the entire project:
#
#   From Group v6:  LR=5e-5, unfreeze=8, [rubric, question, answer] ordering
#   From Group v7:  xlm-roberta-large (550M params)
#   From Group v8:  CORAL ordinal loss, LLRD, FGM adversarial training,
#                   dynamic token budgeting
#   From Jannen:    load_best_model_at_end, is_ternary prefix,
#                   type-aware thresholds, GroupKFold + oversampling
#
# New in v10:
#   - TensorBoard logging: train/val loss per epoch on same scale
#   - group_by option: answer_id (default) or question_id (stricter eval)
#   - Ablation study with 7 experiments
#
# Usage:
#   python investigation_v10.py --data_dir ./data
#   python investigation_v10.py --data_dir ./data --group_by question_id
#   python investigation_v10.py --data_dir ./data --experiments full_config no_llrd
#
# =============================================================================

import os
import sys
import random
import html
import warnings
import shutil
import re
import gc
import json
import time
import argparse
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.utils import resample
from datasets import Dataset
from transformers import (
    AutoConfig,
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    TrainerCallback,
    DataCollatorWithPadding,
    get_linear_schedule_with_warmup,
)
from torch.utils.tensorboard import SummaryWriter

warnings.filterwarnings("ignore")


# =============================================================================
# GLOBAL CONFIG
# =============================================================================
QUESTION_COL  = "question"
SOLUTION_COL  = "solution"
RUBRIC_COL    = "rubric"
ANSWER_COL    = "answer"
SCORE_COL     = "target_score"
ANSWER_ID_COL = "answer_id"
ALL_FIELD_COLS = [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL]

SEED    = 42
N_FOLDS = 5
CLASS_WEIGHTS = {0.0: 1.0, 0.5: 1.0, 1.0: 1.0}


def set_seed(s):
    """Set random seeds for reproducibility across all libraries."""
    random.seed(s)
    np.random.seed(s)
    torch.manual_seed(s)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(s)


# =============================================================================
# TENSORBOARD CALLBACK: per-epoch train + val loss on same plot
# =============================================================================
class EpochLossCallback(TrainerCallback):
    """
    Logs per-epoch training loss and validation loss to TensorBoard
    under the same tag group so they appear on a single chart.

    This makes it easy to spot overfitting: training loss goes down
    while validation loss goes up or flattens.
    """

    def __init__(self, tb_writer):
        self.tb_writer = tb_writer
        self.train_losses = []

    def on_log(self, args, state, control, logs=None, **kwargs):
        """Collect training loss from each logging step."""
        if logs and "loss" in logs:
            self.train_losses.append(logs["loss"])

    def on_evaluate(self, args, state, control, metrics=None, **kwargs):
        """At each evaluation (end of epoch), log both losses to TB."""
        epoch = int(state.epoch) if state.epoch else 0

        # Mean training loss for this epoch
        if self.train_losses:
            mean_train_loss = np.mean(self.train_losses)
            self.tb_writer.add_scalar("epoch_loss/train", mean_train_loss, epoch)
            self.train_losses = []

        # Validation metrics from the evaluate call
        if metrics:
            if "eval_loss" in metrics:
                self.tb_writer.add_scalar("epoch_loss/validation", metrics["eval_loss"], epoch)
            if "eval_rmse" in metrics:
                self.tb_writer.add_scalar("epoch_metrics/rmse", metrics["eval_rmse"], epoch)
            if "eval_rounded_accuracy" in metrics:
                self.tb_writer.add_scalar("epoch_metrics/accuracy", metrics["eval_rounded_accuracy"], epoch)

        self.tb_writer.flush()


# =============================================================================
# TEXT PREPROCESSING
# =============================================================================
def normalize_text(text):
    """Clean and normalize text: unescape HTML, remove markdown headers, collapse whitespace."""
    if pd.isna(text):
        return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split())


# =============================================================================
# DATA LOADING
# =============================================================================
def load_data(data_dir, use_ternary_prefix=True):
    """
    Load all datasets from data_dir, merge, normalize, compute class weights.

    Looks for subdirectories: WuS-WS25, DAV-SS2425, NLP-SS2425, WuS-SS24.
    Skips any that don't exist (so it works with 3 or 4 datasets).
    """
    global CLASS_WEIGHTS
    dataset_names = ["WuS-WS25", "DAV-SS2425", "NLP-SS2425", "WuS-SS24"]
    dfs = []

    print("\n>>> Loading datasets...")
    for name in dataset_names:
        path = os.path.join(data_dir, name)
        if not os.path.exists(path):
            print(f"  WARNING: {path} not found, skipping")
            continue

        q  = pd.read_csv(os.path.join(path, "questions.csv"))
        a  = pd.read_csv(os.path.join(path, "answers.csv"))
        r  = pd.read_csv(os.path.join(path, "rubrics.csv"))
        ar = pd.read_csv(os.path.join(path, "answer_rubrics.csv"))

        # Prefix IDs to prevent collisions across datasets
        prefix = f"{name}_"
        for frame in [q, a, r, ar]:
            for id_col in ["question_id", "answer_id", "rubric_id"]:
                if id_col in frame.columns:
                    frame[id_col] = prefix + frame[id_col].astype(str)

        a = a.rename(columns={"score": "answer_total_score"})
        r = r.rename(columns={"score": "rubric_score"})

        if "is_ternary" not in r.columns:
            r["is_ternary"] = True

        rubric_cols = ["question_id", "rubric_id", "rubric", "rubric_score", "is_ternary"]
        merged = ar.merge(
            a[["question_id", "answer_id", "answer", "answer_total_score"]],
            on=["question_id", "answer_id"], how="left"
        ).merge(
            r[rubric_cols], on=["question_id", "rubric_id"], how="left"
        ).merge(
            q[["question_id", "question", "solution", "max_score"]],
            on="question_id", how="left"
        )

        merged["target_score"] = merged["label"].astype(float) * merged["rubric_score"]
        print(f"  {name}: {len(merged)} rows")
        dfs.append(merged)

    df = pd.concat(dfs, ignore_index=True)

    for col in ALL_FIELD_COLS:
        df[col] = df[col].apply(normalize_text)

    # is_ternary prefix on rubric text (Jannen improvement)
    if use_ternary_prefix and "is_ternary" in df.columns:
        df["rubric"] = df.apply(
            lambda row: ("ternary: " if row["is_ternary"] else "binary: ") + row["rubric"],
            axis=1
        )
        n_bin = (~df["is_ternary"]).sum()
        n_ter = df["is_ternary"].sum()
        print(f"  is_ternary prefix: binary={n_bin}, ternary={n_ter}")

    total = len(df)
    counts = df[SCORE_COL].value_counts().to_dict()
    CLASS_WEIGHTS = {s: total / counts.get(s, 1.0) for s in [0.0, 0.5, 1.0]}

    n_answers = df[ANSWER_ID_COL].nunique()
    n_questions = df["question_id"].nunique()
    print(f"  Combined: {total} rows, {n_answers} answers, {n_questions} questions")
    print(f"  Class weights: {CLASS_WEIGHTS}")
    print(f"  Label distribution: {dict(sorted(counts.items()))}")

    return df


def oversample_minority(df):
    """Oversample minority classes to match the largest class size."""
    classes = [df[(df[SCORE_COL] - s).abs() < 0.01] for s in [0.0, 0.5, 1.0]]
    max_size = max(len(c) for c in classes)
    balanced = pd.concat([
        resample(c, replace=True, n_samples=max_size, random_state=SEED)
        if len(c) < max_size else c
        for c in classes
    ])
    balanced = balanced.sample(frac=1, random_state=SEED).reset_index(drop=True)
    print(f"  [Oversampling] {len(df)} -> {len(balanced)} samples")
    return balanced


# =============================================================================
# DYNAMIC TOKENIZATION (from v8)
# =============================================================================
def tokenize_dynamic(batch, tokenizer, field_cols, max_length=512):
    """
    Tokenize with dynamic budget allocation.

    If everything fits in max_length, nothing is truncated.
    If over budget, truncate in priority order: answer > solution > question.
    Rubric is never truncated (defines the grading criterion).
    """
    all_ids, all_masks = [], []
    special_count = len(field_cols) + 1  # CLS + SEP per field

    for i in range(len(batch[field_cols[0]])):
        encoded = {
            col: tokenizer.encode(batch[col][i], add_special_tokens=False)
            for col in field_cols
        }
        lengths = {col: len(toks) for col, toks in encoded.items()}
        total = sum(lengths.values()) + special_count

        if total > max_length:
            budget = max_length - special_count
            rubric_len = lengths.get("rubric", 0)
            question_len = lengths.get("question", 0)
            solution_len = lengths.get("solution", 0)

            # Truncate answer first (minimum 80 tokens)
            if "answer" in encoded:
                non_answer = rubric_len + question_len + solution_len
                answer_budget = max(80, budget - non_answer)
                encoded["answer"] = encoded["answer"][:answer_budget]

            # Then solution if still over
            new_total = sum(len(t) for t in encoded.values()) + special_count
            if new_total > max_length and "solution" in encoded:
                used = rubric_len + question_len + len(encoded["answer"])
                sol_budget = max(50, budget - used)
                encoded["solution"] = encoded["solution"][:sol_budget]

            # Last resort: question
            new_total = sum(len(t) for t in encoded.values()) + special_count
            if new_total > max_length and "question" in encoded:
                used = rubric_len + len(encoded.get("solution", [])) + len(encoded["answer"])
                q_budget = max(30, budget - used)
                encoded["question"] = encoded["question"][:q_budget]

        ids = [tokenizer.cls_token_id]
        for col in field_cols:
            ids += encoded[col] + [tokenizer.sep_token_id]

        all_ids.append(ids)
        all_masks.append([1] * len(ids))

    return {"input_ids": all_ids, "attention_mask": all_masks}


# =============================================================================
# FGM ADVERSARIAL TRAINING (from v8)
# =============================================================================
class FGM:
    """Fast Gradient Method: perturb embeddings in gradient direction for regularization."""

    def __init__(self, model, epsilon=0.5, emb_name="word_embeddings"):
        self.model = model
        self.epsilon = epsilon
        self.emb_name = emb_name
        self.backup = {}

    def attack(self):
        """Add adversarial perturbation to embedding weights."""
        for name, param in self.model.named_parameters():
            if param.requires_grad and self.emb_name in name:
                self.backup[name] = param.data.clone()
                norm = torch.norm(param.grad)
                if norm != 0 and not torch.isnan(norm):
                    param.data.add_(self.epsilon * param.grad / norm)

    def restore(self):
        """Restore original embedding weights after adversarial step."""
        for name, param in self.model.named_parameters():
            if param.requires_grad and self.emb_name in name:
                assert name in self.backup
                param.data.copy_(self.backup[name])
        self.backup = {}


# =============================================================================
# TRAINER CLASSES
# =============================================================================
class CORALTrainer(Trainer):
    """
    CORAL ordinal regression with optional FGM adversarial training.

    Model outputs 2 logits for P(score >= 0.5) and P(score >= 1.0).
    Loss: weighted BCE on cumulative probability thresholds.
    """

    def __init__(self, *args, fgm_epsilon=0.0, fgm_emb_name="word_embeddings", **kwargs):
        super().__init__(*args, **kwargs)
        self.fgm_epsilon = fgm_epsilon
        self.fgm_emb_name = fgm_emb_name

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        """CORAL loss: BCE on cumulative thresholds, weighted by class frequency."""
        inputs_copy = dict(inputs)
        labels = inputs_copy.pop("labels")
        outputs = model(**inputs_copy)
        logits = outputs.logits  # (batch, 2)

        y1 = (labels >= 0.5).float()
        y2 = (labels >= 1.0).float()
        targets = torch.stack([y1, y2], dim=-1)

        bce = nn.BCEWithLogitsLoss(reduction="none")
        loss = bce(logits, targets)

        weights = torch.ones_like(labels)
        for score_val, w in CLASS_WEIGHTS.items():
            weights[(labels - score_val).abs() < 0.01] = w

        loss = (loss.sum(dim=-1) * weights).mean()
        return (loss, outputs) if return_outputs else loss

    def training_step(self, model, inputs, *args, **kwargs):
        """Forward + backward + optional FGM adversarial step."""
        model.train()
        inputs = self._prepare_inputs(inputs)

        loss = self.compute_loss(model, inputs)
        if self.args.gradient_accumulation_steps > 1:
            loss = loss / self.args.gradient_accumulation_steps
        self.accelerator.backward(loss)

        if self.fgm_epsilon > 0:
            fgm = FGM(model, epsilon=self.fgm_epsilon, emb_name=self.fgm_emb_name)
            fgm.attack()
            loss_adv = self.compute_loss(model, inputs)
            if self.args.gradient_accumulation_steps > 1:
                loss_adv = loss_adv / self.args.gradient_accumulation_steps
            self.accelerator.backward(loss_adv)
            fgm.restore()

        return loss.detach()


class WeightedMSETrainer(Trainer):
    """Weighted MSE regression with optional FGM. For ablation comparison vs CORAL."""

    def __init__(self, *args, fgm_epsilon=0.0, fgm_emb_name="word_embeddings", **kwargs):
        super().__init__(*args, **kwargs)
        self.fgm_epsilon = fgm_epsilon
        self.fgm_emb_name = fgm_emb_name

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        """Weighted MSE loss for single-output regression."""
        inputs_copy = dict(inputs)
        labels = inputs_copy.pop("labels")
        outputs = model(**inputs_copy)
        preds = outputs.logits.squeeze(-1)

        weights = torch.ones_like(labels)
        for score_val, w in CLASS_WEIGHTS.items():
            weights[(labels - score_val).abs() < 0.01] = w

        loss = (weights * (preds - labels) ** 2).mean()
        return (loss, outputs) if return_outputs else loss

    def training_step(self, model, inputs, *args, **kwargs):
        """Forward + backward + optional FGM adversarial step."""
        model.train()
        inputs = self._prepare_inputs(inputs)

        loss = self.compute_loss(model, inputs)
        if self.args.gradient_accumulation_steps > 1:
            loss = loss / self.args.gradient_accumulation_steps
        self.accelerator.backward(loss)

        if self.fgm_epsilon > 0:
            fgm = FGM(model, epsilon=self.fgm_epsilon, emb_name=self.fgm_emb_name)
            fgm.attack()
            loss_adv = self.compute_loss(model, inputs)
            if self.args.gradient_accumulation_steps > 1:
                loss_adv = loss_adv / self.args.gradient_accumulation_steps
            self.accelerator.backward(loss_adv)
            fgm.restore()

        return loss.detach()


# =============================================================================
# LLRD: Layer-wise Discriminative Learning Rate (from v8)
# =============================================================================
def get_llrd_param_groups(model, base_lr, weight_decay=0.01, lr_decay=0.88):
    """
    Group model parameters with decaying LR from top to bottom.

    Head layers get full base_lr. Each encoder layer going downward
    gets lr * (lr_decay ^ distance_from_top). This preserves general
    language knowledge in lower layers while adapting upper layers.
    """
    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_layer = max(
        (int(m.group(1)) for n, _ in model.named_parameters()
         for m in [layer_pattern.search(n)] if m),
        default=-1
    )

    groups = []

    # Head: full LR
    head_params = [
        p for n, p in model.named_parameters()
        if p.requires_grad and any(h in n for h in ["classifier", "score", "pooler"])
    ]
    if head_params:
        groups.append({"params": head_params, "lr": base_lr, "weight_decay": weight_decay})

    # Encoder layers: decaying LR
    for idx in range(max_layer, -1, -1):
        layer_lr = base_lr * (lr_decay ** (max_layer - idx))
        layer_params = [
            p for n, p in model.named_parameters()
            if p.requires_grad and f"layer.{idx}." in n
            and not any(h in n for h in ["classifier", "score", "pooler"])
        ]
        if layer_params:
            groups.append({"params": layer_params, "lr": layer_lr, "weight_decay": weight_decay})

    # Embeddings: lowest LR
    base_params = [
        p for n, p in model.named_parameters()
        if p.requires_grad
        and not layer_pattern.search(n)
        and not any(h in n for h in ["classifier", "score", "pooler"])
    ]
    if base_params:
        groups.append({
            "params": base_params,
            "lr": base_lr * (lr_decay ** (max_layer + 1)),
            "weight_decay": weight_decay,
        })

    return groups


# =============================================================================
# LAYER UNFREEZING
# =============================================================================
def unfreeze_top_layers(model, num_layers):
    """Freeze everything, then unfreeze top N encoder layers + classification head."""
    for param in model.parameters():
        param.requires_grad = False

    for name, module in model.named_modules():
        if any(h in name for h in ["classifier", "score", "pooler"]):
            for param in module.parameters():
                param.requires_grad = True

    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_idx = max(
        (int(m.group(1)) for n, _ in model.named_parameters()
         for m in [layer_pattern.search(n)] if m),
        default=-1
    )
    if max_idx != -1:
        start = max(0, max_idx - num_layers + 1)
        for name, param in model.named_parameters():
            m = layer_pattern.search(name)
            if m and int(m.group(1)) >= start:
                param.requires_grad = True
        print(f"  [Unfreezing] layers {start}-{max_idx} + head")

    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  [Params] {trainable:,} / {total:,} ({100 * trainable / total:.1f}%)")


# =============================================================================
# METRICS
# =============================================================================
def round_to_valid(s):
    """Round to nearest valid label: {0.0, 0.5, 1.0}."""
    v = np.array([0.0, 0.5, 1.0])
    return float(v[np.argmin(np.abs(v - s))])


def coral_to_score(logits_2d):
    """Convert 2-logit CORAL output to continuous score in [0, 1]."""
    probs = 1.0 / (1.0 + np.exp(-logits_2d))
    return 0.5 * probs[:, 0] + 0.5 * probs[:, 1]


def metrics_coral(eval_pred):
    """RMSE, MAE, accuracy for CORAL (2-logit) models."""
    preds, labels = eval_pred
    preds = preds.reshape(-1, 2)
    labels = labels.reshape(-1)
    if np.isnan(preds).any():
        return {"rmse": 999.0, "mae": 999.0, "rounded_accuracy": 0.0}
    continuous = coral_to_score(preds)
    rmse = np.sqrt(mean_squared_error(labels, continuous))
    mae = mean_absolute_error(labels, continuous)
    rounded = np.array([round_to_valid(p) for p in continuous])
    return {"rmse": rmse, "mae": mae, "rounded_accuracy": np.mean(rounded == labels)}


def metrics_mse(eval_pred):
    """RMSE, MAE, accuracy for single-output MSE models."""
    preds, labels = eval_pred
    preds = np.clip(preds.reshape(-1), 0.0, 1.0)
    labels = labels.reshape(-1)
    if np.isnan(preds).any():
        return {"rmse": 999.0, "mae": 999.0, "rounded_accuracy": 0.0}
    rmse = np.sqrt(mean_squared_error(labels, preds))
    mae = mean_absolute_error(labels, preds)
    rounded = np.array([round_to_valid(p) for p in preds])
    return {"rmse": rmse, "mae": mae, "rounded_accuracy": np.mean(rounded == labels)}


# =============================================================================
# RAW PREDICTIONS
# =============================================================================
def get_raw_predictions(model, df, tokenizer, field_cols, use_coral=True):
    """Run inference on all rows, return continuous scores in [0, 1]."""
    model.eval()
    scores = []
    with torch.no_grad():
        for _, row in df.iterrows():
            batch = {col: [row[col]] for col in field_cols}
            tok = tokenize_dynamic(batch, tokenizer, field_cols)
            input_ids = torch.tensor(tok["input_ids"]).to(model.device)
            att_mask = torch.tensor(tok["attention_mask"]).to(model.device)
            logits = model(input_ids=input_ids, attention_mask=att_mask).logits

            if use_coral:
                probs = torch.sigmoid(logits)
                score = (0.5 * probs[0, 0] + 0.5 * probs[0, 1]).item()
            else:
                score = max(0.0, min(1.0, logits.squeeze(-1).item()))
            scores.append(score)
    return np.array(scores)


# =============================================================================
# THRESHOLD OPTIMIZATION
# =============================================================================
def optimize_global_thresholds(raw_scores, labels):
    """Grid-search T1, T2: below T1 -> 0.0, between -> 0.5, above T2 -> 1.0."""
    best_rmse, best_t1, best_t2 = float("inf"), 0.25, 0.75
    for t1 in np.arange(0.05, 0.50, 0.02):
        for t2 in np.arange(t1 + 0.05, 0.95, 0.02):
            preds = np.where(raw_scores < t1, 0.0, np.where(raw_scores <= t2, 0.5, 1.0))
            rmse = np.sqrt(mean_squared_error(labels, preds))
            if rmse < best_rmse:
                best_rmse, best_t1, best_t2 = rmse, t1, t2
    return best_t1, best_t2


def optimize_type_aware_thresholds(raw_scores, labels, is_ternary_flags):
    """
    Separate thresholds for binary vs ternary rubrics (Jannen improvement).

    Binary (is_ternary=False): only {0.0, 0.5} valid. Single threshold.
    Ternary (is_ternary=True): {0.0, 0.5, 1.0} valid. Two thresholds.
    """
    binary_mask = ~np.array(is_ternary_flags, dtype=bool)
    ternary_mask = np.array(is_ternary_flags, dtype=bool)

    best_t_bin, best_bin_rmse = 0.5, float("inf")
    if binary_mask.sum() > 0:
        for t in np.arange(0.0, 1.01, 0.02):
            preds = np.where(raw_scores[binary_mask] >= t, 0.5, 0.0)
            rmse = np.sqrt(mean_squared_error(labels[binary_mask], preds))
            if rmse < best_bin_rmse:
                best_bin_rmse, best_t_bin = rmse, t

    best_t1, best_t2, best_ter_rmse = 0.25, 0.75, float("inf")
    if ternary_mask.sum() > 0:
        for t1 in np.arange(0.0, 0.6, 0.02):
            for t2 in np.arange(t1 + 0.02, 1.01, 0.02):
                preds = np.where(raw_scores[ternary_mask] < t1, 0.0,
                        np.where(raw_scores[ternary_mask] <= t2, 0.5, 1.0))
                rmse = np.sqrt(mean_squared_error(labels[ternary_mask], preds))
                if rmse < best_ter_rmse:
                    best_ter_rmse, best_t1, best_t2 = rmse, t1, t2

    print(f"    Binary:  T={best_t_bin:.2f}  RMSE={best_bin_rmse:.4f}  (n={binary_mask.sum()})")
    print(f"    Ternary: T1={best_t1:.2f}, T2={best_t2:.2f}  RMSE={best_ter_rmse:.4f}  (n={ternary_mask.sum()})")
    return best_t_bin, best_t1, best_t2


def apply_type_aware_thresholds(raw_scores, is_ternary_flags, t_bin, t1_ter, t2_ter):
    """Apply rubric-type-specific thresholds to raw scores."""
    preds = np.zeros_like(raw_scores)
    for i, (score, is_ter) in enumerate(zip(raw_scores, is_ternary_flags)):
        if is_ter:
            preds[i] = 0.0 if score < t1_ter else (0.5 if score <= t2_ter else 1.0)
        else:
            preds[i] = 0.5 if score >= t_bin else 0.0
    return preds


# =============================================================================
# SINGLE FOLD TRAINING
# =============================================================================
def train_fold(model_name, train_df, val_df, fold, config, tb_writer=None):
    """
    Train one fold. Returns raw predictions and trainer eval metrics.

    Args:
        model_name: HuggingFace model path
        train_df, val_df: fold dataframes
        fold: fold number (1-indexed)
        config: experiment config dict
        tb_writer: TensorBoard SummaryWriter for this fold
    """
    lr         = config["lr"]
    unfreeze   = config["unfreeze"]
    epochs     = config["epochs"]
    field_cols = config["field_cols"]
    use_llrd   = config["use_llrd"]
    use_fgm    = config["use_fgm"]
    use_coral  = config["use_coral"]
    batch_size = config["batch_size"]
    grad_accum = config["grad_accum"]
    save_dir   = config.get("save_dir")

    hf_config = AutoConfig.from_pretrained(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name, config=hf_config)

    train_balanced = oversample_minority(train_df)

    def make_ds(df_in):
        d = df_in.copy()
        d["labels"] = d[SCORE_COL].astype(float)
        ds = Dataset.from_pandas(d[list(field_cols) + ["labels"]].reset_index(drop=True))
        ds = ds.map(lambda b: tokenize_dynamic(b, tokenizer, field_cols), batched=True)
        return ds.remove_columns(list(field_cols))

    train_ds = make_ds(train_balanced)
    val_ds = make_ds(val_df)

    # 2 outputs for CORAL, 1 for MSE
    hf_config.num_labels = 2 if use_coral else 1
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, config=hf_config, ignore_mismatched_sizes=True,
        torch_dtype=torch.float32,
    )

    # Gradient checkpointing saves VRAM for large models
    if "large" in model_name and hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable()

    unfreeze_top_layers(model, unfreeze)

    out_dir = f"/tmp/v10_fold_{fold}"

    # Optimizer
    total_steps = int(epochs * len(train_ds) / (batch_size * grad_accum))
    if use_llrd:
        param_groups = get_llrd_param_groups(model, base_lr=lr, lr_decay=0.88)
        optimizer = torch.optim.AdamW(param_groups)
    else:
        optimizer = torch.optim.AdamW(
            filter(lambda p: p.requires_grad, model.parameters()),
            lr=lr, weight_decay=0.01,
        )

    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(total_steps * 0.1),
        num_training_steps=total_steps,
    )

    use_bf16 = torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    use_fp16 = torch.cuda.is_available() and not use_bf16

    args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=lr,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=batch_size,
        gradient_accumulation_steps=grad_accum,
        num_train_epochs=epochs,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,       # Jannen: use best epoch, not final
        metric_for_best_model="rmse",
        greater_is_better=False,
        save_total_limit=2,
        logging_steps=10,
        report_to="none",                  # We handle TB via our custom callback
        seed=SEED,
        bf16=use_bf16,
        fp16=use_fp16,
        max_grad_norm=1.0,
    )

    # Trainer class and metrics
    fgm_eps = 0.5 if use_fgm else 0.0
    emb_name = "embeddings.word_embeddings"
    TrainerClass = CORALTrainer if use_coral else WeightedMSETrainer
    compute_fn = metrics_coral if use_coral else metrics_mse

    # Build callbacks
    callbacks = []
    if tb_writer:
        callbacks.append(EpochLossCallback(tb_writer))

    trainer = TrainerClass(
        model=model, args=args,
        train_dataset=train_ds, eval_dataset=val_ds,
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        compute_metrics=compute_fn,
        optimizers=(optimizer, scheduler),
        callbacks=callbacks,
        fgm_epsilon=fgm_eps,
        fgm_emb_name=emb_name,
    )

    trainer.train()

    best_ckpt = trainer.state.best_model_checkpoint
    eval_result = trainer.evaluate()
    print(f"  [Fold {fold}] Best ckpt: {best_ckpt}")
    print(f"  [Fold {fold}] Trainer eval: RMSE={eval_result['eval_rmse']:.4f}  Acc={eval_result['eval_rounded_accuracy']:.4f}")

    # Save fold model
    if save_dir:
        fold_path = os.path.join(save_dir, f"fold_{fold}")
        os.makedirs(fold_path, exist_ok=True)
        trainer.save_model(fold_path)
        tokenizer.save_pretrained(fold_path)
        print(f"  Saved to {fold_path}")

    # Raw predictions for threshold optimization
    train_raw = get_raw_predictions(model, train_df, tokenizer, field_cols, use_coral)
    val_raw = get_raw_predictions(model, val_df, tokenizer, field_cols, use_coral)

    del model, trainer, train_ds, val_ds
    gc.collect()
    torch.cuda.empty_cache()
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)

    return train_raw, val_raw, eval_result


# =============================================================================
# EXPERIMENT RUNNER
# =============================================================================
def run_experiment(df, experiment_name, model_name, config, group_by="answer_id", tb_base_dir="./tb_logs"):
    """
    Run full 5-fold CV experiment with global + type-aware threshold evaluation.

    Args:
        df: full dataframe
        experiment_name: name for logging and results
        model_name: HuggingFace model identifier
        config: experiment hyperparameters
        group_by: 'answer_id' or 'question_id' for GroupKFold grouping
        tb_base_dir: base directory for TensorBoard logs
    """
    print(f"\n{'=' * 70}")
    print(f"  EXPERIMENT: {experiment_name}")
    print(f"  Model: {model_name}")
    print(f"  LR={config['lr']}  unfreeze={config['unfreeze']}  epochs={config['epochs']}")
    print(f"  CORAL={config['use_coral']}  LLRD={config['use_llrd']}  FGM={config['use_fgm']}")
    print(f"  Fields: {config['field_cols']}")
    print(f"  GroupKFold by: {group_by}")
    print(f"  Split: 5-fold CV -> 80% train / 20% val per fold")
    print(f"{'=' * 70}")

    kf = GroupKFold(n_splits=N_FOLDS)
    groups = df[group_by]

    global_rmses, global_accs = [], []
    type_rmses, type_accs = [], []
    trainer_rmses, trainer_accs = [], []

    for fold, (tr_idx, va_idx) in enumerate(kf.split(df, groups=groups), 1):
        train_df = df.iloc[tr_idx].reset_index(drop=True)
        val_df = df.iloc[va_idx].reset_index(drop=True)

        # Verify no leakage on the grouping column
        train_groups = set(df.iloc[tr_idx][group_by])
        val_groups = set(df.iloc[va_idx][group_by])
        assert len(train_groups & val_groups) == 0, f"Leakage on {group_by}!"

        val_labels = val_df[SCORE_COL].values
        train_labels = train_df[SCORE_COL].values

        print(f"\n  FOLD {fold}/{N_FOLDS}  train={len(train_df)}  val={len(val_df)}")
        print(f"  Val dist: {dict(zip(*np.unique(val_labels, return_counts=True)))}")

        # TensorBoard writer for this fold
        tb_dir = os.path.join(tb_base_dir, experiment_name, f"fold_{fold}")
        os.makedirs(tb_dir, exist_ok=True)
        tb_writer = SummaryWriter(log_dir=tb_dir)

        train_raw, val_raw, eval_result = train_fold(
            model_name, train_df, val_df, fold, config, tb_writer
        )

        tb_writer.close()

        trainer_rmses.append(eval_result["eval_rmse"])
        trainer_accs.append(eval_result["eval_rounded_accuracy"])

        # Global thresholds
        t1_g, t2_g = optimize_global_thresholds(train_raw, train_labels)
        g_preds = np.where(val_raw < t1_g, 0.0, np.where(val_raw <= t2_g, 0.5, 1.0))
        g_rmse = np.sqrt(mean_squared_error(val_labels, g_preds))
        g_acc = np.mean(g_preds == val_labels)
        global_rmses.append(g_rmse)
        global_accs.append(g_acc)
        print(f"  [Global thresh]    Fold {fold}: RMSE={g_rmse:.4f}  Acc={g_acc:.4f}")

        # Type-aware thresholds
        has_ternary = "is_ternary" in val_df.columns
        if has_ternary:
            val_ter = val_df["is_ternary"].values
            train_ter = train_df["is_ternary"].values
            t_bin, t1_ter, t2_ter = optimize_type_aware_thresholds(train_raw, train_labels, train_ter)
            ta_preds = apply_type_aware_thresholds(val_raw, val_ter, t_bin, t1_ter, t2_ter)
            ta_rmse = np.sqrt(mean_squared_error(val_labels, ta_preds))
            ta_acc = np.mean(ta_preds == val_labels)
        else:
            ta_rmse, ta_acc = g_rmse, g_acc
        type_rmses.append(ta_rmse)
        type_accs.append(ta_acc)
        print(f"  [Type-aware]       Fold {fold}: RMSE={ta_rmse:.4f}  Acc={ta_acc:.4f}")

    # Summary
    print(f"\n{'=' * 70}")
    print(f"  RESULTS: {experiment_name} (group_by={group_by})")
    print(f"{'=' * 70}")
    for name, rmses, accs in [
        ("Trainer (direct eval)", trainer_rmses, trainer_accs),
        ("Global thresholds", global_rmses, global_accs),
        ("Type-aware thresholds", type_rmses, type_accs),
    ]:
        print(f"  {name:<30} RMSE={np.mean(rmses):.4f}+-{np.std(rmses):.4f}  Acc={np.mean(accs):.4f}+-{np.std(accs):.4f}")

    return {
        "experiment": experiment_name,
        "model": model_name,
        "group_by": group_by,
        "lr": config["lr"],
        "unfreeze": config["unfreeze"],
        "epochs": config["epochs"],
        "fields": str(config["field_cols"]),
        "use_coral": config["use_coral"],
        "use_llrd": config["use_llrd"],
        "use_fgm": config["use_fgm"],
        "batch_size": config["batch_size"],
        "grad_accum": config["grad_accum"],
        "trainer_rmse_mean": float(np.mean(trainer_rmses)),
        "trainer_rmse_std": float(np.std(trainer_rmses)),
        "trainer_acc_mean": float(np.mean(trainer_accs)),
        "global_rmse_mean": float(np.mean(global_rmses)),
        "global_rmse_std": float(np.std(global_rmses)),
        "global_acc_mean": float(np.mean(global_accs)),
        "type_rmse_mean": float(np.mean(type_rmses)),
        "type_rmse_std": float(np.std(type_rmses)),
        "type_acc_mean": float(np.mean(type_accs)),
        "fold_trainer_rmses": [float(x) for x in trainer_rmses],
        "fold_global_rmses": [float(x) for x in global_rmses],
        "fold_type_rmses": [float(x) for x in type_rmses],
    }


# =============================================================================
# EXPERIMENT DEFINITIONS
# =============================================================================
def get_experiments(save_dir=None):
    """
    Define ablation experiments.

    All use [rubric, question, answer] ordering, 20 epochs, v6 optimal HP.
    Each experiment name describes what is changed vs the full config.
    """
    field_cols = [RUBRIC_COL, QUESTION_COL, ANSWER_COL]

    large_full = {
        "lr": 5e-5,
        "unfreeze": 8,
        "epochs": 20,
        "field_cols": field_cols,
        "batch_size": 2,       # large model: 2 per device (VRAM limit)
        "grad_accum": 8,       # effective batch = 16
        "use_coral": True,
        "use_llrd": True,
        "use_fgm": True,
        "save_dir": save_dir,
    }

    return [
        # 1. Everything enabled (the hypothesis)
        ("full_config", "FacebookAI/xlm-roberta-large", {**large_full}),

        # 2. Ablation: remove LLRD
        ("no_llrd", "FacebookAI/xlm-roberta-large", {**large_full, "use_llrd": False}),

        # 3. Ablation: remove FGM
        ("no_fgm", "FacebookAI/xlm-roberta-large", {**large_full, "use_fgm": False}),

        # 4. Ablation: MSE instead of CORAL
        ("mse_loss", "FacebookAI/xlm-roberta-large", {**large_full, "use_coral": False}),

        # 5. Ablation: no LLRD and no FGM (just CORAL + good HP)
        ("no_llrd_no_fgm", "FacebookAI/xlm-roberta-large", {
            **large_full, "use_llrd": False, "use_fgm": False,
        }),

        # 6. Ablation: nothing from v8 (MSE, no LLRD, no FGM = v7 setup with v6 HP)
        ("vanilla_large", "FacebookAI/xlm-roberta-large", {
            **large_full, "use_coral": False, "use_llrd": False, "use_fgm": False,
        }),

        # 7. Base model comparison (same full config but base model)
        ("base_model_full", "FacebookAI/xlm-roberta-base", {
            **large_full, "batch_size": 8, "grad_accum": 2,
        }),
    ]


# =============================================================================
# MAIN
# =============================================================================
def main():
    parser = argparse.ArgumentParser(description="Investigation v10: ablation study")
    parser.add_argument("--data_dir", type=str, required=True,
                        help="Path to data directory with dataset folders")
    parser.add_argument("--save_dir", type=str, default="./saved_models/v10",
                        help="Directory for trained fold models")
    parser.add_argument("--results_file", type=str, default="./results/investigation_v10_results.csv",
                        help="CSV for results (supports resume)")
    parser.add_argument("--tb_dir", type=str, default="./tb_logs/v10",
                        help="TensorBoard log directory")
    parser.add_argument("--group_by", type=str, default="answer_id",
                        choices=["answer_id", "question_id"],
                        help="GroupKFold grouping column (default: answer_id)")
    parser.add_argument("--experiments", nargs="*", default=None,
                        help="Run only named experiments. Default: all.")
    parser.add_argument("--no_ternary_prefix", action="store_true",
                        help="Disable is_ternary prefix on rubric text")
    args = parser.parse_args()

    set_seed(SEED)
    t0 = time.time()

    gpu_name = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU (WARNING)"
    print(f"GPU: {gpu_name}")

    df = load_data(args.data_dir, use_ternary_prefix=not args.no_ternary_prefix)
    os.makedirs(os.path.dirname(args.results_file) or ".", exist_ok=True)

    # Resume support
    completed = set()
    all_results = []
    if os.path.exists(args.results_file):
        try:
            existing = pd.read_csv(args.results_file)
            for _, row in existing.iterrows():
                completed.add(row["experiment"])
                all_results.append(row.to_dict())
            print(f"\nResuming: {len(completed)} experiments already done")
        except Exception as e:
            print(f"\nCould not load existing results: {e}")

    experiments = get_experiments(save_dir=args.save_dir)

    if args.experiments:
        experiments = [(n, m, c) for n, m, c in experiments if n in args.experiments]
        print(f"\nSelected: {[n for n, _, _ in experiments]}")
    else:
        print(f"\nRunning all {len(experiments)} experiments")

    for exp_name, model_name, config in experiments:
        if exp_name in completed:
            print(f"\n>>> Skipping {exp_name} (already done)")
            continue

        result = run_experiment(
            df, exp_name, model_name, config,
            group_by=args.group_by,
            tb_base_dir=args.tb_dir,
        )
        all_results.append(result)
        pd.DataFrame(all_results).to_csv(args.results_file, index=False)
        print(f">>> Saved to {args.results_file}")

    # Final summary
    print(f"\n{'=' * 80}")
    print(f"ABLATION RESULTS (sorted by type-aware RMSE, group_by={args.group_by})")
    print(f"{'=' * 80}")
    rdf = pd.DataFrame(all_results).sort_values("type_rmse_mean")
    for _, r in rdf.iterrows():
        print(f"  {r['experiment']:<22} RMSE={r['type_rmse_mean']:.4f}+-{r.get('type_rmse_std', 0):.4f}  "
              f"Acc={r['type_acc_mean']:.4f}  CORAL={r.get('use_coral', True)}  "
              f"LLRD={r.get('use_llrd', True)}  FGM={r.get('use_fgm', True)}")

    print(f"\nPrevious bests for reference:")
    print(f"  v8 best  (base, CORAL+LLRD+FGM, 4 datasets): RMSE=0.2614  Acc=79.9%")
    print(f"  v7       (large, MSE, 3 datasets):            RMSE=0.2586  Acc=76.6%")
    print(f"  v6       (base, MSE, 3 datasets):             RMSE=0.2664  Acc=77.7%")

    elapsed = (time.time() - t0) / 60
    print(f"\nTotal runtime: {elapsed:.1f} minutes")


if __name__ == "__main__":
    main()