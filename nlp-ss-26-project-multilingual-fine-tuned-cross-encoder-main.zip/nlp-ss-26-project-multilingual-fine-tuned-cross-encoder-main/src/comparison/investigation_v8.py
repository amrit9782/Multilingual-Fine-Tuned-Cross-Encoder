# =============================================================================
# INVESTIGATION v8 — Unified Advanced RMSE Optimization Strategies
#
# Implements:
#   1. Dynamic Token Budgeting (avoids static truncation when fields are short)
#   2. Consistent Rank Logits (CORAL) Ordinal Regression Loss
#   3. Layer-wise Discriminative Learning Rate (LLRD)
#   4. Fast Gradient Method (FGM) Adversarial Training
#   5. Stable mDeBERTa-v3 & XLM-RoBERTa configurations
# =============================================================================

import os, random, html, warnings, shutil, ast, re, gc
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.utils import resample
from datasets import Dataset
from transformers import (
    AutoConfig, AutoTokenizer, AutoModelForSequenceClassification,
    TrainingArguments, Trainer, DataCollatorWithPadding,
    get_linear_schedule_with_warmup
)

warnings.filterwarnings("ignore")

# ── Models ────────────────────────────────────────────────────────────────────
MODELS = {
    "xlm-roberta-base": "FacebookAI/xlm-roberta-base",
    "mdeberta-v3-base": "microsoft/mdeberta-v3-base",
}

# ── Config ────────────────────────────────────────────────────────────────────
QUESTION_COL  = "question"
SOLUTION_COL  = "solution"
RUBRIC_COL    = "rubric"
ANSWER_COL    = "answer"
SCORE_COL     = "target_score"
ANSWER_ID_COL = "answer_id"

ALL_FIELD_COLS = [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL]

MAX_LENGTH = 512
BATCH_SIZE = 2
GRAD_ACCUM = 8
SEED       = 42
N_FOLDS    = 5

CLASS_WEIGHTS = {0.0: 1.0, 0.5: 1.0, 1.0: 1.0}


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(s)

set_seed(SEED)
os.makedirs("results", exist_ok=True)
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")


# ── Preprocessing & Dynamic Tokenization ──────────────────────────────────────
def normalize_text(text):
    if pd.isna(text): return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split())


def tokenize_dynamic(batch, tokenizer, field_cols, max_length=512):
    """
    Tokenize fields dynamically. If the combined sequence is too long,
    we prioritize keeping the entire rubric and question, and truncate the answer.
    """
    all_ids, all_masks = [], []
    special_tokens_count = len(field_cols) + 1  # [CLS] + [SEP] for each field
    
    for i in range(len(batch[field_cols[0]])):
        encoded_fields = {
            col: tokenizer.encode(batch[col][i], add_special_tokens=False)
            for col in field_cols
        }
        
        lengths = {col: len(tokens) for col, tokens in encoded_fields.items()}
        total_tokens = sum(lengths.values()) + special_tokens_count
        
        if total_tokens > max_length:
            allowed_budget = max_length - special_tokens_count
            rubric_len = lengths.get("rubric", 0)
            question_len = lengths.get("question", 0)
            solution_len = lengths.get("solution", 0)
            
            # Answer gets the remaining allowed tokens
            non_answer_len = rubric_len + question_len + solution_len
            if "answer" in encoded_fields:
                answer_budget = max(80, allowed_budget - non_answer_len)
                encoded_fields["answer"] = encoded_fields["answer"][:answer_budget]
                
            # If still over budget, truncate solution, then question
            new_total = sum(len(t) for t in encoded_fields.values()) + special_tokens_count
            if new_total > max_length and "solution" in encoded_fields:
                solution_budget = max(50, max_length - special_tokens_count - rubric_len - question_len - len(encoded_fields["answer"]))
                encoded_fields["solution"] = encoded_fields["solution"][:solution_budget]
                
            new_total = sum(len(t) for t in encoded_fields.values()) + special_tokens_count
            if new_total > max_length and "question" in encoded_fields:
                question_budget = max(30, max_length - special_tokens_count - rubric_len - len(encoded_fields["solution"]) - len(encoded_fields["answer"]))
                encoded_fields["question"] = encoded_fields["question"][:question_budget]
                
        # Build sequence: [CLS] field1 [SEP] field2 [SEP] ... fieldN [SEP]
        ids = [tokenizer.cls_token_id]
        for col in field_cols:
            ids += encoded_fields[col] + [tokenizer.sep_token_id]
            
        all_ids.append(ids)
        all_masks.append([1] * len(ids))
        
    return {"input_ids": all_ids, "attention_mask": all_masks}


def load_data():
    global CLASS_WEIGHTS
    datasets = ["WuS-WS25", "DAV-SS2425", "NLP-SS2425", "WuS-SS24"]
    data_dir = "/home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/data"
    
    dfs = []
    print("\n>>> Loading and merging datasets...")
    for dataset in datasets:
        path = os.path.join(data_dir, dataset)
        q = pd.read_csv(os.path.join(path, "questions.csv"))
        a = pd.read_csv(os.path.join(path, "answers.csv"))
        r = pd.read_csv(os.path.join(path, "rubrics.csv"))
        ar = pd.read_csv(os.path.join(path, "answer_rubrics.csv"))
        
        prefix = f"{dataset}_"
        for df in [q, a, r, ar]:
            if "question_id" in df.columns:
                df["question_id"] = prefix + df["question_id"].astype(str)
            if "answer_id" in df.columns:
                df["answer_id"] = prefix + df["answer_id"].astype(str)
            if "rubric_id" in df.columns:
                df["rubric_id"] = prefix + df["rubric_id"].astype(str)
        
        a = a.rename(columns={"score": "answer_total_score"})
        r = r.rename(columns={"score": "rubric_score"})
        
        merged = ar.merge(
            a[["question_id", "answer_id", "answer", "answer_total_score"]],
            on=["question_id", "answer_id"],
            how="left"
        )
        merged = merged.merge(
            r[["question_id", "rubric_id", "rubric", "rubric_score"]],
            on=["question_id", "rubric_id"],
            how="left"
        )
        merged = merged.merge(
            q[["question_id", "question", "solution", "max_score"]],
            on="question_id",
            how="left"
        )
        
        merged["target_score"] = merged["label"].astype(float) * merged["rubric_score"]
        
        final_columns = [
            "question_id", "answer_id", "rubric_id", "question", "solution",
            "rubric", "answer", "rubric_score", "label", "target_score",
            "answer_total_score", "max_score",
        ]
        merged = merged[final_columns]
        print(f"  {dataset}: {len(merged)} evaluations loaded")
        dfs.append(merged)
        
    df = pd.concat(dfs, ignore_index=True)
    print(f"Combined Dataset: {len(df)} samples")
    
    for col in ALL_FIELD_COLS:
        df[col] = df[col].apply(normalize_text)
        
    total = len(df)
    counts = df[SCORE_COL].value_counts().to_dict()
    CLASS_WEIGHTS = {s: total / counts.get(s, 1.0) for s in [0.0, 0.5, 1.0]}
    print("Computed CLASS_WEIGHTS:", CLASS_WEIGHTS)
    
    return df


def oversample_minority(df):
    classes = [df[(df[SCORE_COL] - s).abs() < 0.01] for s in [0.0, 0.5, 1.0]]
    max_size = max(len(c) for c in classes)
    balanced = pd.concat([
        resample(c, replace=True, n_samples=max_size, random_state=SEED)
        if len(c) < max_size else c
        for c in classes
    ])
    balanced = balanced.sample(frac=1, random_state=SEED).reset_index(drop=True)
    print(f"  [Oversampling] {len(df)} → {len(balanced)} training samples")
    return balanced


# ── FGM Adversarial Training Helper ──────────────────────────────────────────
class FGM:
    def __init__(self, model, epsilon=0.5, emb_name="word_embeddings"):
        self.model = model
        self.epsilon = epsilon
        self.emb_name = emb_name
        self.backup = {}

    def attack(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad and self.emb_name in name:
                self.backup[name] = param.data.clone()
                norm = torch.norm(param.grad)
                if norm != 0 and not torch.isnan(norm):
                    r_at = self.epsilon * param.grad / norm
                    param.data.add_(r_at)

    def restore(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad and self.emb_name in name:
                assert name in self.backup
                param.data.copy_(self.backup[name])
        self.backup = {}


# ── Weighted CORAL Trainer with FGM ──────────────────────────────────────────
class WeightedCORALTrainer(Trainer):
    def __init__(self, *args, fgm_epsilon=0.5, fgm_emb_name="word_embeddings", **kwargs):
        super().__init__(*args, **kwargs)
        self.fgm_epsilon = fgm_epsilon
        self.fgm_emb_name = fgm_emb_name

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        inputs_copy = dict(inputs)
        labels = inputs_copy.pop("labels")  # Targets in {0.0, 0.5, 1.0}
        outputs = model(**inputs_copy)
        logits = outputs.logits  # shape: (batch_size, 2)
        
        # Binary target thresholds: >= 0.5 and >= 1.0
        y1 = (labels >= 0.5).float()
        y2 = (labels >= 1.0).float()
        binary_targets = torch.stack([y1, y2], dim=-1)
        
        bce = nn.BCEWithLogitsLoss(reduction="none")
        loss = bce(logits, binary_targets)
        
        # Apply class weights
        weights = torch.ones_like(labels)
        for score_val, w in CLASS_WEIGHTS.items():
            mask = (labels - score_val).abs() < 0.01
            weights[mask] = w
            
        loss = (loss.sum(dim=-1) * weights).mean()
        return (loss, outputs) if return_outputs else loss

    def training_step(self, model, inputs, *args, **kwargs):
        model.train()
        inputs = self._prepare_inputs(inputs)
        
        loss = self.compute_loss(model, inputs)
        
        if self.args.gradient_accumulation_steps > 1:
            loss = loss / self.args.gradient_accumulation_steps
            
        self.accelerator.backward(loss)
        
        # Adversarial attack step
        if self.fgm_epsilon > 0:
            fgm = FGM(model, epsilon=self.fgm_epsilon, emb_name=self.fgm_emb_name)
            fgm.attack()
            
            loss_adv = self.compute_loss(model, inputs)
            if self.args.gradient_accumulation_steps > 1:
                loss_adv = loss_adv / self.args.gradient_accumulation_steps
            
            self.accelerator.backward(loss_adv)
            fgm.restore()
            
        return loss.detach()


# ── Layer-wise Discriminative Learning Rate (LLRD) ───────────────────────────
def get_optimizer_grouped_parameters(model, base_lr, weight_decay=0.01, lr_decay=0.9):
    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_layer_idx = -1
    for name, _ in model.named_parameters():
        match = layer_pattern.search(name)
        if match:
            max_layer_idx = max(max_layer_idx, int(match.group(1)))
            
    grouped_params = []
    
    # Classification head
    head_params = []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if any(hn in name for hn in ["classifier", "score", "pooler"]):
            head_params.append(param)
            
    if head_params:
        grouped_params.append({
            "params": head_params,
            "lr": base_lr,
            "weight_decay": weight_decay
        })
        
    # Encoder layers (decay learning rate back-to-front)
    for layer_idx in range(max_layer_idx, -1, -1):
        layer_lr = base_lr * (lr_decay ** (max_layer_idx - layer_idx))
        layer_params = []
        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue
            if f"layer.{layer_idx}." in name and not any(hn in name for hn in ["classifier", "score", "pooler"]):
                layer_params.append(param)
                
        if layer_params:
            grouped_params.append({
                "params": layer_params,
                "lr": layer_lr,
                "weight_decay": weight_decay
            })
            
    # Embeddings / remaining base parameters
    base_params = []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if not layer_pattern.search(name) and not any(hn in name for hn in ["classifier", "score", "pooler"]):
            base_params.append(param)
            
    if base_params:
        grouped_params.append({
            "params": base_params,
            "lr": base_lr * (lr_decay ** (max_layer_idx + 1)),
            "weight_decay": weight_decay
        })
        
    return grouped_params


# ── Metrics & Thresholding ───────────────────────────────────────────────────
def round_to_valid(s):
    v = np.array([0.0, 0.5, 1.0])
    return float(v[np.argmin(np.abs(v - s))])


def metrics_regression(eval_pred):
    # Standard regression metrics used during HF evaluate (continuous logit representation)
    preds, labels = eval_pred
    preds = preds.reshape(-1, 2)
    labels = labels.reshape(-1)
    
    if np.isnan(preds).any() or np.isnan(labels).any():
        return {"rmse": 999.0, "mae": 999.0, "rounded_accuracy": 0.0}
    
    # Apply sigmoid and compute expectation for continuous prediction
    probs = 1.0 / (1.0 + np.exp(-preds))
    continuous_preds = 0.5 * probs[:, 0] + 0.5 * probs[:, 1]
    
    rmse = np.sqrt(mean_squared_error(labels, continuous_preds))
    mae = mean_absolute_error(labels, continuous_preds)
    rounded = np.array([round_to_valid(p) for p in continuous_preds])
    rounded_accuracy = np.mean(rounded == labels)
    return {"rmse": rmse, "mae": mae, "rounded_accuracy": rounded_accuracy}


def unfreeze_top_layers(model, num_layers_to_unfreeze=4):
    for param in model.parameters():
        param.requires_grad = False

    head_names = ["classifier", "score", "pooler"]
    for name, module in model.named_modules():
        if any(hn in name for hn in head_names):
            for param in module.parameters():
                param.requires_grad = True

    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_layer_idx = -1
    for name, _ in model.named_parameters():
        match = layer_pattern.search(name)
        if match:
            max_layer_idx = max(max_layer_idx, int(match.group(1)))

    if max_layer_idx != -1:
        unfreeze_start_idx = max(0, max_layer_idx - num_layers_to_unfreeze + 1)
        for name, param in model.named_parameters():
            match = layer_pattern.search(name)
            if match and int(match.group(1)) >= unfreeze_start_idx:
                param.requires_grad = True
        print(f"  [Unfreezing] {num_layers_to_unfreeze}/{max_layer_idx+1} layers + head")
    else:
        params = list(model.named_parameters())
        for name, param in params[-int(len(params)*0.3):]:
            param.requires_grad = True
        print("  [Unfreezing] Top 30% of parameters")


def get_model_raw_predictions(model, df, tokenizer, field_cols):
    model.eval()
    raw_scores = []
    
    with torch.no_grad():
        for idx, row in df.iterrows():
            single_batch = {col: [row[col]] for col in field_cols}
            tokenized = tokenize_dynamic(single_batch, tokenizer, field_cols)
            
            input_ids = torch.tensor(tokenized["input_ids"]).to(model.device)
            attention_mask = torch.tensor(tokenized["attention_mask"]).to(model.device)
            
            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            logits = outputs.logits  # shape: (1, 2)
            probs = torch.sigmoid(logits)
            score = (0.5 * probs[0, 0] + 0.5 * probs[0, 1]).item()
            raw_scores.append(score)
            
    return np.array(raw_scores)


# ── Single Fold Training ──────────────────────────────────────────────────────
def train_fold(model_name, train_df, val_df, fold, model_key,
               lr, unfreeze_layers, epochs, field_cols, use_llrd=True, use_fgm=True,
               batch_size=2, grad_accum=8):
    config = AutoConfig.from_pretrained(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name, config=config)

    train_df_balanced = oversample_minority(train_df)

    def make_ds(df):
        d = df.copy()
        d["labels"] = d[SCORE_COL].astype(float)
        ds = Dataset.from_pandas(d[list(field_cols) + ["labels"]].reset_index(drop=True))
        ds = ds.map(
            lambda b: tokenize_dynamic(b, tokenizer, field_cols),
            batched=True
        )
        return ds.remove_columns(list(field_cols))

    train_ds = make_ds(train_df_balanced)
    val_ds   = make_ds(val_df)

    # Set up model for ordinal classification (2 thresholds outputs)
    config.num_labels = 2
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, config=config, ignore_mismatched_sizes=True,
        torch_dtype=torch.float32,
    )

    # Disable gradient checkpointing for base models to prevent NaN gradients in DeBERTa-v3
    if "large" in model_key and hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable()

    unfreeze_top_layers(model, num_layers_to_unfreeze=unfreeze_layers)

    out_dir = f"/tmp/fold_{model_key}_v8_{fold}"

    # Setup optimization
    num_update_steps_per_epoch = len(train_ds) // (batch_size * grad_accum)
    max_steps = int(epochs * num_update_steps_per_epoch)
    
    if use_llrd:
        grouped_params = get_optimizer_grouped_parameters(model, base_lr=lr, weight_decay=0.01, lr_decay=0.88)
        optimizer = torch.optim.AdamW(grouped_params)
    else:
        optimizer = torch.optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=lr, weight_decay=0.01)
        
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(max_steps * 0.1),
        num_training_steps=max_steps
    )

    use_bf16 = False
    use_fp16 = False
    if "deberta" not in model_key:
        use_bf16 = torch.cuda.is_available()
        use_fp16 = not torch.cuda.is_bf16_supported() and torch.cuda.is_available()

    args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=lr,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=batch_size,
        gradient_accumulation_steps=grad_accum,
        num_train_epochs=epochs,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="no",
        load_best_model_at_end=False,
        logging_steps=40,
        report_to="none",
        seed=SEED,
        bf16=use_bf16,
        fp16=use_fp16,
        max_grad_norm=1.0,
    )

    fgm_emb_name = "embeddings.word_embeddings"
    fgm_epsilon = 0.5 if use_fgm else 0.0

    trainer = WeightedCORALTrainer(
        model=model, args=args,
        train_dataset=train_ds, eval_dataset=val_ds,
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        compute_metrics=metrics_regression,
        optimizers=(optimizer, scheduler),
        fgm_epsilon=fgm_epsilon,
        fgm_emb_name=fgm_emb_name
    )

    trainer.train()

    # Raw predictions extraction (continuous expectation in [0, 1])
    train_raw = get_model_raw_predictions(model, train_df, tokenizer, field_cols)
    train_labels = train_df[SCORE_COL].values

    # Optimize prediction thresholds on the training set
    best_t1, best_t2 = 0.25, 0.75
    best_train_rmse = float("inf")
    for t1 in np.arange(0.1, 0.45, 0.02):
        for t2 in np.arange(t1 + 0.1, 0.9, 0.02):
            preds = np.where(train_raw < t1, 0.0,
                    np.where(train_raw <= t2, 0.5, 1.0))
            rmse = np.sqrt(mean_squared_error(train_labels, preds))
            if rmse < best_train_rmse:
                best_train_rmse = rmse
                best_t1, best_t2 = t1, t2

    print(f"  [Thresholds] T1={best_t1:.2f}, T2={best_t2:.2f} (train RMSE={best_train_rmse:.4f})")

    # Evaluate validation split with optimized thresholds
    val_raw = get_model_raw_predictions(model, val_df, tokenizer, field_cols)
    val_labels = val_df[SCORE_COL].values

    val_preds = np.where(val_raw < best_t1, 0.0,
                np.where(val_raw <= best_t2, 0.5, 1.0))

    eval_rmse = np.sqrt(mean_squared_error(val_labels, val_preds))
    eval_mae = mean_absolute_error(val_labels, val_preds)
    eval_accuracy = np.mean(val_preds == val_labels)

    print(f"  [Fold {fold}] Acc={eval_accuracy:.4f} RMSE={eval_rmse:.4f}")

    del model, trainer, train_ds, val_ds
    gc.collect()
    torch.cuda.empty_cache()
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)

    return eval_rmse, eval_mae, eval_accuracy


# ── CV Runner ─────────────────────────────────────────────────────────────────
def run_experiment(model_key, model_name, df, lr, unfreeze_layers, epochs,
                   field_cols, experiment_name, use_llrd=True, use_fgm=True,
                   batch_size=2, grad_accum=8, lowercase=True):
    print(f"\n{'='*70}")
    print(f"  {experiment_name}")
    print(f"  {model_key} | lr={lr} | unfreeze={unfreeze_layers} | "
          f"epochs={epochs} | LLRD={use_llrd} | FGM={use_fgm} | batch={batch_size} | accum={grad_accum} | lowercase={lowercase}")
    print(f"{'='*70}")

    # Conditionally lowercase the fields for this experiment
    if lowercase:
        df = df.copy()
        for col in field_cols:
            df[col] = df[col].astype(str).str.lower()

    kf = GroupKFold(n_splits=N_FOLDS)
    groups = df[ANSWER_ID_COL]
    rmses, maes, accs = [], [], []

    for fold, (tr_idx, va_idx) in enumerate(kf.split(df, groups=groups), 1):
        train_df = df.iloc[tr_idx].reset_index(drop=True)
        val_df = df.iloc[va_idx].reset_index(drop=True)

        print(f"\n── Fold {fold}/{N_FOLDS} ── (train={len(train_df)}, val={len(val_df)})")
        rmse, mae, acc = train_fold(
            model_name, train_df, val_df, fold, model_key,
            lr, unfreeze_layers, epochs, field_cols, use_llrd, use_fgm,
            batch_size, grad_accum
        )
        rmses.append(rmse); maes.append(mae); accs.append(acc)

    mean_rmse = np.mean(rmses)
    std_rmse = np.std(rmses)
    mean_acc = np.mean(accs)
    std_acc = np.std(accs)
    
    print(f"\n[OK] {experiment_name}  "
          f"RMSE: {mean_rmse:.4f}±{std_rmse:.4f}  "
          f"Acc: {mean_acc:.4f}±{std_acc:.4f}")

    return {
        "experiment": experiment_name,
        "model": model_key,
        "lr": lr,
        "unfreeze_layers": unfreeze_layers,
        "epochs": epochs,
        "fields": str(list(field_cols)),
        "use_llrd": use_llrd,
        "use_fgm": use_fgm,
        "lowercase": lowercase,
        "rmse_mean": mean_rmse, "rmse_std": std_rmse,
        "mae_mean": np.mean(maes),
        "acc_mean": mean_acc, "acc_std": std_acc,
        "fold_rmses": rmses, "fold_accs": accs,
    }


if __name__ == "__main__":
    df = load_data()
    all_results = []
    script_dir = os.path.dirname(os.path.abspath(__file__))
    results_file = os.path.abspath(os.path.join(script_dir, "../results/investigation_v8_results.csv"))

    # Load existing results for resuming
    completed_runs = set()
    if os.path.exists(results_file):
        try:
            existing_df = pd.read_csv(results_file)
            for _, row in existing_df.iterrows():
                res_dict = row.to_dict()
                for col in ["fold_rmses", "fold_accs"]:
                    if col in res_dict and isinstance(res_dict[col], str):
                        try:
                            # Replace np.float64 wrappers before parsing
                            cleaned_str = res_dict[col].replace("np.float64(", "").replace(")", "")
                            res_dict[col] = ast.literal_eval(cleaned_str)
                        except Exception:
                            pass
                completed_runs.add((res_dict["model"], res_dict["experiment"]))
                all_results.append(res_dict)
            print(f"\n>>> Loaded {len(completed_runs)} completed experiments from {results_file}.")
        except Exception as e:
            print(f"\n>>> Could not load existing results: {e}. Starting fresh.")

    # Define optimization experiments to compare improvements
    experiments = [
        # 1. Base model configuration with Rubric-Answer (RA) layout + optimizations (uncased)
        {
            "name": "base_ra_optimizations",
            "model": "xlm-roberta-base",
            "lr": 2e-5,
            "unfreeze": 6,
            "epochs": 15,
            "fields": [RUBRIC_COL, ANSWER_COL],
            "use_llrd": True,
            "use_fgm": True,
            "batch_size": 8,
            "grad_accum": 2,
            "lowercase": True
        },
        # 2. Base model configuration with Rubric-Question-Answer (RQA) layout + optimizations (uncased)
        {
            "name": "base_all_optimizations",
            "model": "xlm-roberta-base",
            "lr": 2e-5,
            "unfreeze": 6,
            "epochs": 15,
            "fields": [RUBRIC_COL, QUESTION_COL, ANSWER_COL],
            "use_llrd": True,
            "use_fgm": True,
            "batch_size": 8,
            "grad_accum": 2,
            "lowercase": True
        },
        # 3. Deberta-v3-base stabilized configuration (FP32, no FGM, unfreeze 6 layers) (uncased)
        {
            "name": "mdeberta_v3_base_stable",
            "model": "mdeberta-v3-base",
            "lr": 5e-6,
            "unfreeze": 6,
            "epochs": 12,
            "fields": [RUBRIC_COL, QUESTION_COL, ANSWER_COL],
            "use_llrd": True,
            "use_fgm": False,
            "batch_size": 4,
            "grad_accum": 4,
            "lowercase": True
        },
        # 4. Base model configuration with Rubric-Answer (RA) layout + optimizations (cased)
        {
            "name": "base_ra_optimizations_cased",
            "model": "xlm-roberta-base",
            "lr": 2e-5,
            "unfreeze": 6,
            "epochs": 15,
            "fields": [RUBRIC_COL, ANSWER_COL],
            "use_llrd": True,
            "use_fgm": True,
            "batch_size": 8,
            "grad_accum": 2,
            "lowercase": False
        },
        # 5. Base model configuration with Rubric-Question-Answer (RQA) layout + optimizations (cased)
        {
            "name": "base_all_optimizations_cased",
            "model": "xlm-roberta-base",
            "lr": 2e-5,
            "unfreeze": 6,
            "epochs": 15,
            "fields": [RUBRIC_COL, QUESTION_COL, ANSWER_COL],
            "use_llrd": True,
            "use_fgm": True,
            "batch_size": 8,
            "grad_accum": 2,
            "lowercase": False
        },
        # 6. Deberta-v3-base stabilized configuration (FP32, no FGM, unfreeze 6 layers) (cased)
        {
            "name": "mdeberta_v3_base_stable_cased",
            "model": "mdeberta-v3-base",
            "lr": 5e-6,
            "unfreeze": 6,
            "epochs": 12,
            "fields": [RUBRIC_COL, QUESTION_COL, ANSWER_COL],
            "use_llrd": True,
            "use_fgm": False,
            "batch_size": 4,
            "grad_accum": 4,
            "lowercase": False
        },
        # 7. Base model configuration with Rubric-Answer (RA) layout + optimizations (cased, no LLRD, no FGM)
        {
            "name": "base_ra_optimizations_cased_no_llrd_no_fgm",
            "model": "xlm-roberta-base",
            "lr": 2e-5,
            "unfreeze": 6,
            "epochs": 15,
            "fields": [RUBRIC_COL, ANSWER_COL],
            "use_llrd": False,
            "use_fgm": False,
            "batch_size": 8,
            "grad_accum": 2,
            "lowercase": False
        },
        # 8. Base model configuration with Rubric-Question-Answer (RQA) layout + optimizations (cased, no LLRD, no FGM)
        {
            "name": "base_all_optimizations_cased_no_llrd_no_fgm",
            "model": "xlm-roberta-base",
            "lr": 2e-5,
            "unfreeze": 6,
            "epochs": 15,
            "fields": [RUBRIC_COL, QUESTION_COL, ANSWER_COL],
            "use_llrd": False,
            "use_fgm": False,
            "batch_size": 8,
            "grad_accum": 2,
            "lowercase": False
        },
        # 9. Deberta-v3-base stabilized configuration (FP32, unfreeze 6 layers) (cased, no LLRD, no FGM)
        {
            "name": "mdeberta_v3_base_stable_cased_no_llrd_no_fgm",
            "model": "mdeberta-v3-base",
            "lr": 5e-6,
            "unfreeze": 6,
            "epochs": 12,
            "fields": [RUBRIC_COL, QUESTION_COL, ANSWER_COL],
            "use_llrd": False,
            "use_fgm": False,
            "batch_size": 4,
            "grad_accum": 4,
            "lowercase": False
        }
    ]

    print(f"\n>>> Running {len(experiments)} advanced optimization experiments...")

    for exp in experiments:
        key = (exp["model"], exp["name"])
        if key in completed_runs:
            print(f"\n>>> Skipping {exp['model']}/{exp['name']} — already done.")
            continue

        res = run_experiment(
            model_key=exp["model"],
            model_name=MODELS[exp["model"]],
            df=df,
            lr=exp["lr"],
            unfreeze_layers=exp["unfreeze"],
            epochs=exp["epochs"],
            field_cols=exp["fields"],
            experiment_name=exp["name"],
            use_llrd=exp["use_llrd"],
            use_fgm=exp["use_fgm"],
            batch_size=exp["batch_size"],
            grad_accum=exp["grad_accum"],
            lowercase=exp["lowercase"]
        )
        all_results.append(res)
        pd.DataFrame(all_results).to_csv(results_file, index=False)
        print(f">>> Saved progress to {results_file}")

    print("\n" + "="*80)
    print("FINAL RESULTS — investigation_v8")
    print("="*80)
    rdf = pd.DataFrame(all_results).sort_values("rmse_mean")
    print(rdf[["experiment", "model", "rmse_mean", "rmse_std", "acc_mean"]].to_string(index=False))
