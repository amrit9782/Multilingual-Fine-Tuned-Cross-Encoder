# =============================================================================
# INVESTIGATION v11 — Advanced Semantic Preprocessing & Target Optimization
#
# Implements:
#   1. Dynamic Token Budgeting (avoids static truncation when fields are short)
#   2. Consistent Rank Logits (CORAL) Ordinal Regression Loss
#   3. Layer-wise Discriminative Learning Rate (LLRD)
#   4. Fast Gradient Method (FGM) Adversarial Training
#   5. Stable mDeBERTa-v3 & XLM-RoBERTa configurations
#   6. Automated Training/Validation Loss Curve Plotting Across Folds
#   7. Target Shift: Trains directly on semantic 'label' instead of scaled 'target_score'
#   8. Contradiction Resolution: Cleans conflicting annotator labels in training
#   9. Expanded Math Preprocessing: Translates 21 distinct LaTeX functions to plain text
#  10. Dynamic Augmentation Loading: Automatically integrates back-translated data if present
# =============================================================================

import os, random, html, warnings, shutil, ast, re, gc
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.utils import resample
from datasets import Dataset
from transformers import (
    AutoConfig, AutoTokenizer, AutoModelForSequenceClassification,
    TrainingArguments, Trainer, DataCollatorWithPadding,
    get_linear_schedule_with_warmup, EarlyStoppingCallback
)

warnings.filterwarnings("ignore")

# ── Models ────────────────────────────────────────────────────────────────────
MODELS = {
    "xlm-roberta-base": "FacebookAI/xlm-roberta-base",
    "mdeberta-v3-base": "microsoft/mdeberta-v3-base",
}

# ── Config ────────────────────────────────────────────────────────────────────
QUESTION_COL  = "question"
SOLUTION_COL  = "solution"
RUBRIC_COL    = "rubric"
ANSWER_COL    = "answer"
SCORE_COL     = "target_score"
TARGET_COL    = "label"
ANSWER_ID_COL = "answer_id"
QUESTION_ID_COL = "question_id"

# Choose grouping column to validate against:
# - ANSWER_ID_COL (same questions, new student answers)
# - QUESTION_ID_COL (completely unseen new questions, zero-shot grading)
GROUP_BY_COL  = ANSWER_ID_COL

ALL_FIELD_COLS = [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL]

MAX_LENGTH = 512
BATCH_SIZE = 32
GRAD_ACCUM = 1
SEED       = 42
N_FOLDS    = 5

# Global optimization configs
USE_LLRD      = True
USE_FGM       = False  # Set to True to test FGM speed/performance
GRID_MODEL    = "xlm-roberta-base"  # "xlm-roberta-base" or "mdeberta-v3-base"
WEIGHT_DECAY  = 0.01
PATIENCE      = 3


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(s)

set_seed(SEED)
os.makedirs("results", exist_ok=True)
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")


# ── Preprocessing & Dynamic Tokenization ──────────────────────────────────────
def normalize_text(text):
    if pd.isna(text): return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    # Strip Jupyter boilerplate template text
    text = re.sub(r"-?\s*This cell supports \*Markdown\* and Math:\s*(\$\s*\\*alpha\^2\s*\$)?\s*", "", text, flags=re.IGNORECASE)
    # Translate common LaTeX symbols/functions to plain text
    latex_replacements = {
        "\\frac{": " ( ",
        "}{": " ) / ( ",
        "\\sigma": "sigma",
        "\\alpha": "alpha",
        "\\beta": "beta",
        "\\gamma": "gamma",
        "\\mu": "mu",
        "\\rho": "rho",
        "\\Sigma": "Sigma",
        "\\Omega": "Omega",
        "\\sum": "sum",
        "\\dots": "...",
        "\\cdot": " * ",
        "\\geq": " >= ",
        "\\ge": " >= ",
        "\\leq": " <= ",
        "\\le": " <= ",
        "\\implies": " => ",
        "\\in": " in ",
        "\\infty": "infinity",
        "\\cup": " union ",
        "\\cap": " intersection ",
        "\\emptyset": "empty_set",
        "\\space": " ",
        "\\text": " ",
        "\\B": "B",
        "$$": " ",
        "$": " ",
        "{": " ( ",
        "}": " ) "
    }
    for pattern, replacement in latex_replacements.items():
        text = text.replace(pattern, replacement)
    # Pad mathematical operators with spaces (collapses duplicate spaces automatically below)
    for op in ["=", "+", "*", "/"]:
        text = text.replace(op, f" {op} ")
    return " ".join(text.strip().split())


def tokenize_dynamic(batch, tokenizer, field_cols, max_length=MAX_LENGTH):
    """
    Tokenize fields dynamically. If the combined sequence is too long,
    we prioritize keeping the entire rubric and question, and truncate the answer.
    """
    all_ids, all_masks = [], []
    special_tokens_count = len(field_cols) + 1  # [CLS] + [SEP] for each field
    
    for i in range(len(batch[field_cols[0]])):
        encoded_fields = {
            col: tokenizer.encode(batch[col][i], add_special_tokens=False)
            for col in field_cols
        }
        
        lengths = {col: len(tokens) for col, tokens in encoded_fields.items()}
        total_tokens = sum(lengths.values()) + special_tokens_count
        
        if total_tokens > max_length:
            allowed_budget = max_length - special_tokens_count
            rubric_len = lengths.get(RUBRIC_COL, 0)
            question_len = lengths.get(QUESTION_COL, 0)
            solution_len = lengths.get(SOLUTION_COL, 0)
            
            # Answer gets the remaining allowed tokens
            non_answer_len = rubric_len + question_len + solution_len
            if ANSWER_COL in encoded_fields:
                answer_budget = max(80, allowed_budget - non_answer_len)
                encoded_fields[ANSWER_COL] = encoded_fields[ANSWER_COL][:answer_budget]
                
            # If still over budget, truncate solution, then question
            new_total = sum(len(t) for t in encoded_fields.values()) + special_tokens_count
            if new_total > max_length and SOLUTION_COL in encoded_fields:
                answer_len = len(encoded_fields[ANSWER_COL]) if ANSWER_COL in encoded_fields else 0
                solution_budget = max(50, max_length - special_tokens_count - rubric_len - question_len - answer_len)
                encoded_fields[SOLUTION_COL] = encoded_fields[SOLUTION_COL][:solution_budget]
                
            new_total = sum(len(t) for t in encoded_fields.values()) + special_tokens_count
            if new_total > max_length and QUESTION_COL in encoded_fields:
                answer_len = len(encoded_fields[ANSWER_COL]) if ANSWER_COL in encoded_fields else 0
                solution_len = len(encoded_fields[SOLUTION_COL]) if SOLUTION_COL in encoded_fields else 0
                question_budget = max(30, max_length - special_tokens_count - rubric_len - solution_len - answer_len)
                encoded_fields[QUESTION_COL] = encoded_fields[QUESTION_COL][:question_budget]
                
        # Build sequence: [CLS] field1 [SEP] field2 [SEP] ... fieldN [SEP]
        ids = [tokenizer.cls_token_id]
        for col in field_cols:
            ids += encoded_fields[col] + [tokenizer.sep_token_id]
            
        all_ids.append(ids)
        all_masks.append([1] * len(ids))
        
    return {"input_ids": all_ids, "attention_mask": all_masks}


def round_to_valid(s):
    v = np.array([0.0, 0.5, 1.0])
    return float(v[np.argmin(np.abs(v - s))])


def load_data(load_augmented=True):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.abspath(os.path.join(script_dir, "../../data"))
    aug_path = os.path.join(data_dir, "augmented_dataset.csv")
    
    if os.path.exists(aug_path):
        print(f"\n>>> Loading dataset from {aug_path}...")
        df = pd.read_csv(aug_path)
        for col in ALL_FIELD_COLS:
            df[col] = df[col].fillna("").astype(str).apply(normalize_text)
        if not load_augmented:
            df = df[~df[ANSWER_ID_COL].str.contains("_aug_backtrans_", na=False)].reset_index(drop=True)
            print(f"  Filtered to original dataset: {len(df)} samples")
        else:
            print(f"  Loaded full augmented dataset: {len(df)} samples")
        return df

    datasets = ["WuS-WS25", "DAV-SS2425", "NLP-SS2425", "WuS-SS24"]
    
    dfs = []
    print("\n>>> Loading and merging datasets...")
    for dataset in datasets:
        path = os.path.join(data_dir, dataset)
        q = pd.read_csv(os.path.join(path, "questions.csv"))
        a = pd.read_csv(os.path.join(path, "answers.csv"))
        r = pd.read_csv(os.path.join(path, "rubrics.csv"))
        ar = pd.read_csv(os.path.join(path, "answer_rubrics.csv"))
        
        prefix = f"{dataset}_"
        for df in [q, a, r, ar]:
            if QUESTION_ID_COL in df.columns:
                df[QUESTION_ID_COL] = prefix + df[QUESTION_ID_COL].astype(str)
            if ANSWER_ID_COL in df.columns:
                df[ANSWER_ID_COL] = prefix + df[ANSWER_ID_COL].astype(str)
            if "rubric_id" in df.columns:
                df["rubric_id"] = prefix + df["rubric_id"].astype(str)
        
        a = a.rename(columns={"score": "answer_total_score"})
        r = r.rename(columns={"score": "rubric_score"})
        
        merged = ar.merge(
            a[[QUESTION_ID_COL, ANSWER_ID_COL, ANSWER_COL, "answer_total_score"]],
            on=[QUESTION_ID_COL, ANSWER_ID_COL],
            how="left"
        )
        merged = merged.merge(
            r[[QUESTION_ID_COL, "rubric_id", RUBRIC_COL, "rubric_score"]],
            on=[QUESTION_ID_COL, "rubric_id"],
            how="left"
        )
        merged = merged.merge(
            q[[QUESTION_ID_COL, QUESTION_COL, SOLUTION_COL, "max_score"]],
            on=QUESTION_ID_COL,
            how="left"
        )
        
        merged[SCORE_COL] = merged["label"].astype(float) * merged["rubric_score"]
        
        final_columns = [
            QUESTION_ID_COL, ANSWER_ID_COL, "rubric_id", QUESTION_COL, SOLUTION_COL,
            RUBRIC_COL, ANSWER_COL, "rubric_score", "label", SCORE_COL,
            "answer_total_score", "max_score",
        ]
        merged = merged[final_columns]
        print(f"  {dataset}: {len(merged)} evaluations loaded")
        dfs.append(merged)
        
    df = pd.concat(dfs, ignore_index=True)
    print(f"Combined Dataset: {len(df)} samples")
    
    for col in ALL_FIELD_COLS:
        df[col] = df[col].apply(normalize_text)
        
    # Clean contradictory labels using majority consensus
    print(">>> Reconciling contradictory label annotations...")
    mean_labels = df.groupby(['answer', 'rubric'])['label'].transform('mean')
    df['label'] = mean_labels.apply(round_to_valid)
    
    # Recalculate target scores based on reconciled labels
    df[SCORE_COL] = df['label'].astype(float) * df['rubric_score'].astype(float)
    
    return df


def oversample_minority(df):
    unique_labels = df[TARGET_COL].unique()
    classes = [df[(df[TARGET_COL] - s).abs() < 0.01] for s in unique_labels]
    classes = [c for c in classes if len(c) > 0]
    if not classes:
        return df
    max_size = max(len(c) for c in classes)
    balanced = pd.concat([
        resample(c, replace=True, n_samples=max_size, random_state=SEED)
        if len(c) < max_size else c
        for c in classes
    ])
    balanced = balanced.sample(frac=1, random_state=SEED).reset_index(drop=True)
    print(f"  [Oversampling] {len(df)} → {len(balanced)} training samples")
    return balanced


# ── FGM Adversarial Training Helper ──────────────────────────────────────────
class FGM:
    def __init__(self, model, epsilon=0.5, emb_name="word_embeddings"):
        self.epsilon = epsilon
        self.backup = {}
        self.emb_param = None
        self.emb_name_matched = None
        
        # Cache the target embedding parameter once at initialization
        for name, param in model.named_parameters():
            if emb_name in name:
                self.emb_param = param
                self.emb_name_matched = name
                break
        
        if self.emb_param is None and epsilon > 0:
            warnings.warn(f"FGM target embedding parameter containing '{emb_name}' was not found in the model.")

    def attack(self):
        if self.emb_param is not None:
            if not self.emb_param.requires_grad:
                warnings.warn(f"FGM target embedding parameter '{self.emb_name_matched}' does not require gradients. Skipping FGM attack.")
                return
            self.backup[self.emb_name_matched] = self.emb_param.data.clone()
            norm = torch.norm(self.emb_param.grad)
            if norm != 0 and not torch.isnan(norm):
                r_at = self.epsilon * self.emb_param.grad / norm
                self.emb_param.data.add_(r_at)

    def restore(self):
        if self.emb_param is not None:
            if not self.emb_param.requires_grad:
                return
            assert self.emb_name_matched in self.backup
            self.emb_param.data.copy_(self.backup[self.emb_name_matched])
            self.backup = {}


# ── Weighted CORAL Trainer with FGM ──────────────────────────────────────────
class WeightedCORALTrainer(Trainer):
    def __init__(self, *args, fgm_epsilon=0.0, fgm_emb_name="word_embeddings", **kwargs):
        super().__init__(*args, **kwargs)
        self.fgm_epsilon = fgm_epsilon
        self.fgm_emb_name = fgm_emb_name
        self.fgm = FGM(self.model, epsilon=fgm_epsilon, emb_name=fgm_emb_name)
        self.bce_loss = nn.BCEWithLogitsLoss(reduction="none")

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        inputs_copy = dict(inputs)
        labels = inputs_copy.pop("labels")  # Targets in {0.0, 0.5, 1.0}
        outputs = model(**inputs_copy)
        logits = outputs.logits  # shape: (batch_size, 2)
        
        # Binary target thresholds: >= 0.5 and >= 1.0
        y1 = (labels >= 0.5).float()
        y2 = (labels >= 1.0).float()
        binary_targets = torch.stack([y1, y2], dim=-1)
        
        loss = self.bce_loss(logits, binary_targets)
        loss = loss.sum(dim=-1).mean()
        return (loss, outputs) if return_outputs else loss

    def training_step(self, model, inputs, *args, **kwargs):
        model.train()
        inputs = self._prepare_inputs(inputs)
        
        loss = self.compute_loss(model, inputs)
        
        if self.args.gradient_accumulation_steps > 1:
            loss = loss / self.args.gradient_accumulation_steps
            
        self.accelerator.backward(loss)
        
        # Adversarial attack step
        if self.fgm_epsilon > 0 and self.fgm.emb_param is not None:
            self.fgm.attack()
            
            loss_adv = self.compute_loss(model, inputs)
            if self.args.gradient_accumulation_steps > 1:
                loss_adv = loss_adv / self.args.gradient_accumulation_steps
            
            self.accelerator.backward(loss_adv)
            self.fgm.restore()
            
        return loss.detach()


# ── Layer-wise Discriminative Learning Rate (LLRD) ───────────────────────────
def get_optimizer_grouped_parameters(model, base_lr, weight_decay=WEIGHT_DECAY, lr_decay=0.9):
    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_layer_idx = -1
    for name, _ in model.named_parameters():
        match = layer_pattern.search(name)
        if match:
            max_layer_idx = max(max_layer_idx, int(match.group(1)))
            
    grouped_params = []
    
    # Classification head
    head_params = []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if any(hn in name for hn in ["classifier", "score", "pooler"]):
            head_params.append(param)
            
    if head_params:
        grouped_params.append({
            "params": head_params,
            "lr": base_lr,
            "weight_decay": weight_decay
        })
        
    # Encoder layers (decay learning rate back-to-front)
    for layer_idx in range(max_layer_idx, -1, -1):
        layer_lr = base_lr * (lr_decay ** (max_layer_idx - layer_idx))
        layer_params = []
        for name, param in model.named_parameters():
            if not param.requires_grad:
                continue
            if f"layer.{layer_idx}." in name and not any(hn in name for hn in ["classifier", "score", "pooler"]):
                layer_params.append(param)
                
        if layer_params:
            grouped_params.append({
                "params": layer_params,
                "lr": layer_lr,
                "weight_decay": weight_decay
            })
            
    # Embeddings / remaining base parameters
    base_params = []
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if not layer_pattern.search(name) and not any(hn in name for hn in ["classifier", "score", "pooler"]):
            base_params.append(param)
            
    if base_params:
        grouped_params.append({
            "params": base_params,
            "lr": base_lr * (lr_decay ** (max_layer_idx + 1)),
            "weight_decay": weight_decay
        })
        
    return grouped_params


# Removed duplicate definition of round_to_valid from here.


def metrics_regression(eval_pred):
    # Standard regression metrics used during HF evaluate (continuous logit representation)
    preds, labels = eval_pred
    preds = preds.reshape(-1, 2)
    labels = labels.reshape(-1)
    
    if np.isnan(preds).any() or np.isnan(labels).any():
        return {"rmse": 999.0, "mae": 999.0, "rounded_accuracy": 0.0}
    
    # Apply sigmoid and compute expectation for continuous prediction
    probs = 1.0 / (1.0 + np.exp(-preds))
    continuous_preds = 0.5 * probs[:, 0] + 0.5 * probs[:, 1]
    
    rmse = np.sqrt(mean_squared_error(labels, continuous_preds))
    mae = mean_absolute_error(labels, continuous_preds)
    rounded = np.array([round_to_valid(p) for p in continuous_preds])
    rounded_accuracy = np.mean(rounded == labels)
    return {"rmse": rmse, "mae": mae, "rounded_accuracy": rounded_accuracy}


def unfreeze_top_layers(model, num_layers_to_unfreeze=4, unfreeze_embeddings=False):
    for param in model.parameters():
        param.requires_grad = False

    head_names = ["classifier", "score", "pooler"]
    for name, module in model.named_modules():
        if any(hn in name for hn in head_names):
            for param in module.parameters():
                param.requires_grad = True

    # Unfreeze word embeddings if FGM is enabled so they can receive perturbations
    if unfreeze_embeddings:
        for name, param in model.named_parameters():
            if "embeddings.word_embeddings" in name:
                param.requires_grad = True
                print("  [Unfreezing] Word embeddings for FGM attack")

    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_layer_idx = -1
    for name, _ in model.named_parameters():
        match = layer_pattern.search(name)
        if match:
            max_layer_idx = max(max_layer_idx, int(match.group(1)))

    if max_layer_idx != -1:
        unfreeze_start_idx = max(0, max_layer_idx - num_layers_to_unfreeze + 1)
        for name, param in model.named_parameters():
            match = layer_pattern.search(name)
            if match and int(match.group(1)) >= unfreeze_start_idx:
                param.requires_grad = True
        print(f"  [Unfreezing] {num_layers_to_unfreeze}/{max_layer_idx+1} layers + head")
    else:
        params = list(model.named_parameters())
        for name, param in params[-int(len(params)*0.3):]:
            param.requires_grad = True
        print("  [Unfreezing] Top 30% of parameters")


def get_model_raw_predictions(model, df, tokenizer, field_cols, batch_size=32):
    model.eval()
    raw_scores = []
    
    # Create dataset & tokenize in batches
    ds = Dataset.from_pandas(df[list(field_cols)].reset_index(drop=True))
    ds = ds.map(
        lambda b: tokenize_dynamic(b, tokenizer, field_cols),
        batched=True,
        remove_columns=list(field_cols)
    )
    
    collator = DataCollatorWithPadding(tokenizer)
    dataloader = torch.utils.data.DataLoader(ds, batch_size=batch_size, collate_fn=collator)
    
    with torch.no_grad():
        for batch in dataloader:
            input_ids = batch["input_ids"].to(model.device)
            attention_mask = batch["attention_mask"].to(model.device)
            
            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            logits = outputs.logits
            probs = torch.sigmoid(logits)
            scores = (0.5 * probs[:, 0] + 0.5 * probs[:, 1]).cpu().numpy()
            raw_scores.extend(scores)
            
    return np.array(raw_scores)


# ── Single Fold Training ──────────────────────────────────────────────────────
def train_fold(model_name, train_df, val_df, fold, model_key,
               lr, unfreeze_layers, epochs, field_cols, use_llrd=True, use_fgm=True,
               batch_size=BATCH_SIZE, grad_accum=GRAD_ACCUM, full_df=None):
    config = AutoConfig.from_pretrained(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name, config=config)

    # Prevent data leakage: augment only the training split of the fold
    if full_df is not None:
        aug_df = full_df[full_df[ANSWER_ID_COL].str.contains("_aug_backtrans_", na=False)]
        if len(aug_df) > 0:
            base_ids = train_df[ANSWER_ID_COL].unique()
            # Map augmented answer_id back to base answer_id to identify parent samples in train_df
            if "source_answer_id" in aug_df.columns:
                base_aug_ids = aug_df["source_answer_id"].astype(str)
            else:
                base_aug_ids = aug_df[ANSWER_ID_COL].apply(lambda x: str(x).split("_aug_backtrans_")[0])
            matching_aug = aug_df[base_aug_ids.isin(base_ids)]
            if len(matching_aug) > 0:
                print(f"  [Augmentation] Appending {len(matching_aug)} matching augmented samples to train_df")
                train_df = pd.concat([train_df, matching_aug], ignore_index=True)

    train_df_balanced = oversample_minority(train_df)

    def make_ds(df):
        d = df.copy()
        d["labels"] = d[TARGET_COL].astype(float)
        ds = Dataset.from_pandas(d[list(field_cols) + ["labels"]].reset_index(drop=True))
        ds = ds.map(
            lambda b: tokenize_dynamic(b, tokenizer, field_cols),
            batched=True
        )
        return ds.remove_columns(list(field_cols))

    train_ds = make_ds(train_df_balanced)
    val_ds   = make_ds(val_df)

    # Set up model for ordinal classification (2 thresholds outputs)
    config.num_labels = 2
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, config=config, ignore_mismatched_sizes=True,
        torch_dtype=torch.float32,
    )

    # Only enable gradient checkpointing for large models to save memory; keep it disabled for base models to prevent NaN gradients in DeBERTa-v3
    if "large" in model_key and hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable()

    unfreeze_top_layers(model, num_layers_to_unfreeze=unfreeze_layers, unfreeze_embeddings=use_fgm)

    out_dir = f"/tmp/fold_{model_key}_v11_{fold}"

    # Setup optimization
    num_update_steps_per_epoch = (len(train_ds) + (batch_size * grad_accum) - 1) // (batch_size * grad_accum)
    max_steps = int(epochs * num_update_steps_per_epoch)
    
    if use_llrd:
        grouped_params = get_optimizer_grouped_parameters(model, base_lr=lr, weight_decay=WEIGHT_DECAY, lr_decay=0.88)
        optimizer = torch.optim.AdamW(grouped_params)
    else:
        optimizer = torch.optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=lr, weight_decay=WEIGHT_DECAY)
        
    scheduler = get_linear_schedule_with_warmup(
        optimizer,
        num_warmup_steps=int(max_steps * 0.1),
        num_training_steps=max_steps
    )

    use_bf16 = False
    use_fp16 = False
    if "deberta" not in model_key:
        use_bf16 = torch.cuda.is_bf16_supported() and torch.cuda.is_available()
        use_fp16 = not use_bf16 and torch.cuda.is_available()

    args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=lr,
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=batch_size,
        gradient_accumulation_steps=grad_accum,
        num_train_epochs=epochs,
        weight_decay=WEIGHT_DECAY,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="rmse",
        greater_is_better=False,
        save_total_limit=1,
        logging_steps=40,
        report_to="none",
        seed=SEED,
        bf16=use_bf16,
        fp16=use_fp16,
        max_grad_norm=1.0,
    )

    fgm_emb_name = "embeddings.word_embeddings"
    fgm_epsilon = 0.5 if use_fgm else 0.0

    trainer = WeightedCORALTrainer(
        model=model, args=args,
        train_dataset=train_ds, eval_dataset=val_ds,
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        compute_metrics=metrics_regression,
        optimizers=(optimizer, scheduler),
        fgm_epsilon=fgm_epsilon,
        fgm_emb_name=fgm_emb_name,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=PATIENCE)]
    )

    trainer.train()

    # Raw predictions extraction (continuous expectation in [0, 1])
    train_raw = get_model_raw_predictions(model, train_df, tokenizer, field_cols)
    train_labels = train_df[TARGET_COL].values

    # Optimize prediction thresholds on the training set
    best_t1, best_t2 = 0.25, 0.75
    best_train_rmse = float("inf")
    for t1 in np.arange(0.1, 0.45, 0.02):
        for t2 in np.arange(t1 + 0.1, 0.9, 0.02):
            preds = np.where(train_raw < t1, 0.0,
                    np.where(train_raw <= t2, 0.5, 1.0))
            rmse = float(np.sqrt(mean_squared_error(train_labels, preds)))
            if rmse < best_train_rmse:
                best_train_rmse = rmse
                best_t1, best_t2 = t1, t2

    print(f"  [Thresholds] T1={best_t1:.2f}, T2={best_t2:.2f} (train RMSE={best_train_rmse:.4f})")

    # Evaluate validation split with optimized thresholds
    val_raw = get_model_raw_predictions(model, val_df, tokenizer, field_cols)
    val_labels = val_df[TARGET_COL].values

    val_preds = np.where(val_raw < best_t1, 0.0,
                np.where(val_raw <= best_t2, 0.5, 1.0))

    eval_rmse = float(np.sqrt(mean_squared_error(val_labels, val_preds)))
    eval_mae = float(mean_absolute_error(val_labels, val_preds))
    eval_accuracy = float(np.mean(val_preds == val_labels))

    print(f"  [Fold {fold}] Acc={eval_accuracy:.4f} RMSE={eval_rmse:.4f}")

    history = trainer.state.log_history
    del model, trainer, train_ds, val_ds
    gc.collect()
    torch.cuda.empty_cache()
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)

    return eval_rmse, eval_mae, eval_accuracy, history, best_t1, best_t2


# ── CV Runner ─────────────────────────────────────────────────────────────────
def run_experiment(model_key, model_name, df, lr, unfreeze_layers, epochs,
                   field_cols, experiment_name, use_llrd=True, use_fgm=True,
                   batch_size=BATCH_SIZE, grad_accum=GRAD_ACCUM, lowercase=True,
                   full_df=None):
    print(f"\n{'='*70}")
    print(f"  {experiment_name}")
    print(f"  {model_key} | lr={lr} | unfreeze={unfreeze_layers} | "
          f"epochs={epochs} | LLRD={use_llrd} | FGM={use_fgm} | batch={batch_size} | accum={grad_accum} | lowercase={lowercase}")
    print(f"{'='*70}")

    # Conditionally lowercase the fields for this experiment
    if lowercase:
        df = df.copy()
        for col in field_cols:
            df[col] = df[col].astype(str).str.lower()

    kf = GroupKFold(n_splits=N_FOLDS)
    groups = df[GROUP_BY_COL]
    rmses, maes, accs = [], [], []

    histories = []
    t1s, t2s = [], []
    for fold, (tr_idx, va_idx) in enumerate(kf.split(df, groups=groups), 1):
        train_df = df.iloc[tr_idx].reset_index(drop=True)
        val_df = df.iloc[va_idx].reset_index(drop=True)

        print(f"\n── Fold {fold}/{N_FOLDS} ── (train={len(train_df)}, val={len(val_df)})")
        rmse, mae, acc, history, fold_t1, fold_t2 = train_fold(
            model_name, train_df, val_df, fold, model_key,
            lr, unfreeze_layers, epochs, field_cols, use_llrd, use_fgm,
            batch_size, grad_accum, full_df=full_df
        )
        rmses.append(rmse); maes.append(mae); accs.append(acc)
        t1s.append(fold_t1); t2s.append(fold_t2)
        histories.append(history)

    mean_rmse = float(np.mean(rmses))
    std_rmse = float(np.std(rmses))
    mean_acc = float(np.mean(accs))
    std_acc = float(np.std(accs))
    
    print(f"\n[OK] {experiment_name}  "
          f"RMSE: {mean_rmse:.4f}±{std_rmse:.4f}  "
          f"Acc: {mean_acc:.4f}±{std_acc:.4f}")

    # Plot and save training/validation curves across folds
    try:
        plt.figure(figsize=(10, 6))
        for fold_idx, history in enumerate(histories, 1):
            train_epochs = [log['epoch'] for log in history if 'loss' in log]
            train_losses = [log['loss'] for log in history if 'loss' in log]
            val_epochs = [log['epoch'] for log in history if 'eval_loss' in log]
            val_losses = [log['eval_loss'] for log in history if 'eval_loss' in log]
            
            plt.plot(train_epochs, train_losses, color='#3b82f6', alpha=0.4, linewidth=1.5, label='Train Loss' if fold_idx == 1 else "")
            plt.plot(val_epochs, val_losses, color='#ef4444', alpha=0.6, linewidth=1.5, marker='o', markersize=4, label='Val Loss' if fold_idx == 1 else "")
            
        plt.title(f'Cross-Validation Loss Curves - {experiment_name}', fontsize=12, fontweight='bold', pad=15)
        plt.xlabel('Epoch', fontsize=11)
        plt.ylabel('Loss (BCE)', fontsize=11)
        plt.grid(True, linestyle='--', alpha=0.5)
        plt.legend(fontsize=10, loc='upper right')
        plt.tight_layout()
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        save_dir = os.path.abspath(os.path.join(script_dir, "../../results/plots/investigation_v11"))
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, f"{experiment_name}.jpg")
        plt.savefig(save_path, dpi=300)
        plt.close()
        print(f"  [Plotting] Saved loss curves to {save_path}")
    except Exception as e:
        print(f"  [Plotting] Error generating loss plot: {e}")

    return {
        "experiment": experiment_name,
        "model": model_key,
        "group_by": GROUP_BY_COL,
        "lr": lr,
        "unfreeze_layers": unfreeze_layers,
        "epochs": epochs,
        "fields": str(list(field_cols)),
        "use_llrd": use_llrd,
        "use_fgm": use_fgm,
        "lowercase": lowercase,
        "rmse_mean": mean_rmse, "rmse_std": std_rmse,
        "mae_mean": float(np.mean(maes)),
        "acc_mean": mean_acc, "acc_std": std_acc,
        "fold_rmses": [float(r) for r in rmses], "fold_accs": [float(a) for a in accs],
        "opt_t1_mean": float(np.mean(t1s)) if t1s else 0.25,
        "opt_t2_mean": float(np.mean(t2s)) if t2s else 0.75,
        "fold_t1s": [float(t) for t in t1s],
        "fold_t2s": [float(t) for t in t2s],
    }


if __name__ == "__main__":
    # Load clean original dataset for cross-validation splitting
    df = load_data(load_augmented=False)
    # Load full dataset (including augmented) to extract augmented samples per fold
    full_df = load_data(load_augmented=True)
    
    all_results = []
    script_dir = os.path.dirname(os.path.abspath(__file__))
    results_file = os.path.abspath(os.path.join(script_dir, "../../results/investigation_v11_results.csv"))

    # Load existing results for resuming
    completed_runs = set()
    if os.path.exists(results_file):
        try:
            existing_df = pd.read_csv(results_file)
            for _, row in existing_df.iterrows():
                res_dict = row.to_dict()
                for col in ["fold_rmses", "fold_accs", "fold_t1s", "fold_t2s"]:
                    if col in res_dict and isinstance(res_dict[col], str):
                        try:
                            # Replace np.float64 wrappers before parsing
                            cleaned_str = res_dict[col].replace("np.float64(", "").replace(")", "")
                            res_dict[col] = ast.literal_eval(cleaned_str)
                        except Exception:
                            pass
                completed_runs.add((res_dict["model"], res_dict["experiment"]))
                all_results.append(res_dict)
            print(f"\n>>> Loaded {len(completed_runs)} completed experiments from {results_file}.")
        except Exception as e:
            print(f"\n>>> Could not load existing results: {e}. Starting fresh.")

    # Define grid search parameters for XLM-RoBERTa-Base Cased with LLRD and FGM enabled
    lrs = [1e-5, 2e-5, 3e-5, 5e-5]
    unfreezes = [2, 4, 6, 8, 10, 12]
    layouts = [
        ("ra", [RUBRIC_COL, ANSWER_COL]),
        ("rqa", [RUBRIC_COL, QUESTION_COL, ANSWER_COL])
    ]

    experiments = []
    for layout_name, fields in layouts:
        for lr in lrs:
            for unfreeze in unfreezes:
                # Dynamically construct the experiment name based on configuration toggles
                fgm_suffix = "" if USE_FGM else "_no_fgm"
                exp_name = f"grid_{GRID_MODEL}_{layout_name}_lr_{lr}_unfreeze_{unfreeze}_epochs_12_{GROUP_BY_COL}{fgm_suffix}"
                
                experiments.append({
                    "name": exp_name,
                    "model": GRID_MODEL,
                    "lr": lr,
                    "unfreeze": unfreeze,
                    "epochs": 12,
                    "fields": fields,
                    "use_llrd": USE_LLRD,
                    "use_fgm": USE_FGM,
                    "batch_size": BATCH_SIZE,
                    "grad_accum": GRAD_ACCUM,
                    "lowercase": False
                })

    print(f"\n>>> Generated grid search of {len(experiments)} combinations. Running pending experiments...")

    for exp in experiments:
        key = (exp["model"], exp["name"])
        if key in completed_runs:
            print(f"\n>>> Skipping {exp['model']}/{exp['name']} — already done.")
            continue

        res = run_experiment(
            model_key=exp["model"],
            model_name=MODELS[exp["model"]],
            df=df,
            lr=exp["lr"],
            unfreeze_layers=exp["unfreeze"],
            epochs=exp["epochs"],
            field_cols=exp["fields"],
            experiment_name=exp["name"],
            use_llrd=exp["use_llrd"],
            use_fgm=exp["use_fgm"],
            batch_size=exp["batch_size"],
            grad_accum=exp["grad_accum"],
            lowercase=exp["lowercase"],
            full_df=full_df
        )
        all_results.append(res)
        temp_results_file = results_file + ".tmp"
        pd.DataFrame(all_results).to_csv(temp_results_file, index=False)
        os.replace(temp_results_file, results_file)
        print(f">>> Saved progress to {results_file}")


    print("\n" + "="*80)
    print("FINAL RESULTS — investigation_v11 (Grid Search)")
    print("="*80)
    rdf = pd.DataFrame(all_results).sort_values("rmse_mean")
    print(rdf[["experiment", "model", "rmse_mean", "rmse_std", "acc_mean"]].to_string(index=False))
