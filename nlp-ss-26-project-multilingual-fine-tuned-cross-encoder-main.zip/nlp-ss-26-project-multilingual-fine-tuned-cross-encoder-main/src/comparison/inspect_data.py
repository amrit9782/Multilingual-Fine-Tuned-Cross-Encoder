import pandas as pd

files = [
    "comparison/DATA/questions.csv",
    "comparison/DATA/answers.csv",
    "comparison/DATA/rubrics.csv",
    "comparison/DATA/answer_rubrics.csv",
]

for file in files:
    print("=" * 80)
    print(file)

    df = pd.read_csv(file)

    print("Shape:", df.shape)
    print("Columns:", list(df.columns))
    print(df.head())