# =============================================================================
# INVESTIGATION v3 — Fixes for majority-class collapse & data leakage
# Memory-optimised for T4 GPU (16 GB VRAM)
#
# Changes from v2:
#   1. GroupKFold on answer_id — no answer appears in both train and val
#   2. Model-specific unfreezing — all 12 layers for multilingual models,
#      4 layers for gbert (which already works well)
#   3. Weighted MSE loss — amplifies gradient from minority classes (0.0, 1.0)
#   4. Minority class oversampling in training folds
#   5. Only regression mode (classification proven worse in v2)
#   6. Only 3 models: xlm-roberta, mdeberta, gbert
# =============================================================================

import os, random, html, warnings, shutil, ast, re, gc
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.utils import resample
from datasets import Dataset
from transformers import (
    AutoConfig, BertConfig,
    AutoTokenizer, AutoModelForSequenceClassification,
    TrainingArguments, Trainer, DataCollatorWithPadding,
)

warnings.filterwarnings("ignore")

# ── Models ────────────────────────────────────────────────────────────────────
MODELS = {
    "xlm-roberta": "FacebookAI/xlm-roberta-base",
    "gbert":       "deepset/gbert-base",
}

# ── Config ────────────────────────────────────────────────────────────────────
FIELD_BUDGETS = {"rubric": 55, "answer": 210, "solution": 172, "question": 70}
DATA_PATH     = "comparison/DATA/final_grading_dataset.csv"
QUESTION_COL  = "question"
SOLUTION_COL  = "solution"
RUBRIC_COL    = "rubric"
ANSWER_COL    = "answer"
SCORE_COL     = "target_score"
ANSWER_ID_COL = "answer_id"
FIELD_COLS    = [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL]

MAX_LENGTH = 512
BATCH_SIZE = 8
GRAD_ACCUM = 2    # effective batch size = BATCH_SIZE × GRAD_ACCUM = 16
EPOCHS     = 10
SEED       = 42
N_FOLDS    = 5

# Per-class sample weights (inverse frequency, normalised)
# Dataset: 0.0 → 223, 0.5 → 480, 1.0 → 97  (total 800)
CLASS_WEIGHTS = {0.0: 800 / 223, 0.5: 800 / 480, 1.0: 800 / 97}

# Model-specific settings
# 6 layers for multilingual = enough adaptation without OOM on T4
MODEL_CONFIGS = {
    "xlm-roberta": {"unfreeze_layers": 6, "lr": 2e-5},
    "gbert":       {"unfreeze_layers": 4, "lr": 3e-5},
}


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(s)

set_seed(SEED)
os.makedirs("results", exist_ok=True)
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")


# ── Preprocessing ─────────────────────────────────────────────────────────────
def normalize_text(text):
    if pd.isna(text): return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split()).lower()

def tokenize_with_budgets(batch, tokenizer):
    all_ids, all_masks = [], []
    for i in range(len(batch[RUBRIC_COL])):
        rubric_ids   = tokenizer.encode(batch[RUBRIC_COL][i],   add_special_tokens=False, max_length=FIELD_BUDGETS["rubric"],   truncation=True)
        answer_ids   = tokenizer.encode(batch[ANSWER_COL][i],   add_special_tokens=False, max_length=FIELD_BUDGETS["answer"],   truncation=True)
        solution_ids = tokenizer.encode(batch[SOLUTION_COL][i], add_special_tokens=False, max_length=FIELD_BUDGETS["solution"], truncation=True)
        question_ids = tokenizer.encode(batch[QUESTION_COL][i], add_special_tokens=False, max_length=FIELD_BUDGETS["question"], truncation=True)
        ids = ([tokenizer.cls_token_id]
               + rubric_ids   + [tokenizer.sep_token_id]
               + answer_ids   + [tokenizer.sep_token_id]
               + solution_ids + [tokenizer.sep_token_id]
               + question_ids + [tokenizer.sep_token_id])
        all_ids.append(ids)
        all_masks.append([1] * len(ids))
    return {"input_ids": all_ids, "attention_mask": all_masks}

def load_data():
    df = pd.read_csv(DATA_PATH)
    for col in FIELD_COLS:
        df[col] = df[col].apply(normalize_text)
    print(f"Dataset: {len(df)} samples")
    print(df[SCORE_COL].value_counts().sort_index().to_string())

    # Verify answer_id column exists for GroupKFold
    assert ANSWER_ID_COL in df.columns, f"Column '{ANSWER_ID_COL}' not found — needed for GroupKFold"
    n_answers = df[ANSWER_ID_COL].nunique()
    print(f"Unique answers: {n_answers} (will be used as groups for KFold)")
    return df


# ── Oversampling ──────────────────────────────────────────────────────────────
def oversample_minority(df):
    """Oversample minority classes so each class has the same count as the majority."""
    classes = [df[df[SCORE_COL] == s] for s in [0.0, 0.5, 1.0]]
    max_size = max(len(c) for c in classes)
    balanced = pd.concat([
        resample(c, replace=True, n_samples=max_size, random_state=SEED)
        if len(c) < max_size else c
        for c in classes
    ])
    balanced = balanced.sample(frac=1, random_state=SEED).reset_index(drop=True)
    print(f"  [Oversampling] {len(df)} → {len(balanced)} training samples")
    print(f"    0.0: {(balanced[SCORE_COL]==0.0).sum()}  "
          f"0.5: {(balanced[SCORE_COL]==0.5).sum()}  "
          f"1.0: {(balanced[SCORE_COL]==1.0).sum()}")
    return balanced


# ── Metrics ───────────────────────────────────────────────────────────────────
def round_to_valid(s):
    v = np.array([0.0, 0.5, 1.0])
    return float(v[np.argmin(np.abs(v - s))])

def metrics_regression(eval_pred):
    preds, labels = eval_pred
    preds = preds.reshape(-1)
    labels = labels.reshape(-1)

    # Handle NaN values gracefully
    if np.isnan(preds).any() or np.isnan(labels).any():
        print("Warning: NaNs detected in predictions or labels!")
        preds = np.nan_to_num(preds, nan=0.0)
        labels = np.nan_to_num(labels, nan=0.0)
        rmse = 999.0
        mae = 999.0
        rounded_accuracy = 0.0
    else:
        preds = np.clip(preds, 0.0, 1.0)
        rmse = np.sqrt(mean_squared_error(labels, preds))
        rounded = np.array([round_to_valid(p) for p in preds])
        mae = mean_absolute_error(labels, preds)
        rounded_accuracy = np.mean(rounded == labels)

    return {"rmse": rmse,
            "mae":  mae,
            "rounded_accuracy": rounded_accuracy}


# ── Weighted MSE Trainer ──────────────────────────────────────────────────────
class WeightedMSETrainer(Trainer):
    """Trainer with sample-weighted MSE loss to combat majority-class collapse.

    Samples from minority classes (0.0 and especially 1.0) receive higher loss
    weights, amplifying their gradient signal so the model can't just predict
    0.5 for everything.
    """
    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        labels = inputs.pop("labels")
        outputs = model(**inputs)
        preds = outputs.logits.squeeze(-1)

        # Assign per-sample weights based on class frequency
        # 0.0 → 3.59x, 0.5 → 1.67x, 1.0 → 8.25x
        weights = torch.ones_like(labels)
        for score_val, w in CLASS_WEIGHTS.items():
            mask = (labels - score_val).abs() < 0.01
            weights[mask] = w

        loss = (weights * (preds - labels) ** 2).mean()
        return (loss, outputs) if return_outputs else loss


# ── Layer unfreezing ──────────────────────────────────────────────────────────
def unfreeze_top_layers(model, num_layers_to_unfreeze=4):
    # First, freeze everything
    for param in model.parameters():
        param.requires_grad = False

    # Unfreeze classification head modules
    head_names = ["classifier", "score", "pooler"]
    for name, module in model.named_modules():
        if any(hn in name for hn in head_names):
            for param in module.parameters():
                param.requires_grad = True

    # Unfreeze top N transformer layers
    layer_pattern = re.compile(r"layer\.(\d+)\.")

    max_layer_idx = -1
    for name, _ in model.named_parameters():
        match = layer_pattern.search(name)
        if match:
            layer_idx = int(match.group(1))
            if layer_idx > max_layer_idx:
                max_layer_idx = layer_idx

    if max_layer_idx != -1:
        unfreeze_start_idx = max(0, max_layer_idx - num_layers_to_unfreeze + 1)
        print(f"  [Unfreezing] Max layer = {max_layer_idx}. "
              f"Unfreezing layers >= {unfreeze_start_idx} and head modules. "
              f"({num_layers_to_unfreeze} of {max_layer_idx + 1} layers)")
        for name, param in model.named_parameters():
            match = layer_pattern.search(name)
            if match:
                layer_idx = int(match.group(1))
                if layer_idx >= unfreeze_start_idx:
                    param.requires_grad = True
    else:
        print("  [Unfreezing] Could not detect numbered transformer layers. "
              "Unfreezing top 30% of parameters.")
        params = list(model.named_parameters())
        num_params = len(params)
        unfreeze_count = int(num_params * 0.3)
        for name, param in params[-unfreeze_count:]:
            param.requires_grad = True

    # Report trainable vs total params
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  [Params] Trainable: {trainable:,} / {total:,} "
          f"({100 * trainable / total:.1f}%)")


# ── Sliding window inference ─────────────────────────────────────────────────
def get_model_raw_predictions(model, df, tokenizer):
    model.eval()
    raw_scores = []
    with torch.no_grad():
        for idx, row in df.iterrows():
            q_text = normalize_text(row[QUESTION_COL])
            s_text = normalize_text(row[SOLUTION_COL])
            r_text = normalize_text(row[RUBRIC_COL])
            a_text = normalize_text(row[ANSWER_COL])

            q_ids = tokenizer.encode(q_text, add_special_tokens=False, max_length=FIELD_BUDGETS["question"], truncation=True)
            s_ids = tokenizer.encode(s_text, add_special_tokens=False, max_length=FIELD_BUDGETS["solution"], truncation=True)
            r_ids = tokenizer.encode(r_text, add_special_tokens=False, max_length=FIELD_BUDGETS["rubric"], truncation=True)
            full_a_ids = tokenizer.encode(a_text, add_special_tokens=False)

            window_size = FIELD_BUDGETS["answer"]
            overlap = 100
            chunks = []
            if len(full_a_ids) <= window_size:
                chunks.append(full_a_ids)
            else:
                step = window_size - overlap
                for start in range(0, len(full_a_ids), step):
                    chunk = full_a_ids[start:start+window_size]
                    chunks.append(chunk)
                    if start + window_size >= len(full_a_ids):
                        break

            chunk_scores = []
            for chunk in chunks:
                input_ids = (
                    [tokenizer.cls_token_id]
                    + r_ids + [tokenizer.sep_token_id]
                    + chunk + [tokenizer.sep_token_id]
                    + s_ids + [tokenizer.sep_token_id]
                    + q_ids + [tokenizer.sep_token_id]
                )
                attention_mask = [1] * len(input_ids)
                input_tensor = torch.tensor([input_ids]).to(model.device)
                mask_tensor = torch.tensor([attention_mask]).to(model.device)

                outputs = model(input_ids=input_tensor, attention_mask=mask_tensor)
                score = outputs.logits.squeeze(-1).item()
                score = max(0.0, min(1.0, score))
                chunk_scores.append(score)

            best_score = max(chunk_scores) if chunk_scores else 0.0
            raw_scores.append(best_score)
    return np.array(raw_scores)


# ── Single fold trainer ───────────────────────────────────────────────────────
def train_fold(model_name, train_df, val_df, fold, model_key):
    try:
        config = AutoConfig.from_pretrained(model_name)
    except ValueError as e:
        if "model_type" in str(e) and "gbert" in model_name:
            config = BertConfig.from_pretrained(model_name)
        else:
            raise e

    tokenizer = AutoTokenizer.from_pretrained(model_name, config=config)

    # ── Oversample minority classes in training set ──
    train_df_balanced = oversample_minority(train_df)

    def make_ds(df):
        d = df.copy()
        d["labels"] = d[SCORE_COL].astype(float)
        ds = Dataset.from_pandas(d[FIELD_COLS + ["labels"]].reset_index(drop=True))
        ds = ds.map(lambda b: tokenize_with_budgets(b, tokenizer), batched=True)
        return ds.remove_columns(FIELD_COLS)

    train_ds = make_ds(train_df_balanced)
    val_ds   = make_ds(val_df)

    config.num_labels = 1
    config.problem_type = "regression"

    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        config=config,
        ignore_mismatched_sizes=True,
    )

    # ── Gradient checkpointing — trades compute for ~30-40% memory saving ──
    if hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable()
        print("  [Memory] Gradient checkpointing enabled")

    # ── Model-specific unfreezing ──
    mcfg = MODEL_CONFIGS[model_key]
    unfreeze_top_layers(model, num_layers_to_unfreeze=mcfg["unfreeze_layers"])

    out_dir = f"/tmp/fold_{model_key}_v3_{fold}"

    args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=mcfg["lr"],
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM,  # effective batch = 8×2 = 16
        num_train_epochs=EPOCHS,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="no",             # ← no disk writes (quota exceeded fix)
        load_best_model_at_end=False,   # ← use final model state instead
        logging_steps=40,
        report_to="none",
        seed=SEED,
        bf16=torch.cuda.is_available(),
        fp16=not torch.cuda.is_bf16_supported() and torch.cuda.is_available(),
        max_grad_norm=1.0,
        warmup_ratio=0.1,
    )

    trainer = WeightedMSETrainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        compute_metrics=metrics_regression,
    )

    trainer.train()

    # ── Sliding window + dynamic threshold evaluation ──
    model.eval()

    print("  Optimizing thresholds T1 and T2 on the training set...")
    train_raw_scores = get_model_raw_predictions(model, train_df, tokenizer)
    train_labels = train_df[SCORE_COL].values

    # Report raw prediction distribution for diagnostics
    print(f"  [Raw predictions] train: mean={train_raw_scores.mean():.4f}, "
          f"std={train_raw_scores.std():.4f}, "
          f"min={train_raw_scores.min():.4f}, max={train_raw_scores.max():.4f}")

    best_t1, best_t2 = 0.23, 0.65
    best_train_rmse = float("inf")

    for t1 in np.arange(0.0, 0.55, 0.02):
        for t2 in np.arange(t1 + 0.02, 1.01, 0.02):
            preds = np.where(train_raw_scores < t1, 0.0,
                    np.where(train_raw_scores <= t2, 0.5, 1.0))
            rmse = np.sqrt(mean_squared_error(train_labels, preds))
            if rmse < best_train_rmse:
                best_train_rmse = rmse
                best_t1, best_t2 = t1, t2

    print(f"  [Dynamic Thresholds] Best T1 = {best_t1:.2f}, T2 = {best_t2:.2f} "
          f"(Train RMSE = {best_train_rmse:.4f})")

    # Evaluate on validation fold
    val_raw_scores = get_model_raw_predictions(model, val_df, tokenizer)
    val_labels = val_df[SCORE_COL].values

    print(f"  [Raw predictions] val: mean={val_raw_scores.mean():.4f}, "
          f"std={val_raw_scores.std():.4f}, "
          f"min={val_raw_scores.min():.4f}, max={val_raw_scores.max():.4f}")

    val_predictions = np.where(val_raw_scores < best_t1, 0.0,
                     np.where(val_raw_scores <= best_t2, 0.5, 1.0))

    eval_rmse = np.sqrt(mean_squared_error(val_labels, val_predictions))
    eval_mae = mean_absolute_error(val_labels, val_predictions)
    eval_accuracy = np.mean(val_predictions == val_labels)

    # Per-class accuracy for diagnostics
    for score_val in [0.0, 0.5, 1.0]:
        mask = val_labels == score_val
        if mask.sum() > 0:
            class_acc = np.mean(val_predictions[mask] == score_val)
            print(f"  [Per-class] {score_val}: acc={class_acc:.4f} "
                  f"(n={mask.sum()})")

    print(f"  [Fold {fold} Result] Acc: {eval_accuracy:.4f} | "
          f"RMSE: {eval_rmse:.4f} | MAE: {eval_mae:.4f}")

    # ── Cleanup — aggressively free GPU memory ──
    del model, trainer, train_ds, val_ds
    gc.collect()
    torch.cuda.empty_cache()
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)
    print(f"  Disk & memory freed after fold {fold}")

    return eval_rmse, eval_mae, eval_accuracy


# ── K-fold runner (GroupKFold on answer_id) ────────────────────────────────────
def run_kfold(model_key, model_name, df):
    print(f"\n{'='*65}")
    print(f"  {model_key.upper()} | regression | GroupKFold on answer_id")
    print(f"{'='*65}")

    kf = GroupKFold(n_splits=N_FOLDS)
    groups = df[ANSWER_ID_COL]
    rmses, maes, accs = [], [], []

    for fold, (tr_idx, va_idx) in enumerate(kf.split(df, groups=groups), 1):
        train_df = df.iloc[tr_idx].reset_index(drop=True)
        val_df = df.iloc[va_idx].reset_index(drop=True)

        # Verify no answer leakage
        train_answers = set(df.iloc[tr_idx][ANSWER_ID_COL].unique())
        val_answers = set(df.iloc[va_idx][ANSWER_ID_COL].unique())
        overlap = train_answers & val_answers
        assert len(overlap) == 0, f"Answer leakage! {len(overlap)} shared answers"

        print(f"\n── Fold {fold}/{N_FOLDS} ──")
        print(f"  Train: {len(train_df)} rows, {len(train_answers)} answers | "
              f"Val: {len(val_df)} rows, {len(val_answers)} answers")
        print(f"  Val score dist: "
              f"0.0={sum(val_df[SCORE_COL]==0.0)} "
              f"0.5={sum(val_df[SCORE_COL]==0.5)} "
              f"1.0={sum(val_df[SCORE_COL]==1.0)}")

        rmse, mae, acc = train_fold(
            model_name, train_df, val_df, fold, model_key
        )
        rmses.append(rmse); maes.append(mae); accs.append(acc)
        print(f"  → RMSE={rmse:.4f}  MAE={mae:.4f}  Acc={acc:.4f}")

    print(f"\n[OK] {model_key}  RMSE: {np.mean(rmses):.4f} ± {np.std(rmses):.4f}"
          f"  |  Acc: {np.mean(accs):.4f} ± {np.std(accs):.4f}")

    return {"model": model_key, "mode": "regression",
            "rmse_mean": np.mean(rmses), "rmse_std": np.std(rmses),
            "mae_mean":  np.mean(maes),  "acc_mean":  np.mean(accs),
            "acc_std": np.std(accs), "fold_rmses": rmses, "fold_accs": accs}


if __name__ == "__main__":
    df = load_data()
    all_results = []
    results_file = "results/investigation_v3_results.csv"

    # Load existing results for resuming
    completed_runs = {}
    if os.path.exists(results_file):
        try:
            existing_df = pd.read_csv(results_file)
            for _, row in existing_df.iterrows():
                res_dict = row.to_dict()
                for col in ["fold_rmses", "fold_accs"]:
                    if col in res_dict and isinstance(res_dict[col], str):
                        try:
                            res_dict[col] = ast.literal_eval(res_dict[col])
                        except Exception:
                            pass
                completed_runs[res_dict["model"]] = res_dict
            print(f"\n>>> Loaded {len(completed_runs)} completed "
                  f"configurations from {results_file}.")
        except Exception as e:
            print(f"\n>>> Could not load existing results: {e}. Starting fresh.")

    # Run 2 models (mdeberta dropped — stuck at majority-class baseline)
    for mk in ["xlm-roberta", "gbert"]:
        if mk in completed_runs:
            print(f"\n>>> Skipping {mk} — already completed in a previous run.")
            all_results.append(completed_runs[mk])
        else:
            res = run_kfold(mk, MODELS[mk], df)
            all_results.append(res)
            # Save incrementally
            pd.DataFrame(all_results).to_csv(results_file, index=False)
            print(f"\n>>> Saved intermediate results for {mk} to {results_file}")


    # ── Final table ───────────────────────────────────────────────────────────
    print("\n" + "="*70)
    print("FINAL RESULTS — investigation_v3")
    print("="*70)
    print(f"{'Model':<14} {'RMSE mean±std':<22} {'Acc mean±std':<22}")
    print("-"*60)

    rdf = pd.DataFrame(all_results).sort_values("rmse_mean")
    for _, r in rdf.iterrows():
        acc_std = r.get('acc_std', 0)
        print(f"{r['model']:<14} "
              f"{r['rmse_mean']:.4f} ± {r['rmse_std']:.4f}        "
              f"{r['acc_mean']:.4f} ± {acc_std:.4f}")

    # Comparison with v2 majority-class baseline
    print(f"\n{'Majority class':<14} 0.3162                  0.6000")

    best = rdf.iloc[0]
    print(f"\n→ BEST: {best['model']}  |  "
          f"RMSE = {best['rmse_mean']:.4f} ± {best['rmse_std']:.4f}  |  "
          f"Acc = {best['acc_mean']:.4f}")

    # Save final sorted results
    rdf.to_csv(results_file, index=False)
    print(f"\nSaved final results to: {results_file}")
