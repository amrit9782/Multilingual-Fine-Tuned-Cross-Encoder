# =============================================================================
# INVESTIGATION v6 — Field Permutation and Ordering Sweep
# Memory-optimised for T4 GPU (16 GB VRAM)
#
# Runs 5-fold cross-validation for XLM-RoBERTa using optimal hyperparams:
#   - Learning Rate: 5e-5
#   - Unfreezing depth: 8 layers
#   - Epochs: 20
#
# Sweeps across all permutations of:
#   - (rubric, answer) [2 orderings]
#   - (rubric, question, answer) [6 orderings]
# =============================================================================

import os, random, html, warnings, shutil, ast, re, gc
import itertools
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import GroupKFold
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.utils import resample
from datasets import Dataset
from transformers import (
    AutoConfig, AutoTokenizer, AutoModelForSequenceClassification,
    TrainingArguments, Trainer, DataCollatorWithPadding,
)

warnings.filterwarnings("ignore")

# ── Models ────────────────────────────────────────────────────────────────────
MODELS = {
    "xlm-roberta": "FacebookAI/xlm-roberta-base",
}

# ── Config ────────────────────────────────────────────────────────────────────
QUESTION_COL  = "question"
SOLUTION_COL  = "solution"
RUBRIC_COL    = "rubric"
ANSWER_COL    = "answer"
SCORE_COL     = "target_score"
ANSWER_ID_COL = "answer_id"

# All possible fields
ALL_FIELD_COLS = [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL]

MAX_LENGTH = 512
BATCH_SIZE = 8
GRAD_ACCUM = 2    # effective batch size = 16
SEED       = 42
N_FOLDS    = 5

# Optimal Hyperparameters
BEST_LR = 5e-5
BEST_UNFREEZE = 8
BEST_EPOCHS = 20

# Global CLASS_WEIGHTS (computed dynamically in load_data)
CLASS_WEIGHTS = {0.0: 1.0, 0.5: 1.0, 1.0: 1.0}


def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(s)

set_seed(SEED)
os.makedirs("results", exist_ok=True)
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")


# ── Preprocessing ─────────────────────────────────────────────────────────────
def normalize_text(text):
    if pd.isna(text): return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split()).lower()


def tokenize_with_budgets(batch, tokenizer, field_cols, field_budgets):
    """Tokenize with per-field budgets. field_cols controls order and selection."""
    all_ids, all_masks = [], []
    for i in range(len(batch[field_cols[0]])):
        token_segments = []
        for col in field_cols:
            budget = field_budgets.get(col, 100)
            seg_ids = tokenizer.encode(
                batch[col][i], add_special_tokens=False,
                max_length=budget, truncation=True
            )
            token_segments.append(seg_ids)

        # Build: [CLS] field1 [SEP] field2 [SEP] ... fieldN [SEP]
        ids = [tokenizer.cls_token_id]
        for seg in token_segments:
            ids += seg + [tokenizer.sep_token_id]

        all_ids.append(ids)
        all_masks.append([1] * len(ids))
    return {"input_ids": all_ids, "attention_mask": all_masks}


def load_data():
    global CLASS_WEIGHTS
    datasets = ["WuS-WS25", "DAV-SS2425", "NLP-SS2425"]
    data_dir = "/home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/data"
    
    dfs = []
    print("\n>>> Loading and merging datasets...")
    for dataset in datasets:
        path = os.path.join(data_dir, dataset)
        q = pd.read_csv(os.path.join(path, "questions.csv"))
        a = pd.read_csv(os.path.join(path, "answers.csv"))
        r = pd.read_csv(os.path.join(path, "rubrics.csv"))
        ar = pd.read_csv(os.path.join(path, "answer_rubrics.csv"))
        
        # Suffix IDs to prevent collisions across datasets
        prefix = f"{dataset}_"
        for df in [q, a, r, ar]:
            if "question_id" in df.columns:
                df["question_id"] = prefix + df["question_id"].astype(str)
            if "answer_id" in df.columns:
                df["answer_id"] = prefix + df["answer_id"].astype(str)
            if "rubric_id" in df.columns:
                df["rubric_id"] = prefix + df["rubric_id"].astype(str)
        
        # Rename columns to avoid confusion
        a = a.rename(columns={"score": "answer_total_score"})
        r = r.rename(columns={"score": "rubric_score"})
        
        # Merge
        merged = ar.merge(
            a[["question_id", "answer_id", "answer", "answer_total_score"]],
            on=["question_id", "answer_id"],
            how="left"
        )
        merged = merged.merge(
            r[["question_id", "rubric_id", "rubric", "rubric_score"]],
            on=["question_id", "rubric_id"],
            how="left"
        )
        merged = merged.merge(
            q[["question_id", "question", "solution", "max_score"]],
            on="question_id",
            how="left"
        )
        
        # Calculate target_score
        merged["target_score"] = merged["label"].astype(float) * merged["rubric_score"]
        
        # Select final columns
        final_columns = [
            "question_id",
            "answer_id",
            "rubric_id",
            "question",
            "solution",
            "rubric",
            "answer",
            "rubric_score",
            "label",
            "target_score",
            "answer_total_score",
            "max_score",
        ]
        merged = merged[final_columns]
        dfs.append(merged)
        
    df = pd.concat(dfs, ignore_index=True)
    print(f"Combined Dataset: {len(df)} samples")
    
    # Normalize texts
    for col in ALL_FIELD_COLS:
        df[col] = df[col].apply(normalize_text)
        
    assert ANSWER_ID_COL in df.columns, f"Column '{ANSWER_ID_COL}' not found"
    n_answers = df[ANSWER_ID_COL].nunique()
    print(f"Unique answers (groups for GroupKFold): {n_answers}")
    
    # Compute inverse class frequencies dynamically
    total = len(df)
    counts = df[SCORE_COL].value_counts().to_dict()
    CLASS_WEIGHTS = {s: total / counts.get(s, 1.0) for s in [0.0, 0.5, 1.0]}
    print("Computed CLASS_WEIGHTS:", CLASS_WEIGHTS)
    
    return df


# ── Oversampling ──────────────────────────────────────────────────────────────
def oversample_minority(df):
    classes = [df[(df[SCORE_COL] - s).abs() < 0.01] for s in [0.0, 0.5, 1.0]]
    max_size = max(len(c) for c in classes)
    balanced = pd.concat([
        resample(c, replace=True, n_samples=max_size, random_state=SEED)
        if len(c) < max_size else c
        for c in classes
    ])
    balanced = balanced.sample(frac=1, random_state=SEED).reset_index(drop=True)
    return balanced


# ── Metrics ───────────────────────────────────────────────────────────────────
def round_to_valid(s):
    v = np.array([0.0, 0.5, 1.0])
    return float(v[np.argmin(np.abs(v - s))])

def metrics_regression(eval_pred):
    preds, labels = eval_pred
    preds = preds.reshape(-1)
    labels = labels.reshape(-1)
    if np.isnan(preds).any() or np.isnan(labels).any():
        preds = np.nan_to_num(preds, nan=0.0)
        labels = np.nan_to_num(labels, nan=0.0)
        return {"rmse": 999.0, "mae": 999.0, "rounded_accuracy": 0.0}
    preds = np.clip(preds, 0.0, 1.0)
    rmse = np.sqrt(mean_squared_error(labels, preds))
    rounded = np.array([round_to_valid(p) for p in preds])
    mae = mean_absolute_error(labels, preds)
    rounded_accuracy = np.mean(rounded == labels)
    return {"rmse": rmse, "mae": mae, "rounded_accuracy": rounded_accuracy}


# ── Weighted MSE Trainer ──────────────────────────────────────────────────────
class WeightedMSETrainer(Trainer):
    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        labels = inputs.pop("labels")
        outputs = model(**inputs)
        preds = outputs.logits.squeeze(-1)
        weights = torch.ones_like(labels)
        for score_val, w in CLASS_WEIGHTS.items():
            mask = (labels - score_val).abs() < 0.01
            weights[mask] = w
        loss = (weights * (preds - labels) ** 2).mean()
        return (loss, outputs) if return_outputs else loss


# ── Layer unfreezing ──────────────────────────────────────────────────────────
def unfreeze_top_layers(model, num_layers_to_unfreeze=4):
    for param in model.parameters():
        param.requires_grad = False

    head_names = ["classifier", "score", "pooler"]
    for name, module in model.named_modules():
        if any(hn in name for hn in head_names):
            for param in module.parameters():
                param.requires_grad = True

    layer_pattern = re.compile(r"layer\.(\d+)\.")
    max_layer_idx = -1
    for name, _ in model.named_parameters():
        match = layer_pattern.search(name)
        if match:
            layer_idx = int(match.group(1))
            if layer_idx > max_layer_idx:
                max_layer_idx = layer_idx

    if max_layer_idx != -1:
        unfreeze_start_idx = max(0, max_layer_idx - num_layers_to_unfreeze + 1)
        for name, param in model.named_parameters():
            match = layer_pattern.search(name)
            if match and int(match.group(1)) >= unfreeze_start_idx:
                param.requires_grad = True
        print(f"  [Unfreezing] {num_layers_to_unfreeze}/{max_layer_idx+1} layers + head")
    else:
        params = list(model.named_parameters())
        for name, param in params[-int(len(params)*0.3):]:
            param.requires_grad = True
        print("  [Unfreezing] Top 30% of parameters")


# ── Sliding window inference ─────────────────────────────────────────────────
def get_model_raw_predictions(model, df, tokenizer, field_cols, field_budgets):
    model.eval()
    raw_scores = []
    answer_budget = field_budgets.get(ANSWER_COL, 210)

    with torch.no_grad():
        for idx, row in df.iterrows():
            # Encode non-answer fields
            non_answer_ids = {}
            for col in field_cols:
                if col == ANSWER_COL:
                    continue
                budget = field_budgets.get(col, 100)
                non_answer_ids[col] = tokenizer.encode(
                    normalize_text(row[col]), add_special_tokens=False,
                    max_length=budget, truncation=True
                )

            # Sliding window over answer
            if ANSWER_COL not in field_cols:
                # No answer field — single pass
                ids = [tokenizer.cls_token_id]
                for col in field_cols:
                    ids += non_answer_ids[col] + [tokenizer.sep_token_id]
                input_tensor = torch.tensor([ids]).to(model.device)
                mask_tensor = torch.ones_like(input_tensor).to(model.device)
                outputs = model(input_ids=input_tensor, attention_mask=mask_tensor)
                score = outputs.logits.squeeze(-1).item()
                raw_scores.append(max(0.0, min(1.0, score)))
                continue

            full_a_ids = tokenizer.encode(
                normalize_text(row[ANSWER_COL]), add_special_tokens=False
            )

            window_size = answer_budget
            overlap = 100
            chunks = []
            if len(full_a_ids) <= window_size:
                chunks.append(full_a_ids)
            else:
                step = window_size - overlap
                for start in range(0, len(full_a_ids), step):
                    chunk = full_a_ids[start:start+window_size]
                    chunks.append(chunk)
                    if start + window_size >= len(full_a_ids):
                        break

            chunk_scores = []
            for chunk in chunks:
                ids = [tokenizer.cls_token_id]
                for col in field_cols:
                    if col == ANSWER_COL:
                        ids += chunk + [tokenizer.sep_token_id]
                    else:
                        ids += non_answer_ids[col] + [tokenizer.sep_token_id]
                input_tensor = torch.tensor([ids]).to(model.device)
                mask_tensor = torch.ones_like(input_tensor).to(model.device)
                outputs = model(input_ids=input_tensor, attention_mask=mask_tensor)
                score = outputs.logits.squeeze(-1).item()
                chunk_scores.append(max(0.0, min(1.0, score)))

            raw_scores.append(max(chunk_scores) if chunk_scores else 0.0)
    return np.array(raw_scores)


# ── Single fold trainer ───────────────────────────────────────────────────────
def train_fold(model_name, train_df, val_df, fold, model_key,
               lr, unfreeze_layers, epochs, field_cols, field_budgets):
    try:
        config = AutoConfig.from_pretrained(model_name)
    except ValueError as e:
        raise e

    tokenizer = AutoTokenizer.from_pretrained(model_name, config=config)
    train_df_balanced = oversample_minority(train_df)

    def make_ds(df):
        d = df.copy()
        d["labels"] = d[SCORE_COL].astype(float)
        ds = Dataset.from_pandas(d[list(field_cols) + ["labels"]].reset_index(drop=True))
        ds = ds.map(
            lambda b: tokenize_with_budgets(b, tokenizer, field_cols, field_budgets),
            batched=True
        )
        return ds.remove_columns(list(field_cols))

    train_ds = make_ds(train_df_balanced)
    val_ds   = make_ds(val_df)

    config.num_labels = 1
    config.problem_type = "regression"

    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, config=config, ignore_mismatched_sizes=True,
    )

    if hasattr(model, "gradient_checkpointing_enable"):
        model.gradient_checkpointing_enable()

    unfreeze_top_layers(model, num_layers_to_unfreeze=unfreeze_layers)

    out_dir = f"/tmp/fold_{model_key}_v6_{fold}"

    args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=lr,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRAD_ACCUM,
        num_train_epochs=epochs,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="no",
        load_best_model_at_end=False,
        logging_steps=40,
        report_to="none",
        seed=SEED,
        bf16=torch.cuda.is_available(),
        fp16=not torch.cuda.is_bf16_supported() and torch.cuda.is_available(),
        max_grad_norm=1.0,
        warmup_ratio=0.1,
    )

    trainer = WeightedMSETrainer(
        model=model, args=args,
        train_dataset=train_ds, eval_dataset=val_ds,
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        compute_metrics=metrics_regression,
    )

    trainer.train()

    # ── Sliding window + dynamic threshold evaluation ──
    model.eval()
    train_raw = get_model_raw_predictions(model, train_df, tokenizer, field_cols, field_budgets)
    train_labels = train_df[SCORE_COL].values

    best_t1, best_t2 = 0.23, 0.65
    best_train_rmse = float("inf")
    for t1 in np.arange(0.0, 0.55, 0.02):
        for t2 in np.arange(t1 + 0.02, 1.01, 0.02):
            preds = np.where(train_raw < t1, 0.0,
                    np.where(train_raw <= t2, 0.5, 1.0))
            rmse = np.sqrt(mean_squared_error(train_labels, preds))
            if rmse < best_train_rmse:
                best_train_rmse = rmse
                best_t1, best_t2 = t1, t2

    print(f"  [Thresholds] T1={best_t1:.2f}, T2={best_t2:.2f} (train RMSE={best_train_rmse:.4f})")

    val_raw = get_model_raw_predictions(model, val_df, tokenizer, field_cols, field_budgets)
    val_labels = val_df[SCORE_COL].values

    val_preds = np.where(val_raw < best_t1, 0.0,
                np.where(val_raw <= best_t2, 0.5, 1.0))

    eval_rmse = np.sqrt(mean_squared_error(val_labels, val_preds))
    eval_mae = mean_absolute_error(val_labels, val_preds)
    eval_accuracy = np.mean(val_preds == val_labels)

    print(f"  [Fold {fold}] Acc={eval_accuracy:.4f} RMSE={eval_rmse:.4f}")

    del model, trainer, train_ds, val_ds
    gc.collect()
    torch.cuda.empty_cache()
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)

    return eval_rmse, eval_mae, eval_accuracy


# ── K-fold runner ─────────────────────────────────────────────────────────────
def run_experiment(model_key, model_name, df, lr, unfreeze_layers, epochs,
                   field_cols, field_budgets, experiment_name):
    print(f"\n{'='*70}")
    print(f"  {experiment_name}")
    print(f"  fields={list(field_cols)} | budgets={field_budgets}")
    print(f"{'='*70}")

    kf = GroupKFold(n_splits=N_FOLDS)
    groups = df[ANSWER_ID_COL]
    rmses, maes, accs = [], [], []

    for fold, (tr_idx, va_idx) in enumerate(kf.split(df, groups=groups), 1):
        train_df = df.iloc[tr_idx].reset_index(drop=True)
        val_df = df.iloc[va_idx].reset_index(drop=True)

        assert len(set(df.iloc[tr_idx][ANSWER_ID_COL]) & set(df.iloc[va_idx][ANSWER_ID_COL])) == 0
        print(f"\n── Fold {fold}/{N_FOLDS} ── (train={len(train_df)}, val={len(val_df)})")

        rmse, mae, acc = train_fold(
            model_name, train_df, val_df, fold, model_key,
            lr, unfreeze_layers, epochs, field_cols, field_budgets
        )
        rmses.append(rmse); maes.append(mae); accs.append(acc)

    print(f"\n[OK] {experiment_name}  Acc: {np.mean(accs):.4f}±{np.std(accs):.4f}  RMSE: {np.mean(rmses):.4f}±{np.std(rmses):.4f}")

    return {
        "experiment": experiment_name,
        "model": model_key,
        "lr": lr,
        "unfreeze_layers": unfreeze_layers,
        "epochs": epochs,
        "fields": str(list(field_cols)),
        "rmse_mean": np.mean(rmses), "rmse_std": np.std(rmses),
        "mae_mean": np.mean(maes),
        "acc_mean": np.mean(accs), "acc_std": np.std(accs),
        "fold_rmses": rmses, "fold_accs": accs,
    }


# =============================================================================
# EXPERIMENT DEFINITIONS
# =============================================================================

BUDGETS_2_FIELDS = {RUBRIC_COL: 120, ANSWER_COL: 380}
BUDGETS_3_FIELDS = {RUBRIC_COL: 120, ANSWER_COL: 230, QUESTION_COL: 150}


def build_experiments():
    """Build all permutations and orderings for (R, A) and (R, Q, A)."""
    experiments = []

    # 1. Permutations of (R, A) [2-field configs]
    fields_2 = [RUBRIC_COL, ANSWER_COL]
    for perm in itertools.permutations(fields_2):
        name = "perm_ra_" + "_".join(perm)
        experiments.append({
            "name": name,
            "fields": list(perm),
            "budgets": BUDGETS_2_FIELDS
        })

    # 2. Permutations of (R, Q, A) [3-field configs]
    fields_3 = [RUBRIC_COL, ANSWER_COL, QUESTION_COL]
    for perm in itertools.permutations(fields_3):
        name = "perm_raq_" + "_".join(perm)
        experiments.append({
            "name": name,
            "fields": list(perm),
            "budgets": BUDGETS_3_FIELDS
        })

    return experiments


# =============================================================================
# MAIN
# =============================================================================
if __name__ == "__main__":
    df = load_data()
    all_results = []
    results_file = "results/investigation_v6_results.csv"

    # Load existing results for resuming
    completed_runs = set()
    if os.path.exists(results_file):
        try:
            existing_df = pd.read_csv(results_file)
            for _, row in existing_df.iterrows():
                res_dict = row.to_dict()
                for col in ["fold_rmses", "fold_accs"]:
                    if col in res_dict and isinstance(res_dict[col], str):
                        try:
                            res_dict[col] = ast.literal_eval(res_dict[col])
                        except Exception:
                            pass
                completed_runs.add(res_dict["experiment"])
                all_results.append(res_dict)
            print(f"\n>>> Loaded {len(completed_runs)} completed experiments.")
        except Exception as e:
            print(f"\n>>> Could not load existing results: {e}. Starting fresh.")

    experiments = build_experiments()
    print(f"\n>>> Total experiments to run: {len(experiments)} ({len(experiments) - len(completed_runs)} remaining)")

    for exp in experiments:
        if exp["name"] in completed_runs:
            print(f"\n>>> Skipping {exp['name']} — already done.")
            continue

        res = run_experiment(
            model_key="xlm-roberta",
            model_name=MODELS["xlm-roberta"],
            df=df,
            lr=BEST_LR,
            unfreeze_layers=BEST_UNFREEZE,
            epochs=BEST_EPOCHS,
            field_cols=exp["fields"],
            field_budgets=exp["budgets"],
            experiment_name=exp["name"],
        )
        all_results.append(res)

        # Save incrementally
        pd.DataFrame(all_results).to_csv(results_file, index=False)
        print(f">>> Saved ({len(all_results)} total experiments)")

    # ── Final summary ─────────────────────────────────────────────────────
    print("\n" + "="*80)
    print("FINAL RESULTS — investigation_v6 (Field Permutations)")
    print("="*80)

    rdf = pd.DataFrame(all_results).sort_values("acc_mean", ascending=False)
    print(f"{'Experiment':<35} {'Fields':<35} {'Acc':<14} {'RMSE':<14}")
    print("-"*100)
    for _, r in rdf.iterrows():
        print(f"{r['experiment']:<35} {r['fields']:<35} "
              f"{r['acc_mean']:.4f}±{r['acc_std']:.4f} "
              f"{r['rmse_mean']:.4f}±{r['rmse_std']:.4f}")

    rdf.to_csv(results_file, index=False)
    print(f"\nSaved final results to: {results_file}")
