import os
import random
import html
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error
from transformers import AutoTokenizer, AutoModel

import sys
from pathlib import Path

# Add 'comparison' directory to python path if not present
comparison_dir = Path(__file__).resolve().parent
if str(comparison_dir) not in sys.path:
    sys.path.insert(0, str(comparison_dir))

from config import (
    DATA_PATH,
    SEED,
    QUESTION_COL,
    SOLUTION_COL,
    RUBRIC_COL,
    ANSWER_COL,
    SCORE_COL,
)

# Resolve DATA_PATH dynamically so it works from any Cwd
resolved_data_path = Path(DATA_PATH)
if not resolved_data_path.is_absolute() and not resolved_data_path.exists():
    resolved_data_path = comparison_dir / DATA_PATH
    if not resolved_data_path.exists():
        resolved_data_path = Path("comparison") / DATA_PATH

MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
N_FOLDS    = 5
RUBRIC_SCORE_COL = "rubric_score"

def set_seed(s):
    random.seed(s)
    np.random.seed(s)
    torch.manual_seed(s)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(s)

def normalize_text(text):
    if pd.isna(text):
        return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split()).lower()

def mean_pooling(model_output, attention_mask):
    token_embeddings = model_output[0]  # First element contains token embeddings
    input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
    return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

def get_embeddings(texts, model, tokenizer, device, batch_size=32):
    model.eval()
    all_embeddings = []
    
    # Process in batches to handle larger sizes cleanly
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i : i + batch_size]
        encoded = tokenizer(
            batch_texts,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors="pt"
        ).to(device)
        
        with torch.no_grad():
            outputs = model(**encoded)
            embeddings = mean_pooling(outputs, encoded["attention_mask"])
            # Normalize embeddings to unit length so dot product = cosine similarity
            embeddings = torch.nn.functional.normalize(embeddings, p=2, dim=1)
            all_embeddings.append(embeddings.cpu().numpy())
            
    return np.vstack(all_embeddings)

def run_sbert_baseline():
    set_seed(SEED)
    os.makedirs("results", exist_ok=True)
    
    # Check GPU availability
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device} | Model: {MODEL_NAME}")
    
    # Load dataset
    df = pd.read_csv(str(resolved_data_path))
    print(f"Loaded dataset: {len(df)} rows")
    
    # Normalize text fields
    for col in [ANSWER_COL, RUBRIC_COL, QUESTION_COL, SOLUTION_COL]:
        df[col] = df[col].apply(normalize_text)
        
    # Pre-load tokenizer and model to avoid loading them repeatedly
    print("Loading Sentence-BERT model and tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModel.from_pretrained(MODEL_NAME).to(device)
    
    # Pre-calculate embeddings for all unique answers and rubrics to optimize runtime
    print("Computing embeddings for student answers...")
    answers = df[ANSWER_COL].tolist()
    answer_embeddings = get_embeddings(answers, model, tokenizer, device)
    
    print("Computing embeddings for rubric texts...")
    rubrics = df[RUBRIC_COL].tolist()
    rubric_embeddings = get_embeddings(rubrics, model, tokenizer, device)
    
    # Calculate cosine similarity for all rows (vectorized dot product)
    print("Calculating cosine similarities...")
    similarities = np.sum(answer_embeddings * rubric_embeddings, axis=1)
    df["similarity"] = similarities
    
    # K-fold evaluation setup
    kf = KFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    
    # Lists to store metrics for both methods
    results_scaled = {"rmse": [], "mae": [], "acc": []}
    results_thresholded = {"rmse": [], "mae": [], "acc": []}
    optimal_thresholds = []
    
    # We will also save predictions for further error analysis
    df["pred_score_scaled"] = 0.0
    df["pred_score_thresholded"] = 0.0
    
    print(f"\nEvaluating with {N_FOLDS}-fold Cross-Validation...")
    for fold, (tr_idx, va_idx) in enumerate(kf.split(df), 1):
        train_fold_df = df.iloc[tr_idx].reset_index(drop=True)
        val_fold_df = df.iloc[va_idx].reset_index(drop=True)
        
        # ── Method 1: Continuous Cosine Scaling ──
        # Map: pred = max(0, similarity) * rubric_score
        val_sims = val_fold_df["similarity"].values
        val_rubric_scores = val_fold_df[RUBRIC_SCORE_COL].values
        val_targets = val_fold_df[SCORE_COL].values
        
        pred_scaled = np.maximum(0.0, val_sims) * val_rubric_scores
        # Save predictions
        df.loc[va_idx, "pred_score_scaled"] = pred_scaled
        
        # Metrics for Method 1
        rmse_s = np.sqrt(mean_squared_error(val_targets, pred_scaled))
        mae_s = mean_absolute_error(val_targets, pred_scaled)
        
        # Rounding for accuracy (to nearest in {0.0, 0.5, 1.0})
        def round_to_valid(val):
            valid_scores = np.array([0.0, 0.5, 1.0])
            return valid_scores[np.argmin(np.abs(valid_scores - val))]
            
        rounded_scaled = np.array([round_to_valid(p) for p in pred_scaled])
        acc_s = np.mean(rounded_scaled == val_targets)
        
        results_scaled["rmse"].append(rmse_s)
        results_scaled["mae"].append(mae_s)
        results_scaled["acc"].append(acc_s)
        
        # ── Method 2: Optimized Thresholding ──
        # Find optimal threshold on training set to minimize RMSE
        train_sims = train_fold_df["similarity"].values
        train_rubric_scores = train_fold_df[RUBRIC_SCORE_COL].values
        train_targets = train_fold_df[SCORE_COL].values
        
        best_threshold = 0.0
        best_train_rmse = float("inf")
        
        # Sweep threshold values from -1.0 to 1.0 with step 0.01
        for thresh in np.arange(-1.0, 1.01, 0.01):
            preds_train = np.where(train_sims >= thresh, train_rubric_scores, 0.0)
            rmse_train = np.sqrt(mean_squared_error(train_targets, preds_train))
            if rmse_train < best_train_rmse:
                best_train_rmse = rmse_train
                best_threshold = thresh
                
        optimal_thresholds.append(best_threshold)
        
        # Apply optimal threshold to validation fold
        pred_thresh = np.where(val_sims >= best_threshold, val_rubric_scores, 0.0)
        df.loc[va_idx, "pred_score_thresholded"] = pred_thresh
        
        # Metrics for Method 2
        rmse_t = np.sqrt(mean_squared_error(val_targets, pred_thresh))
        mae_t = mean_absolute_error(val_targets, pred_thresh)
        acc_t = np.mean(pred_thresh == val_targets)
        
        results_thresholded["rmse"].append(rmse_t)
        results_thresholded["mae"].append(mae_t)
        results_thresholded["acc"].append(acc_t)
        
        print(f"Fold {fold}: Opt Threshold = {best_threshold:.2f} | "
              f"Scaled RMSE = {rmse_s:.4f}, Acc = {acc_s:.4f} | "
              f"Thresh RMSE = {rmse_t:.4f}, Acc = {acc_t:.4f}")
              
    # ── Calculate Aggregates ──
    mean_rmse_s, std_rmse_s = np.mean(results_scaled["rmse"]), np.std(results_scaled["rmse"])
    mean_mae_s, mean_acc_s = np.mean(results_scaled["mae"]), np.mean(results_scaled["acc"])
    
    mean_rmse_t, std_rmse_t = np.mean(results_thresholded["rmse"]), np.std(results_thresholded["rmse"])
    mean_mae_t, mean_acc_t = np.mean(results_thresholded["mae"]), np.mean(results_thresholded["acc"])
    mean_opt_thresh = np.mean(optimal_thresholds)
    
    print("\n" + "=" * 65)
    print("SBERT COSINE SIMILARITY BASELINE RESULTS SUMMARY")
    print("=" * 65)
    print(f"Method 1: Continuous Cosine Scaling")
    print(f"  RMSE: {mean_rmse_s:.4f} ± {std_rmse_s:.4f}")
    print(f"  MAE:  {mean_mae_s:.4f}")
    print(f"  Acc:  {mean_acc_s:.4f}")
    print("-" * 65)
    print(f"Method 2: Optimized Threshold (Mean threshold = {mean_opt_thresh:.2f})")
    print(f"  RMSE: {mean_rmse_t:.4f} ± {std_rmse_t:.4f}")
    print(f"  MAE:  {mean_mae_t:.4f}")
    print(f"  Acc:  {mean_acc_t:.4f}")
    print("=" * 65)
    
    # Save the detailed predictions file
    predictions_path = "results/baseline_sbert_predictions.csv"
    df.to_csv(predictions_path, index=False)
    print(f"Saved detailed predictions to {predictions_path}")
    
    # Save the aggregate results directly to a new CSV file
    results_csv_path = "results/baseline_sbert_results.csv"
    results_summary_df = pd.DataFrame([
        {
            "model": "sbert-cosine-scaled",
            "mode": "unsupervised",
            "rmse_mean": mean_rmse_s,
            "rmse_std": std_rmse_s,
            "mae_mean": mean_mae_s,
            "acc_mean": mean_acc_s,
            "fold_rmses": str(results_scaled["rmse"]),
            "optimal_thresholds": "N/A"
        },
        {
            "model": "sbert-cosine-thresholded",
            "mode": "unsupervised",
            "rmse_mean": mean_rmse_t,
            "rmse_std": std_rmse_t,
            "mae_mean": mean_mae_t,
            "acc_mean": mean_acc_t,
            "fold_rmses": str(results_thresholded["rmse"]),
            "optimal_thresholds": str(optimal_thresholds)
        }
    ])
    
    results_summary_df.to_csv(results_csv_path, index=False)
    print(f"Saved aggregated baseline results to {results_csv_path}")

if __name__ == "__main__":
    run_sbert_baseline()
