# =============================================================================
# INVESTIGATION v2 — Disk-safe version for Google Colab (T4 GPU)
# Fix: delete checkpoints after each fold, save_only_model=True
# =============================================================================

import os, random, html, warnings, shutil, ast
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error
from datasets import Dataset
from transformers import (
    AutoConfig, BertConfig,
    AutoTokenizer, AutoModelForSequenceClassification,
    TrainingArguments, Trainer, DataCollatorWithPadding,
)

warnings.filterwarnings("ignore")

# ── Models ────────────────────────────────────────────────────────────────────
MODELS = {
    "xlm-roberta": "FacebookAI/xlm-roberta-base",
    "mdeberta":    "microsoft/mdeberta-v3-base",
    "gbert":       "deepset/gbert-base",
    "infoxlm":     "microsoft/infoxlm-base",
}

# ── Config ────────────────────────────────────────────────────────────────────
FIELD_BUDGETS = {"rubric": 55, "answer": 210, "solution": 172, "question": 70}
DATA_PATH     = "comparison/DATA/final_grading_dataset.csv"
QUESTION_COL  = "question"
SOLUTION_COL  = "solution"
RUBRIC_COL    = "rubric"
ANSWER_COL    = "answer"
SCORE_COL     = "target_score"
FIELD_COLS    = [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL]

MAX_LENGTH = 512
BATCH_SIZE = 16
EPOCHS     = 10
LR         = 3e-5
SEED       = 42
N_FOLDS    = 5

SCORE_TO_CLASS = {0.0: 0, 0.5: 1, 1.0: 2}
CLASS_TO_SCORE = {0: 0.0, 1: 0.5, 2: 1.0}

def set_seed(s):
    random.seed(s); np.random.seed(s); torch.manual_seed(s)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(s)

set_seed(SEED)
os.makedirs("results", exist_ok=True)
print("GPU:", torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CPU")


# ── Preprocessing ─────────────────────────────────────────────────────────────
def normalize_text(text):
    if pd.isna(text): return ""
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split()).lower()

def tokenize_with_budgets(batch, tokenizer):
    all_ids, all_masks = [], []
    for i in range(len(batch[RUBRIC_COL])):
        rubric_ids   = tokenizer.encode(batch[RUBRIC_COL][i],   add_special_tokens=False, max_length=FIELD_BUDGETS["rubric"],   truncation=True)
        answer_ids   = tokenizer.encode(batch[ANSWER_COL][i],   add_special_tokens=False, max_length=FIELD_BUDGETS["answer"],   truncation=True)
        solution_ids = tokenizer.encode(batch[SOLUTION_COL][i], add_special_tokens=False, max_length=FIELD_BUDGETS["solution"], truncation=True)
        question_ids = tokenizer.encode(batch[QUESTION_COL][i], add_special_tokens=False, max_length=FIELD_BUDGETS["question"], truncation=True)
        ids = ([tokenizer.cls_token_id]
               + rubric_ids   + [tokenizer.sep_token_id]
               + answer_ids   + [tokenizer.sep_token_id]
               + solution_ids + [tokenizer.sep_token_id]
               + question_ids + [tokenizer.sep_token_id])
        all_ids.append(ids)
        all_masks.append([1] * len(ids))
    return {"input_ids": all_ids, "attention_mask": all_masks}

def load_data():
    df = pd.read_csv(DATA_PATH)
    for col in FIELD_COLS:
        df[col] = df[col].apply(normalize_text)
    print(f"Dataset: {len(df)} samples")
    print(df[SCORE_COL].value_counts().sort_index().to_string())
    return df


# ── Metrics ───────────────────────────────────────────────────────────────────
def round_to_valid(s):
    v = np.array([0.0, 0.5, 1.0])
    return float(v[np.argmin(np.abs(v - s))])

def metrics_regression(eval_pred):
    preds, labels = eval_pred
    preds = preds.reshape(-1)
    labels = labels.reshape(-1)
    
    # Handle NaN values gracefully
    if np.isnan(preds).any() or np.isnan(labels).any():
        print("Warning: NaNs detected in predictions or labels!")
        preds = np.nan_to_num(preds, nan=0.0)
        labels = np.nan_to_num(labels, nan=0.0)
        rmse = 999.0
        mae = 999.0
        rounded_accuracy = 0.0
    else:
        preds = np.clip(preds, 0.0, 1.0)
        rmse = np.sqrt(mean_squared_error(labels, preds))
        rounded = np.array([round_to_valid(p) for p in preds])
        mae = mean_absolute_error(labels, preds)
        rounded_accuracy = np.mean(rounded == labels)
        
    return {"rmse": rmse,
            "mae":  mae,
            "rounded_accuracy": rounded_accuracy}

def metrics_classification(eval_pred):
    logits, labels = eval_pred
    if np.isnan(logits).any() or np.isnan(labels).any():
        print("Warning: NaNs detected in logits or labels!")
        logits = np.nan_to_num(logits, nan=0.0)
        labels = np.nan_to_num(labels, nan=0)
        
    pred_cls   = np.argmax(logits, axis=-1)
    pred_score = np.array([CLASS_TO_SCORE[p] for p in pred_cls])
    true_score = np.array([CLASS_TO_SCORE[int(l)] for l in labels])
    
    rmse = np.sqrt(mean_squared_error(true_score, pred_score))
    mae = mean_absolute_error(true_score, pred_score)
    rounded_accuracy = np.mean(pred_score == true_score)
    
    return {"rmse": rmse,
            "mae":  mae,
            "rounded_accuracy": rounded_accuracy}

class WeightedTrainer(Trainer):
    def __init__(self, class_weights, **kwargs):
        super().__init__(**kwargs)
        self.class_weights = class_weights

    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        labels = inputs.pop("labels")
        outputs = model(**inputs)
        # Dynamically move weights to the same device as the logits
        self.class_weights = self.class_weights.to(outputs.logits.device)
        loss = torch.nn.CrossEntropyLoss(weight=self.class_weights)(
            outputs.logits, labels
        )
        return (loss, outputs) if return_outputs else loss

def unfreeze_top_layers(model, num_layers_to_unfreeze=4):
    # First, freeze everything
    for param in model.parameters():
        param.requires_grad = False
        
    # Unfreeze classification head modules
    head_names = ["classifier", "score", "pooler"]
    for name, module in model.named_modules():
        if any(hn in name for hn in head_names):
            for param in module.parameters():
                param.requires_grad = True
                
    # Unfreeze top N transformer layers
    import re
    layer_pattern = re.compile(r"layer\.(\d+)\.")
    
    max_layer_idx = -1
    for name, _ in model.named_parameters():
        match = layer_pattern.search(name)
        if match:
            layer_idx = int(match.group(1))
            if layer_idx > max_layer_idx:
                max_layer_idx = layer_idx
                
    if max_layer_idx != -1:
        unfreeze_start_idx = max(0, max_layer_idx - num_layers_to_unfreeze + 1)
        print(f"  [Unfreezing] Max layer = {max_layer_idx}. Unfreezing layers >= {unfreeze_start_idx} and head modules.")
        for name, param in model.named_parameters():
            match = layer_pattern.search(name)
            if match:
                layer_idx = int(match.group(1))
                if layer_idx >= unfreeze_start_idx:
                    param.requires_grad = True
    else:
        print("  [Unfreezing] Could not detect numbered transformer layers. Unfreezing top 30% of parameters.")
        params = list(model.named_parameters())
        num_params = len(params)
        unfreeze_count = int(num_params * 0.3)
        for name, param in params[-unfreeze_count:]:
            param.requires_grad = True

def get_model_raw_predictions(model, df, tokenizer):
    model.eval()
    raw_scores = []
    with torch.no_grad():
        for idx, row in df.iterrows():
            q_text = normalize_text(row[QUESTION_COL])
            s_text = normalize_text(row[SOLUTION_COL])
            r_text = normalize_text(row[RUBRIC_COL])
            a_text = normalize_text(row[ANSWER_COL])
            
            q_ids = tokenizer.encode(q_text, add_special_tokens=False, max_length=FIELD_BUDGETS["question"], truncation=True)
            s_ids = tokenizer.encode(s_text, add_special_tokens=False, max_length=FIELD_BUDGETS["solution"], truncation=True)
            r_ids = tokenizer.encode(r_text, add_special_tokens=False, max_length=FIELD_BUDGETS["rubric"], truncation=True)
            full_a_ids = tokenizer.encode(a_text, add_special_tokens=False)
            
            window_size = FIELD_BUDGETS["answer"]
            overlap = 100
            chunks = []
            if len(full_a_ids) <= window_size:
                chunks.append(full_a_ids)
            else:
                step = window_size - overlap
                for start in range(0, len(full_a_ids), step):
                    chunk = full_a_ids[start:start+window_size]
                    chunks.append(chunk)
                    if start + window_size >= len(full_a_ids):
                        break
                        
            chunk_scores = []
            for chunk in chunks:
                input_ids = (
                    [tokenizer.cls_token_id]
                    + r_ids + [tokenizer.sep_token_id]
                    + chunk + [tokenizer.sep_token_id]
                    + s_ids + [tokenizer.sep_token_id]
                    + q_ids + [tokenizer.sep_token_id]
                )
                attention_mask = [1] * len(input_ids)
                input_tensor = torch.tensor([input_ids]).to(model.device)
                mask_tensor = torch.tensor([attention_mask]).to(model.device)
                
                outputs = model(input_ids=input_tensor, attention_mask=mask_tensor)
                score = outputs.logits.squeeze(-1).item()
                score = max(0.0, min(1.0, score))
                chunk_scores.append(score)
                
            best_score = max(chunk_scores) if chunk_scores else 0.0
            raw_scores.append(best_score)
    return np.array(raw_scores)

# ── Single fold trainer ───────────────────────────────────────────────────────
def train_fold(model_name, train_df, val_df, fold, model_key, mode):
    try:
        config = AutoConfig.from_pretrained(model_name)
    except ValueError as e:
        if "model_type" in str(e) and "gbert" in model_name:
            config = BertConfig.from_pretrained(model_name)
        else:
            raise e

    tokenizer = AutoTokenizer.from_pretrained(model_name, config=config)

    def make_ds(df):
        d = df.copy()
        d["labels"] = (d[SCORE_COL].astype(float) if mode == "regression"
                       else d[SCORE_COL].map(SCORE_TO_CLASS).astype(int))
        ds = Dataset.from_pandas(d[FIELD_COLS + ["labels"]].reset_index(drop=True))
        ds = ds.map(lambda b: tokenize_with_budgets(b, tokenizer), batched=True)
        return ds.remove_columns(FIELD_COLS)

    train_ds = make_ds(train_df)
    val_ds   = make_ds(val_df)

    num_labels = 1 if mode == "regression" else 3
    config.num_labels = num_labels
    config.problem_type = "regression" if mode == "regression" else "single_label_classification"


    counts = train_df[SCORE_COL].value_counts().sort_index()
    total  = len(train_df)
    weights = torch.tensor([total/counts[0.0], total/counts[0.5], total/counts[1.0]])
    weights = weights / weights.sum()
    device  = "cuda" if torch.cuda.is_available() else "cpu"
    weights = weights.to(device)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        config=config,
        ignore_mismatched_sizes=True,
    )

    # Unfreeze only classification head and top 4 transformer layers
    unfreeze_top_layers(model, num_layers_to_unfreeze=4)

    if mode == "classification":
        counts = train_df[SCORE_COL].value_counts().sort_index()
        total  = len(train_df)
        weights = torch.tensor([total/counts[0.0], total/counts[0.5], total/counts[1.0]])
        weights = weights / weights.sum()
        device  = "cuda" if torch.cuda.is_available() else "cpu"
        weights = weights.to(device)

    out_dir = f"/tmp/fold_{model_key}_{mode}_{fold}"  # /tmp — not counted in disk quota display

    # Use a lower learning rate specifically for DeBERTa models to ensure stability
    model_lr = LR
    if "deberta" in model_key or "deberta" in model_name:
        model_lr = 1.5e-5

    args = TrainingArguments(
        output_dir=out_dir,
        learning_rate=model_lr,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        num_train_epochs=EPOCHS,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=1,          # ← keep only the single best checkpoint
        load_best_model_at_end=True,
        metric_for_best_model="rmse",
        greater_is_better=False,
        logging_steps=40,
        report_to="none",
        seed=SEED,
        bf16=torch.cuda.is_available(),
        save_only_model=True,        # ← skip optimizer state (~50% disk saving)
        max_grad_norm=1.0,          # ← add gradient clipping for training stability
        warmup_ratio=0.1,            # ← add warmup to smoothly ramp up learning rate
    )

    common_kwargs = {
        "model": model,
        "args": args,
        "train_dataset": train_ds,
        "eval_dataset": val_ds,
        "processing_class": tokenizer,
        "data_collator": DataCollatorWithPadding(tokenizer),
        "compute_metrics": metrics_regression if mode == "regression" else metrics_classification,
    }


    trainer_kwargs = dict(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        compute_metrics=metrics_regression if mode == "regression" else metrics_classification,
    )

    if mode == "classification":
        trainer = WeightedTrainer(class_weights=weights, **trainer_kwargs)
    else:
        trainer = Trainer(**trainer_kwargs)

    trainer.train()

    # ── Custom sliding window and optimized threshold evaluation ──
    if mode == "regression":
        model.eval()
        
        # Optimize T1 and T2 on training fold
        print("  Optimizing thresholds T1 and T2 dynamically on the training set...")
        train_raw_scores = get_model_raw_predictions(model, train_df, tokenizer)
        train_labels = train_df[SCORE_COL].values
        
        best_t1, best_t2 = 0.23, 0.65
        best_train_rmse = float("inf")
        
        # Sweeping T1 and T2
        for t1 in np.arange(0.0, 0.55, 0.02):
            for t2 in np.arange(t1 + 0.02, 1.01, 0.02):
                preds = np.where(train_raw_scores < t1, 0.0, np.where(train_raw_scores <= t2, 0.5, 1.0))
                rmse = np.sqrt(mean_squared_error(train_labels, preds))
                if rmse < best_train_rmse:
                    best_train_rmse = rmse
                    best_t1, best_t2 = t1, t2
                    
        print(f"  [Dynamic Thresholds] Best T1 = {best_t1:.2f}, T2 = {best_t2:.2f} (Train RMSE = {best_train_rmse:.4f})")
        
        # Evaluate on validation fold
        val_raw_scores = get_model_raw_predictions(model, val_df, tokenizer)
        val_labels = val_df[SCORE_COL].values
        
        val_predictions = np.where(val_raw_scores < best_t1, 0.0, np.where(val_raw_scores <= best_t2, 0.5, 1.0))
        
        eval_rmse = np.sqrt(mean_squared_error(val_labels, val_predictions))
        eval_mae = mean_absolute_error(val_labels, val_predictions)
        eval_accuracy = np.mean(val_predictions == val_labels)
        
        print(f"  [Sliding Window + Dynamic Thresholds] Validation Accuracy: {eval_accuracy:.4f} | RMSE: {eval_rmse:.4f}")
    else:
        # Standard evaluation for classification mode
        res = trainer.evaluate()
        eval_rmse = res["eval_rmse"]
        eval_mae = res["eval_mae"]
        eval_accuracy = res["eval_rounded_accuracy"]

    # ── Free memory AND disk immediately after each fold ──────────────────────
    del model, trainer
    torch.cuda.empty_cache()
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)   # ← delete checkpoint, reclaim disk
    print(f"  Disk freed after fold {fold}")

    return eval_rmse, eval_mae, eval_accuracy




# ── K-fold runner ─────────────────────────────────────────────────────────────
def run_kfold(model_key, model_name, df, mode="regression"):
    print(f"\n{'='*65}")
    print(f"  {model_key.upper()} | {mode} | {N_FOLDS}-fold CV")
    print(f"{'='*65}")

    kf = KFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    rmses, maes, accs = [], [], []

    for fold, (tr_idx, va_idx) in enumerate(kf.split(df), 1):
        print(f"\n── Fold {fold}/{N_FOLDS} ──")
        rmse, mae, acc = train_fold(
            model_name,
            df.iloc[tr_idx].reset_index(drop=True),
            df.iloc[va_idx].reset_index(drop=True),
            fold, model_key, mode
        )
        rmses.append(rmse); maes.append(mae); accs.append(acc)
        print(f"  → RMSE={rmse:.4f}  MAE={mae:.4f}  Acc={acc:.4f}")

    print(f"\n[OK] {model_key} [{mode}]  RMSE: {np.mean(rmses):.4f} ± {np.std(rmses):.4f}"
          f"  |  Acc: {np.mean(accs):.4f}")

    return {"model": model_key, "mode": mode,
            "rmse_mean": np.mean(rmses), "rmse_std": np.std(rmses),
            "mae_mean":  np.mean(maes),  "acc_mean":  np.mean(accs),
            "fold_rmses": rmses}


if __name__ == "__main__":
    df = load_data()
    all_results = []
    results_file = "results/investigation_v2_results.csv"

    # Load existing results for resuming
    completed_runs = {}
    if os.path.exists(results_file):
        try:
            existing_df = pd.read_csv(results_file)
            for _, row in existing_df.iterrows():
                res_dict = row.to_dict()
                # Convert list back from string representation
                if "fold_rmses" in res_dict and isinstance(res_dict["fold_rmses"], str):
                    try:
                        res_dict["fold_rmses"] = ast.literal_eval(res_dict["fold_rmses"])
                    except Exception:
                        pass
                completed_runs[(res_dict["model"], res_dict["mode"])] = res_dict
            print(f"\n>>> Loaded {len(completed_runs)} completed configurations from {results_file}.")
        except Exception as e:
            print(f"\n>>> Could not load existing results: {e}. Starting fresh.")

    # Define all configurations to run
    experiments = []
    # Phase 1: regression vs classification on baseline models
    for mk in ["xlm-roberta", "mdeberta"]:
        # for mode in ["regression", "classification"]:
        for mode in ["regression"]:  # skip classification for now, focus on regression improvements
            experiments.append((mk, MODELS[mk], mode))
    # Phase 2: new models (regression only)
    # for mk in ["gbert", "infoxlm"]:
    for mk in ["gbert"]:  # skip infoxlm for now, focus on gbert which is more promising
        experiments.append((mk, MODELS[mk], "regression"))

    # Execute experiments
    for mk, model_name, mode in experiments:
        key = (mk, mode)
        if key in completed_runs:
            print(f"\n>>> Skipping {mk} ({mode}) — already completed in a previous run.")
            all_results.append(completed_runs[key])
        else:
            res = run_kfold(mk, model_name, df, mode)
            all_results.append(res)
            # Save incrementally
            pd.DataFrame(all_results).to_csv(results_file, index=False)
            print(f"\n>>> Saved intermediate results for {mk} ({mode}) to {results_file}")


    # ── Final table ───────────────────────────────────────────────────────────────
    print("\n" + "="*65)
    print("FINAL RESULTS")
    print("="*65)
    print(f"{'Model':<14} {'Mode':<16} {'RMSE mean±std':<22} {'Acc'}")
    print("-"*60)

    rdf = pd.DataFrame(all_results).sort_values("rmse_mean")
    for _, r in rdf.iterrows():
        print(f"{r['model']:<14} {r['mode']:<16} "
              f"{r['rmse_mean']:.4f} ± {r['rmse_std']:.4f}        {r['acc_mean']:.4f}")

    best = rdf.iloc[0]
    print(f"\n→ DECISION: Use  {best['model']}  with  {best['mode']}  head")
    print(f"  RMSE = {best['rmse_mean']:.4f} ± {best['rmse_std']:.4f}")

    # Save final sorted results
    rdf.to_csv(results_file, index=False)
    print(f"\nSaved final results to: {results_file}")
