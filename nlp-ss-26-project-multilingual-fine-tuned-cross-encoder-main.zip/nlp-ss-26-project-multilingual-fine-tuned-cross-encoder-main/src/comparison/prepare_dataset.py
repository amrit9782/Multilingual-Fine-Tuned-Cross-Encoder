import pandas as pd


QUESTIONS_PATH = "DATA/questions.csv"
ANSWERS_PATH = "DATA/answers.csv"
RUBRICS_PATH = "DATA/rubrics.csv"
ANSWER_RUBRICS_PATH = "DATA/answer_rubrics.csv"

OUTPUT_PATH = "DATA/final_grading_dataset.csv"


def main():
    questions = pd.read_csv(QUESTIONS_PATH)
    answers = pd.read_csv(ANSWERS_PATH)
    rubrics = pd.read_csv(RUBRICS_PATH)
    answer_rubrics = pd.read_csv(ANSWER_RUBRICS_PATH)

    # Rename columns to avoid confusion.
    answers = answers.rename(columns={
        "score": "answer_total_score"
    })

    rubrics = rubrics.rename(columns={
        "score": "rubric_score"
    })

    # answer_rubrics contains:
    # question_id, answer_id, rubric_id, label
    df = answer_rubrics.merge(
        answers,
        on=["question_id", "answer_id"],
        how="left"
    )

    df = df.merge(
        rubrics,
        on=["question_id", "rubric_id"],
        how="left"
    )

    df = df.merge(
        questions,
        on="question_id",
        how="left"
    )

    # Convert True/False labels into numeric rubric score.
    df["label"] = df["label"].astype(bool)

    df["target_score"] = df.apply(
        lambda row: row["rubric_score"] if row["label"] else 0.0,
        axis=1
    )

    final_columns = [
        "question_id",
        "answer_id",
        "rubric_id",
        "question",
        "solution",
        "rubric",
        "answer",
        "rubric_score",
        "label",
        "target_score",
        "answer_total_score",
        "max_score",
    ]

    df = df[final_columns]

    print("Final dataset shape:", df.shape)
    print(df.head())
    print("\nTarget score distribution:")
    print(df["target_score"].value_counts().sort_index())

    df.to_csv(OUTPUT_PATH, index=False)
    print(f"\nSaved final dataset to: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()