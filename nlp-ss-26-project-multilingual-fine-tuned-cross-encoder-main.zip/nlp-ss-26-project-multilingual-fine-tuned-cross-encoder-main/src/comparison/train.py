import os
import random
import html
import numpy as np
import pandas as pd
import torch

from datasets import Dataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error

from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer,
    DataCollatorWithPadding,
)

from config import (
    MODELS,
    DATA_PATH,
    QUESTION_COL,
    SOLUTION_COL,
    RUBRIC_COL,
    ANSWER_COL,
    SCORE_COL,
    MAX_LENGTH,
    BATCH_SIZE,
    EPOCHS,
    LEARNING_RATE,
    SEED,
    FIELD_BUDGETS,
)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def normalize_text(text):
    if pd.isna(text):
        return ""

    text = str(text)
    text = html.unescape(text)
    text = text.strip()
    text = " ".join(text.split())
    text = text.lower()

    return text


def load_dataset():
    df = pd.read_csv(DATA_PATH)

    print("Loaded data:", df.shape)
    print("Columns:", df.columns.tolist())

    # Normalise each field separately — keep them as columns, not merged string.
    # The tokenizer will handle concatenation with proper [SEP] tokens.
    for col in [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL]:
        df[col] = df[col].apply(normalize_text)

    df["labels"] = df[SCORE_COL].astype(float)

    train_df, val_df = train_test_split(
        df,
        test_size=0.2,
        random_state=SEED,
    )

    keep_cols = [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL, "labels"]

    train_dataset = Dataset.from_pandas(
        train_df[keep_cols].reset_index(drop=True)
    )
    val_dataset = Dataset.from_pandas(
        val_df[keep_cols].reset_index(drop=True)
    )

    return train_dataset, val_dataset


def tokenize_with_budgets(batch, tokenizer):
    """
    Tokenise each field with its own fixed token budget, then manually
    assemble:  [CLS] rubric [SEP] answer [SEP] solution [SEP] question [SEP]

    This guarantees every field gets space regardless of the others' lengths,
    matching the pipeline spec in the project .md file.
    """
    all_input_ids = []
    all_attention_masks = []

    rubric_budget   = FIELD_BUDGETS["rubric"]
    answer_budget   = FIELD_BUDGETS["answer"]
    solution_budget = FIELD_BUDGETS["solution"]
    question_budget = FIELD_BUDGETS["question"]

    batch_size = len(batch[RUBRIC_COL])

    for i in range(batch_size):
        # Encode each field without special tokens so we control placement.
        rubric_ids   = tokenizer.encode(batch[RUBRIC_COL][i],   add_special_tokens=False, max_length=rubric_budget,   truncation=True)
        answer_ids   = tokenizer.encode(batch[ANSWER_COL][i],   add_special_tokens=False, max_length=answer_budget,   truncation=True)
        solution_ids = tokenizer.encode(batch[SOLUTION_COL][i], add_special_tokens=False, max_length=solution_budget, truncation=True)
        question_ids = tokenizer.encode(batch[QUESTION_COL][i], add_special_tokens=False, max_length=question_budget, truncation=True)

        # Assemble: [CLS] rubric [SEP] answer [SEP] solution [SEP] question [SEP]
        input_ids = (
            [tokenizer.cls_token_id]
            + rubric_ids   + [tokenizer.sep_token_id]
            + answer_ids   + [tokenizer.sep_token_id]
            + solution_ids + [tokenizer.sep_token_id]
            + question_ids + [tokenizer.sep_token_id]
        )

        # Sanity check — should never exceed MAX_LENGTH given budget totals
        assert len(input_ids) <= MAX_LENGTH, (
            f"Input exceeded MAX_LENGTH ({len(input_ids)} > {MAX_LENGTH}). "
            f"Adjust FIELD_BUDGETS in config.py."
        )

        attention_mask = [1] * len(input_ids)

        all_input_ids.append(input_ids)
        all_attention_masks.append(attention_mask)

    return {
        "input_ids":      all_input_ids,
        "attention_mask": all_attention_masks,
    }


def tokenize_data(train_dataset, val_dataset, tokenizer):
    def _tokenize(batch):
        return tokenize_with_budgets(batch, tokenizer)

    field_cols = [RUBRIC_COL, ANSWER_COL, SOLUTION_COL, QUESTION_COL]

    train_dataset = train_dataset.map(_tokenize, batched=True)
    val_dataset   = val_dataset.map(_tokenize, batched=True)

    # Drop the raw text columns — model only needs input_ids, attention_mask, labels
    train_dataset = train_dataset.remove_columns(field_cols)
    val_dataset   = val_dataset.remove_columns(field_cols)

    return train_dataset, val_dataset


def round_to_valid_score(score):
    valid_scores = np.array([0.0, 0.5, 1.0])
    closest_index = np.argmin(np.abs(valid_scores - score))
    return float(valid_scores[closest_index])


def compute_metrics(eval_pred):
    predictions, labels = eval_pred

    predictions = predictions.reshape(-1)
    labels = labels.reshape(-1)

    predictions = np.clip(predictions, 0.0, 1.0)

    mse = mean_squared_error(labels, predictions)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(labels, predictions)

    rounded_predictions = np.array(
        [round_to_valid_score(pred) for pred in predictions]
    )

    rounded_accuracy = np.mean(rounded_predictions == labels)

    return {
        "rmse": rmse,
        "mae": mae,
        "rounded_accuracy": rounded_accuracy,
    }

def unfreeze_top_layers(model, num_layers_to_unfreeze=4):
    # First, freeze everything
    for param in model.parameters():
        param.requires_grad = False
        
    # Unfreeze classification head modules
    head_names = ["classifier", "score", "pooler"]
    for name, module in model.named_modules():
        if any(hn in name for hn in head_names):
            for param in module.parameters():
                param.requires_grad = True
                
    # Unfreeze top N transformer layers
    import re
    layer_pattern = re.compile(r"layer\.(\d+)\.")
    
    max_layer_idx = -1
    for name, _ in model.named_parameters():
        match = layer_pattern.search(name)
        if match:
            layer_idx = int(match.group(1))
            if layer_idx > max_layer_idx:
                max_layer_idx = layer_idx
                
    if max_layer_idx != -1:
        unfreeze_start_idx = max(0, max_layer_idx - num_layers_to_unfreeze + 1)
        print(f"  [Unfreezing] Max layer = {max_layer_idx}. Unfreezing layers >= {unfreeze_start_idx} and head modules.")
        for name, param in model.named_parameters():
            match = layer_pattern.search(name)
            if match:
                layer_idx = int(match.group(1))
                if layer_idx >= unfreeze_start_idx:
                    param.requires_grad = True
    else:
        print("  [Unfreezing] Could not detect numbered transformer layers. Unfreezing top 30% of parameters.")
        params = list(model.named_parameters())
        num_params = len(params)
        unfreeze_count = int(num_params * 0.3)
        for name, param in params[-unfreeze_count:]:
            param.requires_grad = True


def train_one_model(model_key, model_name):
    print("=" * 80)
    print("Training:", model_key)
    print("Model checkpoint:", model_name)
    print("=" * 80)

    train_dataset, val_dataset = load_dataset()

    tokenizer = AutoTokenizer.from_pretrained(model_name)

    train_dataset, val_dataset = tokenize_data(
        train_dataset,
        val_dataset,
        tokenizer,
    )

    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        num_labels=1,
        problem_type="regression",
        torch_dtype=torch.float16, 
    )

    # Unfreeze only classification head and top 4 transformer layers
    unfreeze_top_layers(model, num_layers_to_unfreeze=4)

    data_collator = DataCollatorWithPadding(tokenizer=tokenizer)

    output_dir = f"results/{model_key}"

    training_args = TrainingArguments(
        output_dir=output_dir,
        learning_rate=LEARNING_RATE,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        num_train_epochs=EPOCHS,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="epoch",
        logging_strategy="steps",
        logging_steps=10,
        load_best_model_at_end=True,
        metric_for_best_model="rmse",
        greater_is_better=False,
        report_to="none",
        # fp16=True,                         # halves forward/backward memory
        bf16=True,
        gradient_checkpointing=False,
        optim="adafactor", 
        seed=SEED,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        processing_class=tokenizer,
        data_collator=data_collator,
        compute_metrics=compute_metrics,
    )

    trainer.train()

    results = trainer.evaluate()

    os.makedirs("results", exist_ok=True)

    with open(f"results/{model_key}_results.txt", "w") as f:
        for key, value in results.items():
            f.write(f"{key}: {value}\n")

    trainer.save_model(f"results/{model_key}/best_model")
    tokenizer.save_pretrained(f"results/{model_key}/best_model")

    if model_key == "xlm-roberta":
        app_best_model_dir = "../app/best_model"
        os.makedirs(app_best_model_dir, exist_ok=True)
        trainer.save_model(app_best_model_dir)
        tokenizer.save_pretrained(app_best_model_dir)
        print(f"Saved best production model also to: {app_best_model_dir}")

    print("Final results:")
    print(results)

    return results


def main():
    set_seed(SEED)

    all_results = {}

    for model_key, model_name in MODELS.items():
        results = train_one_model(model_key, model_name)
        all_results[model_key] = results

    print("\nFinal comparison:")
    for model_key, results in all_results.items():
        print(model_key, results)


if __name__ == "__main__":
    main()