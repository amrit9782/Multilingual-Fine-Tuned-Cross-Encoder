"""
grader.py - Production grading service using a fine-tuned cross-encoder.

Model loading priority:
  1. Local ./best_model/ directory (if it exists and is non-empty)
  2. HuggingFace Hub via MODEL_REPO + HF_TOKEN environment variables
  3. Fallback to xlm-roberta-base (untrained, for smoke-testing only)

Environment variables (set in .env):
  MODEL_REPO   - HuggingFace repo ID, e.g. "amrit97/xlm-roberta-large-grader-v9"
  HF_TOKEN     - HuggingFace access token (required for private repos)
  USE_PREFIX   - "true" if model was trained with is_ternary prefix (default: false)
  FIELD_COLS   - comma-separated field order, e.g. "rubric,answer" (default: rubric,answer)
  T_BINARY     - threshold for binary rubrics (default: 0.45)
  T1_TERNARY   - lower threshold for ternary rubrics (default: 0.25)
  T2_TERNARY   - upper threshold for ternary rubrics (default: 0.75)
"""

import html
import os

import numpy as np
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from models import (
    AnswerResult,
    Decision,
    GradeRequest,
    GradeResponse,
    RubricDecision,
)

# =============================================================================
# CONFIG FROM ENVIRONMENT
# =============================================================================
MODEL_REPO  = os.environ.get("MODEL_REPO", "")
HF_TOKEN    = os.environ.get("HF_TOKEN", "")
USE_PREFIX  = os.environ.get("USE_PREFIX", "false").lower() == "true"
FIELD_COLS  = [c.strip() for c in os.environ.get("FIELD_COLS", "rubric,answer").split(",")]
T_BINARY    = float(os.environ.get("T_BINARY",   "0.45"))
T1_TERNARY  = float(os.environ.get("T1_TERNARY", "0.25"))
T2_TERNARY  = float(os.environ.get("T2_TERNARY", "0.75"))


# =============================================================================
# MODEL LOADING (once at startup)
# =============================================================================
def _load_model():
    """
    Load tokenizer and model. Tries local path first, then HF Hub, then fallback.
    Returns (tokenizer, model, use_prefix, field_cols, t_binary, t1, t2).
    """
    use_prefix = USE_PREFIX
    field_cols = FIELD_COLS
    t_binary   = T_BINARY
    t1_ternary = T1_TERNARY
    t2_ternary = T2_TERNARY

    local_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "best_model")
    model_source = None

    # 1. Try local best_model/
    if os.path.exists(local_path) and os.listdir(local_path):
        model_source = local_path
        print(f">>> Loading model from local: {local_path}")
    # 2. Try HF Hub
    elif MODEL_REPO:
        from huggingface_hub import snapshot_download
        print(f">>> Downloading model from HuggingFace Hub: {MODEL_REPO}")
        model_source = snapshot_download(
            repo_id=MODEL_REPO,
            token=HF_TOKEN or None,
            cache_dir="/tmp/model_cache",
        )
        print(f">>> Download complete: {model_source}")
    # 3. Fallback
    else:
        model_source = "FacebookAI/xlm-roberta-base"
        print(f">>> WARNING: no local model and no MODEL_REPO set. Using untrained fallback.")

    tokenizer = AutoTokenizer.from_pretrained(model_source)
    model = AutoModelForSequenceClassification.from_pretrained(model_source)

    # Load thresholds.txt if present (colleague's format)
    thresholds_txt = os.path.join(local_path if local_path == model_source else "", "thresholds.txt")
    if os.path.exists(thresholds_txt):
        try:
            with open(thresholds_txt) as f:
                for line in f:
                    if "=" in line:
                        key, val = line.strip().split("=", 1)
                        if key == "T1":      t1_ternary = float(val)
                        elif key == "T2":    t2_ternary = float(val)
                        elif key == "LAYOUT": field_cols = [c.strip() for c in val.split(",")]
            print(f">>> Loaded thresholds.txt: T1={t1_ternary}, T2={t2_ternary}, layout={field_cols}")
        except Exception as e:
            print(f">>> Could not read thresholds.txt: {e}. Using defaults.")

    # Load thresholds.json if present (v10 format)
    thresholds_json = os.path.join(
        model_source if isinstance(model_source, str) and os.path.isdir(model_source) else "",
        "thresholds.json"
    )
    if os.path.exists(thresholds_json):
        import json
        with open(thresholds_json) as f:
            th = json.load(f)
        t_binary   = th.get("binary_threshold", t_binary)
        t1_ternary = th.get("ternary_t1", t1_ternary)
        t2_ternary = th.get("ternary_t2", t2_ternary)
        print(f">>> Loaded thresholds.json: binary={t_binary}, t1={t1_ternary}, t2={t2_ternary}")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()

    n_labels = model.config.num_labels
    n_params = sum(p.numel() for p in model.parameters())
    print(f">>> Model ready: {n_labels} label(s) ({'CORAL' if n_labels == 2 else 'MSE'}), "
          f"{n_params:,} params, device={device}")
    print(f">>> Config: fields={field_cols}, prefix={use_prefix}, "
          f"T_binary={t_binary}, T1={t1_ternary}, T2={t2_ternary}")

    return tokenizer, model, device, use_prefix, field_cols, t_binary, t1_ternary, t2_ternary


tokenizer, model, device, USE_PREFIX, FIELD_COLS, T_BINARY, T1_TERNARY, T2_TERNARY = _load_model()


# =============================================================================
# TEXT PREPROCESSING
# =============================================================================
def normalize_text(text):
    """Match training preprocessing exactly."""
    if text is None: return ""
    try:
        import pandas as pd
        if pd.isna(text): return ""
    except Exception:
        pass
    text = html.unescape(str(text))
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    return " ".join(text.strip().split())


# =============================================================================
# TOKENIZATION
# =============================================================================
def build_input_ids(rubric_text, question_text, answer_text):
    """Dynamic budget tokenization: rubric never truncated, answer first to be cut."""
    encoded = {
        "rubric":   tokenizer.encode(rubric_text,   add_special_tokens=False),
        "question": tokenizer.encode(question_text, add_special_tokens=False),
        "answer":   tokenizer.encode(answer_text,   add_special_tokens=False),
    }
    special_count = len(FIELD_COLS) + 1
    total = sum(len(encoded.get(c, [])) for c in FIELD_COLS) + special_count

    if total > 512:
        budget = 512 - special_count
        rubric_len   = len(encoded.get("rubric",   []))
        question_len = len(encoded.get("question", []))
        solution_len = len(encoded.get("solution", []))

        if "answer" in encoded:
            answer_budget = max(80, budget - rubric_len - question_len - solution_len)
            encoded["answer"] = encoded["answer"][:answer_budget]

        new_total = sum(len(t) for t in encoded.values()) + special_count
        if new_total > 512 and "solution" in encoded:
            answer_len = len(encoded["answer"]) if "answer" in encoded else 0
            solution_budget = max(50, 512 - special_count - rubric_len - question_len - answer_len)
            encoded["solution"] = encoded["solution"][:solution_budget]

        new_total = sum(len(encoded.get(c, [])) for c in FIELD_COLS) + special_count
        if new_total > 512 and "question" in encoded:
            used = rubric_len + len(encoded["answer"])
            encoded["question"] = encoded["question"][:max(30, budget - used)]

    ids = [tokenizer.cls_token_id]
    for col in FIELD_COLS:
        ids += encoded.get(col, []) + [tokenizer.sep_token_id]
    return ids


# =============================================================================
# DECISION MAPPING
# =============================================================================
def score_to_decision(score: float, is_ternary: bool) -> Decision:
    """
    Type-aware threshold mapping.
    Binary rubrics: only yes/no. Never half (1.0 is an impossible label).
    Ternary rubrics: yes/half/no based on two thresholds.
    """
    if is_ternary:
        if score < T1_TERNARY:
            return Decision.no
        elif score <= T2_TERNARY:
            return Decision.half
        else:
            return Decision.yes
    else:
        # Binary: never return half
        return Decision.yes if score >= T_BINARY else Decision.no


# =============================================================================
# GRADE FUNCTION
# =============================================================================
def grade(request: GradeRequest) -> GradeResponse:
    """
    Grade all student answers against all rubrics.

    Batches all (answer, rubric) pairs together for efficient GPU inference.
    Returns decisions in the same order as the input lists.
    """
    question_text = normalize_text(request.question)

    # Build all (answer, rubric) pairs
    all_ids, all_masks, pair_indices = [], [], []
    for a_idx, answer in enumerate(request.student_answers):
        answer_text = normalize_text(answer.text)
        for r_idx, rubric in enumerate(request.rubrics):
            rubric_text = normalize_text(rubric.text)

            # Add is_ternary prefix if model was trained with it
            if USE_PREFIX:
                prefix = "ternary: " if rubric.is_ternary else "binary: "
                rubric_text = prefix + rubric_text

            ids = build_input_ids(rubric_text, question_text, answer_text)
            all_ids.append(ids)
            all_masks.append([1] * len(ids))
            pair_indices.append((a_idx, r_idx))

    # Batch inference
    scores = []
    batch_size = 8  # conservative for large model on CPU
    with torch.no_grad():
        for i in range(0, len(all_ids), batch_size):
            batch_ids   = all_ids[i:i + batch_size]
            batch_masks = all_masks[i:i + batch_size]

            max_len     = max(len(ids) for ids in batch_ids)
            pad_id      = tokenizer.pad_token_id or 1
            padded_ids  = [ids + [pad_id] * (max_len - len(ids)) for ids in batch_ids]
            padded_masks= [m   + [0]      * (max_len - len(m))   for m   in batch_masks]

            ids_tensor  = torch.tensor(padded_ids).to(device)
            mask_tensor = torch.tensor(padded_masks).to(device)

            logits = model(input_ids=ids_tensor, attention_mask=mask_tensor).logits

            if model.config.num_labels == 2:
                # CORAL: 2-logit output
                probs = torch.sigmoid(logits)
                batch_scores = (0.5 * probs[:, 0] + 0.5 * probs[:, 1]).cpu().numpy()
            else:
                # MSE: single logit
                batch_scores = logits.squeeze(-1).cpu().numpy()
                batch_scores = np.clip(batch_scores, 0.0, 1.0)

            scores.extend(batch_scores.tolist())

    # Assemble results
    rubric_decisions_by_answer = [[] for _ in range(len(request.student_answers))]
    for idx, (a_idx, r_idx) in enumerate(pair_indices):
        rubric   = request.rubrics[r_idx]
        decision = score_to_decision(scores[idx], rubric.is_ternary)
        rubric_decisions_by_answer[a_idx].append(
            RubricDecision(rubric_id=rubric.id, decision=decision)
        )

    return GradeResponse(
        question_id=request.question_id,
        results=[
            AnswerResult(
                answer_id=request.student_answers[a_idx].id,
                rubric_decisions=rubric_decisions_by_answer[a_idx],
            )
            for a_idx in range(len(request.student_answers))
        ],
    )