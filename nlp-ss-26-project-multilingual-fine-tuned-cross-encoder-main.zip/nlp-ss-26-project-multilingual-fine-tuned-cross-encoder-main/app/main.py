import asyncio

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from grader import grade
from models import GradeRequest, GradeResponse

app = FastAPI(title="NLP Grader")


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/grade", response_model=GradeResponse)
async def grade_endpoint(request: GradeRequest) -> GradeResponse:
    return await asyncio.to_thread(grade, request)
