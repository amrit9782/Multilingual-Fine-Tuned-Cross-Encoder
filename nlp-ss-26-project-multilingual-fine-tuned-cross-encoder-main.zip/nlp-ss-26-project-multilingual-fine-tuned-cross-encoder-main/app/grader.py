"""
grader_final.py - Production grading service tailored for v11 and future models.

Model loading priority:
  1. Local MODEL_PATH directory (if it exists and is non-empty)
  2. HuggingFace Hub via MODEL_REPO + HF_TOKEN environment variables
  3. remote MODEL_PATH if it specifies a HuggingFace repository ID
  4. Fallback to xlm-roberta-base (untrained)

Environment variables (set in .env):
  MODEL_REPO   - HuggingFace repo ID, e.g. "amrit97/xlm-roberta-base-grader-v11"
  MODEL_PATH   - Local model path (default: ./best_model)
  HF_TOKEN     - HuggingFace access token (required for private repos)
  USE_PREFIX   - "true" if model was trained with is_ternary prefix (default: false)
  FIELD_COLS   - comma-separated field order, e.g. "rubric,answer" (default: rubric,answer)
  T_BINARY     - threshold for binary rubrics (default: 0.5)
  T1_TERNARY   - lower threshold for ternary rubrics (default: 0.22)
  T2_TERNARY   - upper threshold for ternary rubrics (default: 0.69)
"""

import os
import sys
import html
import re
import numpy as np
import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from models import (
    AnswerResult,
    Decision,
    GradeRequest,
    GradeResponse,
    RubricDecision,
)

# =============================================================================
# CONFIG FROM ENVIRONMENT
# =============================================================================
MODEL_REPO  = os.environ.get("MODEL_REPO", "")
MODEL_PATH  = os.environ.get("MODEL_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "best_model"))
HF_TOKEN    = os.environ.get("HF_TOKEN", "")
USE_PREFIX  = os.environ.get("USE_PREFIX", "false").lower() == "true"
FIELD_COLS  = [c.strip() for c in os.environ.get("FIELD_COLS", "rubric,answer").split(",")]
T_BINARY    = float(os.environ.get("T_BINARY",   "0.5"))
T1_TERNARY  = float(os.environ.get("T1_TERNARY", "0.22"))
T2_TERNARY  = float(os.environ.get("T2_TERNARY", "0.69"))


# =============================================================================
# MODEL LOADING (once at startup)
# =============================================================================
def _load_model():
    """
    Load tokenizer and model. Tries local path first, then HF Hub, then fallback.
    Returns (tokenizer, model, device, use_prefix, field_cols, t_binary, t1_ternary, t2_ternary).
    """
    use_prefix = USE_PREFIX
    field_cols = FIELD_COLS
    t_binary   = T_BINARY
    t1_ternary = T1_TERNARY
    t2_ternary = T2_TERNARY

    model_source = None

    # 1. Try local MODEL_PATH first
    if os.path.exists(MODEL_PATH) and os.path.isdir(MODEL_PATH) and os.listdir(MODEL_PATH):
        model_source = MODEL_PATH
        print(f">>> Loading model from local: {MODEL_PATH}")
    # 2. Try MODEL_REPO from environment
    elif MODEL_REPO:
        from huggingface_hub import snapshot_download
        print(f">>> Downloading model from HuggingFace Hub (MODEL_REPO): {MODEL_REPO}")
        try:
            model_source = snapshot_download(
                repo_id=MODEL_REPO,
                token=HF_TOKEN or None,
                cache_dir="/tmp/model_cache",
            )
            print(f">>> Download complete: {model_source}")
        except Exception as e:
            print(f">>> Error downloading from MODEL_REPO: {e}. Trying fallback.")
    # 3. Check if MODEL_PATH itself looks like a remote HF repo
    elif "/" in MODEL_PATH and not MODEL_PATH.startswith("/") and not MODEL_PATH.startswith("."):
        from huggingface_hub import snapshot_download
        print(f">>> Downloading model from HuggingFace Hub (MODEL_PATH): {MODEL_PATH}")
        try:
            model_source = snapshot_download(
                repo_id=MODEL_PATH,
                token=HF_TOKEN or None,
                cache_dir="/tmp/model_cache",
            )
            print(f">>> Download complete: {model_source}")
        except Exception as e:
            print(f">>> Error downloading from MODEL_PATH as repo: {e}. Trying fallback.")

    # 4. Fallback
    if not model_source:
        model_source = "FacebookAI/xlm-roberta-base"
        print(f">>> WARNING: No valid local model or remote repo found. Using fallback: {model_source}")

    tokenizer = AutoTokenizer.from_pretrained(model_source)
    model = AutoModelForSequenceClassification.from_pretrained(model_source)

    # Attempt to load thresholds.txt if present (colleague's format)
    thresholds_txt = os.path.join(model_source if os.path.isdir(model_source) else "", "thresholds.txt")
    if os.path.exists(thresholds_txt):
        try:
            with open(thresholds_txt, "r") as f:
                for line in f:
                    if "=" in line:
                        key, val = line.strip().split("=", 1)
                        if key == "T1":      t1_ternary = float(val)
                        elif key == "T2":    t2_ternary = float(val)
                        elif key == "LAYOUT": field_cols = [c.strip() for c in val.split(",")]
            print(f">>> Loaded thresholds.txt: T1={t1_ternary}, T2={t2_ternary}, layout={field_cols}")
        except Exception as e:
            print(f">>> Could not read thresholds.txt: {e}. Using defaults.")

    # Attempt to load thresholds.json if present (v10 format)
    thresholds_json = os.path.join(model_source if os.path.isdir(model_source) else "", "thresholds.json")
    if os.path.exists(thresholds_json):
        try:
            import json
            with open(thresholds_json, "r") as f:
                th = json.load(f)
            t_binary   = th.get("binary_threshold", t_binary)
            t1_ternary = th.get("ternary_t1", t1_ternary)
            t2_ternary = th.get("ternary_t2", t2_ternary)
            print(f">>> Loaded thresholds.json: binary={t_binary}, t1={t1_ternary}, t2={t2_ternary}")
        except Exception as e:
            print(f">>> Could not read thresholds.json: {e}. Using defaults.")

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()

    n_labels = model.config.num_labels
    n_params = sum(p.numel() for p in model.parameters())
    print(f">>> Model ready: {n_labels} label(s) ({'CORAL' if n_labels == 2 else 'MSE'}), "
          f"{n_params:,} params, device={device}")
    print(f">>> Config: fields={field_cols}, prefix={use_prefix}, "
          f"T_binary={t_binary}, T1={t1_ternary}, T2={t2_ternary}")

    return tokenizer, model, device, use_prefix, field_cols, t_binary, t1_ternary, t2_ternary


tokenizer, model, device, USE_PREFIX, FIELD_COLS, T_BINARY, T1_TERNARY, T2_TERNARY = _load_model()


# =============================================================================
# TEXT PREPROCESSING (v11 math normalization)
# =============================================================================
def normalize_text(text):
    if text is None: return ""
    try:
        import pandas as pd
        if pd.isna(text): return ""
    except Exception:
        pass
    text = str(text)
    text = html.unescape(text)
    text = text.replace("###", "").replace("##", "").replace("#", "")
    text = text.replace("\n", " ").replace("\r", " ")
    
    # Strip Jupyter boilerplate template text
    text = re.sub(r"-?\s*This cell supports \*Markdown\* and Math:\s*(\$\s*\\*alpha\^2\s*\$)?\s*", "", text, flags=re.IGNORECASE)
    
    # Translate common LaTeX symbols/functions to plain text
    latex_replacements = {
        "\\frac{": " ( ",
        "}{": " ) / ( ",
        "\\sigma": "sigma",
        "\\alpha": "alpha",
        "\\beta": "beta",
        "\\gamma": "gamma",
        "\\mu": "mu",
        "\\rho": "rho",
        "\\Sigma": "Sigma",
        "\\Omega": "Omega",
        "\\sum": "sum",
        "\\dots": "...",
        "\\cdot": " * ",
        "\\geq": " >= ",
        "\\ge": " >= ",
        "\\leq": " <= ",
        "\\le": " <= ",
        "\\implies": " => ",
        "\\in": " in ",
        "\\infty": "infinity",
        "\\cup": " union ",
        "\\cap": " intersection ",
        "\\emptyset": "empty_set",
        "\\space": " ",
        "\\text": " ",
        "\\B": "B",
        "$$": " ",
        "$": " ",
        "{": " ( ",
        "}": " ) "
    }
    for pattern, replacement in latex_replacements.items():
        text = text.replace(pattern, replacement)
        
    # Pad mathematical operators with spaces
    for op in ["=", "+", "*", "/"]:
        text = text.replace(op, f" {op} ")
        
    return " ".join(text.strip().split())


# =============================================================================
# TOKENIZATION
# =============================================================================
def build_input_ids(rubric_text, question_text, answer_text, solution_text):
    """Dynamic budget tokenization: rubric never truncated, answer first to be cut."""
    encoded = {}
    if "rubric" in FIELD_COLS:
        encoded["rubric"] = tokenizer.encode(rubric_text, add_special_tokens=False)
    if "question" in FIELD_COLS:
        encoded["question"] = tokenizer.encode(question_text, add_special_tokens=False)
    if "answer" in FIELD_COLS:
        encoded["answer"] = tokenizer.encode(answer_text, add_special_tokens=False)
    if "solution" in FIELD_COLS:
        encoded["solution"] = tokenizer.encode(solution_text, add_special_tokens=False)

    special_count = len(FIELD_COLS) + 1
    lengths = {col: len(tokens) for col, tokens in encoded.items()}
    total = sum(lengths.values()) + special_count

    if total > 512:
        budget = 512 - special_count
        rubric_len = lengths.get("rubric", 0)
        question_len = lengths.get("question", 0)
        solution_len = lengths.get("solution", 0)

        if "answer" in encoded:
            answer_budget = max(80, budget - (rubric_len + question_len + solution_len))
            encoded["answer"] = encoded["answer"][:answer_budget]

        new_total = sum(len(t) for t in encoded.values()) + special_count
        if new_total > 512 and "solution" in encoded:
            answer_len = len(encoded["answer"]) if "answer" in encoded else 0
            solution_budget = max(50, 512 - special_count - rubric_len - question_len - answer_len)
            encoded["solution"] = encoded["solution"][:solution_budget]

        new_total = sum(len(t) for t in encoded.values()) + special_count
        if new_total > 512 and "question" in encoded:
            answer_len = len(encoded["answer"]) if "answer" in encoded else 0
            solution_len = len(encoded["solution"]) if "solution" in encoded else 0
            question_budget = max(30, 512 - special_count - rubric_len - solution_len - answer_len)
            encoded["question"] = encoded["question"][:question_budget]

    ids = [tokenizer.cls_token_id]
    for col in FIELD_COLS:
        if col in encoded:
            ids += encoded[col] + [tokenizer.sep_token_id]
    return ids


# =============================================================================
# DECISION MAPPING
# =============================================================================
def score_to_decision(score: float, is_ternary: bool) -> Decision:
    """
    Type-aware threshold mapping.
    Binary rubrics: only yes/no (never half).
    Ternary rubrics: yes/half/no based on T1 and T2 thresholds.
    """
    if is_ternary:
        if score < T1_TERNARY:
            return Decision.no
        elif score <= T2_TERNARY:
            return Decision.half
        else:
            return Decision.yes
    else:
        return Decision.yes if score >= T_BINARY else Decision.no


# =============================================================================
# GRADE FUNCTION
# =============================================================================
def grade(request: GradeRequest) -> GradeResponse:
    """
    Grade all student answers against all rubrics.
    Batches all (answer, rubric) pairs together for efficient GPU/CPU inference.
    """
    question_text = normalize_text(request.question)
    solution_text = normalize_text(request.solution) if request.solution else ""

    # Store decisions by student answer index
    rubric_decisions_by_answer = [[] for _ in range(len(request.student_answers))]

    # Build all pairs that require inference, bypassing noise/empty answers
    pairs = []
    for a_idx, answer in enumerate(request.student_answers):
        answer_text = normalize_text(answer.text)
        
        # Check if the answer is invalid/placeholder/noise (e.g. empty or a single non-alphanumeric char like '~')
        answer_stripped = answer_text.strip()
        if len(answer_stripped) == 0 or (len(answer_stripped) <= 1 and not answer_stripped.isalnum()):
            # Direct Decision.no for all rubrics of this noise/empty answer
            for rubric in request.rubrics:
                rubric_decisions_by_answer[a_idx].append(
                    RubricDecision(rubric_id=rubric.id, decision=Decision.no)
                )
            continue

        for r_idx, rubric in enumerate(request.rubrics):
            rubric_text = normalize_text(rubric.text)

            # Prepend binary/ternary prefix if USE_PREFIX is enabled
            if USE_PREFIX:
                prefix = "ternary: " if rubric.is_ternary else "binary: "
                rubric_text = prefix + rubric_text

            pairs.append({
                "rubric": rubric_text,
                "answer": answer_text,
                "solution": solution_text,
                "question": question_text,
                "a_idx": a_idx,
                "r_idx": r_idx
            })

    # Batch inference
    if pairs:
        all_ids = []
        all_masks = []
        for pair in pairs:
            ids = build_input_ids(pair["rubric"], pair["question"], pair["answer"], pair["solution"])
            all_ids.append(ids)
            all_masks.append([1] * len(ids))

        scores = []
        batch_size = 8  # conservative default for CPU/GPU
        with torch.no_grad():
            for i in range(0, len(all_ids), batch_size):
                batch_ids   = all_ids[i:i + batch_size]
                batch_masks = all_masks[i:i + batch_size]

                max_len     = max(len(ids) for ids in batch_ids)
                pad_id      = tokenizer.pad_token_id or 1
                padded_ids  = [ids + [pad_id] * (max_len - len(ids)) for ids in batch_ids]
                padded_masks= [m   + [0]      * (max_len - len(m))   for m   in batch_masks]

                ids_tensor  = torch.tensor(padded_ids).to(device)
                mask_tensor = torch.tensor(padded_masks).to(device)

                logits = model(input_ids=ids_tensor, attention_mask=mask_tensor).logits

                if model.config.num_labels == 2:
                    # CORAL: 2-logit output
                    probs = torch.sigmoid(logits)
                    batch_scores = (0.5 * probs[:, 0] + 0.5 * probs[:, 1]).cpu().numpy()
                else:
                    # MSE: single logit
                    batch_scores = logits.squeeze(-1).cpu().numpy()
                    batch_scores = np.clip(batch_scores, 0.0, 1.0)

                scores.extend(batch_scores.tolist())

        # Assemble results
        for idx, score in enumerate(scores):
            pair = pairs[idx]
            a_idx = pair["a_idx"]
            r_idx = pair["r_idx"]
            rubric = request.rubrics[r_idx]

            decision = score_to_decision(score, rubric.is_ternary)
            rubric_decisions_by_answer[a_idx].append(
                RubricDecision(rubric_id=rubric.id, decision=decision)
            )

    return GradeResponse(
        question_id=request.question_id,
        results=[
            AnswerResult(
                answer_id=request.student_answers[a_idx].id,
                rubric_decisions=rubric_decisions_by_answer[a_idx],
            )
            for a_idx in range(len(request.student_answers))
        ],
    )
