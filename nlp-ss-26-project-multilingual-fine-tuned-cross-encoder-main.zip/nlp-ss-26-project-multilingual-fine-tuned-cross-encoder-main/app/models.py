from enum import Enum

from pydantic import BaseModel


class Decision(str, Enum):
    yes     = "yes"
    half    = "half"
    no      = "no"


class Rubric(BaseModel):
    id: str
    text: str
    is_ternary: bool = False


class StudentAnswer(BaseModel):
    id: str
    text: str


class GradeRequest(BaseModel):
    question_id: str
    question: str
    solution: str | None = None
    rubrics: list[Rubric]
    student_answers: list[StudentAnswer]


class RubricDecision(BaseModel):
    rubric_id: str
    decision: Decision


class AnswerResult(BaseModel):
    answer_id: str
    rubric_decisions: list[RubricDecision]


class GradeResponse(BaseModel):
    question_id: str
    results: list[AnswerResult]
