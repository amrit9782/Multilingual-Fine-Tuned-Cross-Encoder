"""Unit tests for grader.grade().

Run with:  pytest tests/test_grader.py
The service does not need to be running.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "app"))

from models import (
    AnswerResult,
    Decision,
    GradeRequest,
    GradeResponse,
    Rubric,
    RubricDecision,
    StudentAnswer,
)
from grader import grade


SAMPLE_REQUEST = GradeRequest(
    question_id="q1",
    question="What causes seasons on Earth?",
    solution="Seasons are caused by the tilt of Earth's axis.",
    rubrics=[
        Rubric(id="r1", text="Mentions the tilt of Earth's axis."),
        Rubric(id="r2", text="Does not cite distance from the Sun as the cause."),
    ],
    student_answers=[
        StudentAnswer(id="a1", text="The Earth is tilted on its axis."),
        StudentAnswer(id="a2", text="The Earth gets closer to the Sun."),
    ],
)


def test_returns_grade_response():
    result = grade(SAMPLE_REQUEST)
    assert isinstance(result, GradeResponse)


def test_question_id_preserved():
    result = grade(SAMPLE_REQUEST)
    assert result.question_id == SAMPLE_REQUEST.question_id


def test_one_result_per_answer():
    result = grade(SAMPLE_REQUEST)
    assert len(result.results) == len(SAMPLE_REQUEST.student_answers)


def test_answer_ids_preserved():
    result = grade(SAMPLE_REQUEST)
    returned_ids = [r.answer_id for r in result.results]
    expected_ids = [a.id for a in SAMPLE_REQUEST.student_answers]
    assert returned_ids == expected_ids


def test_one_decision_per_rubric():
    result = grade(SAMPLE_REQUEST)
    for answer_result in result.results:
        assert len(answer_result.rubric_decisions) == len(SAMPLE_REQUEST.rubrics)


def test_rubric_ids_preserved():
    result = grade(SAMPLE_REQUEST)
    expected_rubric_ids = [r.id for r in SAMPLE_REQUEST.rubrics]
    for answer_result in result.results:
        returned_rubric_ids = [rd.rubric_id for rd in answer_result.rubric_decisions]
        assert returned_rubric_ids == expected_rubric_ids


def test_decisions_are_valid():
    result = grade(SAMPLE_REQUEST)
    valid = set(Decision)
    for answer_result in result.results:
        for rd in answer_result.rubric_decisions:
            assert rd.decision in valid


def test_handles_missing_solution():
    request = SAMPLE_REQUEST.model_copy(update={"solution": None})
    result = grade(request)
    assert isinstance(result, GradeResponse)
    assert len(result.results) == len(request.student_answers)
