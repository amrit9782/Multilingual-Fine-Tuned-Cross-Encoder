"""Integration tests against the running service.

Requires the service to be up:
  docker compose up --build -d

Run with:  pytest tests/test_api.py
"""

import json
from pathlib import Path

import pytest
import requests

BASE_URL = "http://localhost:8000"

EXAMPLE_PAYLOAD = json.loads(
    (Path(__file__).parent.parent / "data" / "example_input.json").read_text()
)


def test_health():
    response = requests.get(f"{BASE_URL}/health", timeout=5)
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_grade_status_ok():
    response = requests.post(f"{BASE_URL}/grade", json=EXAMPLE_PAYLOAD, timeout=30)
    assert response.status_code == 200


def test_grade_returns_correct_question_id():
    response = requests.post(f"{BASE_URL}/grade", json=EXAMPLE_PAYLOAD, timeout=30)
    data = response.json()
    assert data["question_id"] == EXAMPLE_PAYLOAD["question_id"]


def test_grade_one_result_per_answer():
    response = requests.post(f"{BASE_URL}/grade", json=EXAMPLE_PAYLOAD, timeout=30)
    data = response.json()
    assert len(data["results"]) == len(EXAMPLE_PAYLOAD["student_answers"])


def test_grade_answer_ids_match():
    response = requests.post(f"{BASE_URL}/grade", json=EXAMPLE_PAYLOAD, timeout=30)
    data = response.json()
    expected = [a["id"] for a in EXAMPLE_PAYLOAD["student_answers"]]
    returned = [r["answer_id"] for r in data["results"]]
    assert returned == expected


def test_grade_one_decision_per_rubric():
    response = requests.post(f"{BASE_URL}/grade", json=EXAMPLE_PAYLOAD, timeout=30)
    data = response.json()
    for result in data["results"]:
        assert len(result["rubric_decisions"]) == len(EXAMPLE_PAYLOAD["rubrics"])


def test_grade_rubric_ids_match():
    response = requests.post(f"{BASE_URL}/grade", json=EXAMPLE_PAYLOAD, timeout=30)
    data = response.json()
    expected_rubric_ids = [r["id"] for r in EXAMPLE_PAYLOAD["rubrics"]]
    for result in data["results"]:
        returned = [rd["rubric_id"] for rd in result["rubric_decisions"]]
        assert returned == expected_rubric_ids


def test_grade_valid_decisions():
    valid = {"yes", "half", "no"}
    response = requests.post(f"{BASE_URL}/grade", json=EXAMPLE_PAYLOAD, timeout=30)
    data = response.json()
    for result in data["results"]:
        for rd in result["rubric_decisions"]:
            assert rd["decision"] in valid


def test_grade_without_solution():
    payload = {**EXAMPLE_PAYLOAD, "solution": None}
    response = requests.post(f"{BASE_URL}/grade", json=payload, timeout=30)
    assert response.status_code == 200
