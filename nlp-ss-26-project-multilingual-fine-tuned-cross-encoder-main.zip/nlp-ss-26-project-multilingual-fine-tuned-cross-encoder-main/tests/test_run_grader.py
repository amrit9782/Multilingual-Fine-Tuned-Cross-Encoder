#!/usr/bin/env python3
"""
run_grader_tests.py - Send test payloads to the grader and display results.

Usage:
    # Run all built-in JSON payloads
    python3 run_grader_tests.py

    # Run a single JSON payload
    python3 run_grader_tests.py --payload data/test_payload_nlp.json

    # Load real samples from a dataset folder (questions/answers/rubrics CSVs)
    python3 run_grader_tests.py --dataset data/NLP-SS2425
    python3 run_grader_tests.py --dataset data/WuS-WS25
    python3 run_grader_tests.py --dataset data/WuS-SS24

    # Control how many questions and answers to sample
    python3 run_grader_tests.py --dataset data/NLP-SS2425 --n_questions 3 --n_answers 4

    # Test against a different model (update .env first, then restart Docker)
    python3 run_grader_tests.py --dataset data/NLP-SS2425 --url http://localhost:8000
"""

import argparse
import json
import os
import random
import time

import pandas as pd
import requests

BASE_URL = "http://localhost:8000"

ANSWER_QUALITY = {
    "a_excellent": "EXCELLENT", "a_partial": "PARTIAL",
    "a_poor": "POOR",           "a_blank": "BLANK",
    "a_correct": "CORRECT",     "a_confused": "CONFUSED",
    "a_wrong": "WRONG",         "a_gut": "GUT (DE)",
    "a_teilweise": "TEILWEISE", "a_falsch": "FALSCH (DE)",
}


# =============================================================================
# LOAD FROM CSV DATASET
# =============================================================================
def load_dataset_payload(dataset_dir, n_questions=2, n_answers=3, seed=42):
    """
    Build a /grade payload from real training CSV files.

    Picks n_questions random questions, then for each question picks
    n_answers random student answers and up to 5 rubrics.

    Returns a list of payloads (one per question).
    """
    rng = random.Random(seed)

    q_path  = os.path.join(dataset_dir, "questions.csv")
    a_path  = os.path.join(dataset_dir, "answers.csv")
    r_path  = os.path.join(dataset_dir, "rubrics.csv")
    ar_path = os.path.join(dataset_dir, "answer_rubrics.csv")

    for p in [q_path, a_path, r_path, ar_path]:
        if not os.path.exists(p):
            raise FileNotFoundError(f"Missing: {p}")

    q  = pd.read_csv(q_path)
    a  = pd.read_csv(a_path)
    r  = pd.read_csv(r_path)
    ar = pd.read_csv(ar_path)

    if "is_ternary" not in r.columns:
        r["is_ternary"] = True

    # Pick random questions that have enough answers
    question_ids = a.groupby("question_id").filter(
        lambda x: len(x) >= n_answers
    )["question_id"].unique().tolist()

    if not question_ids:
        question_ids = a["question_id"].unique().tolist()

    chosen_qids = rng.sample(question_ids, min(n_questions, len(question_ids)))

    payloads = []
    for qid in chosen_qids:
        q_row = q[q["question_id"] == qid]
        if q_row.empty:
            continue

        question_text  = str(q_row["question"].iloc[0])
        solution_text  = str(q_row["solution"].iloc[0]) if "solution" in q_row else None

        # Sample answers for this question
        a_rows = a[a["question_id"] == qid]
        chosen_aids = rng.sample(a_rows["answer_id"].tolist(),
                                 min(n_answers, len(a_rows)))

        # Get rubrics for this question (up to 5)
        r_rows = r[r["question_id"] == qid].head(5)
        if r_rows.empty:
            continue

        rubrics = [
            {
                "id": str(row["rubric_id"]),
                "text": str(row["rubric"]),
                "is_ternary": bool(row["is_ternary"]),
            }
            for _, row in r_rows.iterrows()
        ]

        student_answers = []
        ground_truth = {}
        for aid in chosen_aids:
            a_row = a_rows[a_rows["answer_id"] == aid]
            if a_row.empty:
                continue
            student_answers.append({
                "id": str(aid),
                "text": str(a_row["answer"].iloc[0]),
            })
            # Collect gold labels from answer_rubrics
            for _, r_row in r_rows.iterrows():
                ar_match = ar[
                    (ar["question_id"] == qid) &
                    (ar["answer_id"] == aid) &
                    (ar["rubric_id"] == r_row["rubric_id"])
                ]
                if not ar_match.empty:
                    label = ar_match["label"].iloc[0]
                    gold = ("yes" if label == 1.0
                            else "no" if label == 0.0
                            else "half")
                    ground_truth[(str(aid), str(r_row["rubric_id"]))] = gold

        if not student_answers:
            continue

        payloads.append({
            "payload": {
                "question_id": str(qid),
                "question": question_text,
                "solution": solution_text,
                "rubrics": rubrics,
                "student_answers": student_answers,
            },
            "ground_truth": ground_truth,
            "dataset": os.path.basename(dataset_dir),
        })

    return payloads


# =============================================================================
# RUN A SINGLE PAYLOAD
# =============================================================================
def run_payload(payload, base_url, ground_truth=None, dataset_name=None):
    """Send one payload and print formatted results."""
    source = dataset_name or "JSON file"
    print(f"\n{'=' * 75}")
    print(f"  SOURCE:   {source}")
    print(f"  QUESTION: {payload['question'][:75]}...")
    print(f"  Rubrics:  {len(payload['rubrics'])}  |  "
          f"Answers: {len(payload['student_answers'])}")
    print(f"{'=' * 75}")

    print("\n  Rubrics:")
    for r in payload["rubrics"]:
        tag = "[ternary]" if r.get("is_ternary") else "[binary] "
        print(f"    {str(r['id']):>6}  {tag}  {r['text'][:65]}")

    t0 = time.time()
    try:
        resp = requests.post(f"{base_url}/grade", json=payload, timeout=120)
        elapsed = time.time() - t0
        resp.raise_for_status()
    except requests.exceptions.ConnectionError:
        print(f"\n  ERROR: Cannot connect to {base_url}.")
        print(f"         Run: docker compose up --build -d")
        return
    except Exception as e:
        print(f"\n  ERROR: {e}")
        return

    result = resp.json()
    rubric_ids = [r["id"] for r in payload["rubrics"]]
    answer_map = {a["id"]: a["text"][:30] for a in payload["student_answers"]}

    has_gt = bool(ground_truth)
    col_w  = 10

    print(f"\n  Results (response time: {elapsed:.2f}s):\n")
    header = f"  {'Answer ID':<22} " + " ".join(f"{rid:>{col_w}}" for rid in rubric_ids)
    print(header)
    if has_gt:
        gt_header = f"  {'Gold label':^22} " + " ".join(f"{'gold':>{col_w}}" for _ in rubric_ids)
        print(gt_header)
    print(f"  {'-' * (22 + (col_w + 1) * len(rubric_ids))}")

    correct = total = 0
    for answer_result in result["results"]:
        aid = answer_result["answer_id"]
        display = ANSWER_QUALITY.get(aid, f"{aid[:10]}:{answer_map.get(aid,'')[:10]}")
        decisions = {rd["rubric_id"]: rd["decision"]
                     for rd in answer_result["rubric_decisions"]}

        pred_row = f"  {display:<22} " + " ".join(
            f"{decisions.get(rid,'?'):>{col_w}}" for rid in rubric_ids
        )
        print(pred_row)

        if has_gt:
            gt_row = f"  {'':22} "
            for rid in rubric_ids:
                gold = ground_truth.get((str(aid), str(rid)), "?")
                pred = decisions.get(rid, "?")
                if gold != "?":
                    total += 1
                    if pred == gold:
                        correct += 1
                        cell = f"{'OK':>{col_w}}"
                    else:
                        cell = f"{'WRONG':>{col_w}}"
                else:
                    cell = f"{'?':>{col_w}}"
                gt_row += cell + " "
            print(gt_row)

    # Sanity check
    print(f"\n  Sanity check (rubrics satisfied per answer):")
    for answer_result in result["results"]:
        aid = answer_result["answer_id"]
        display = ANSWER_QUALITY.get(aid, aid[:20])
        yes_count = sum(1 for rd in answer_result["rubric_decisions"]
                        if rd["decision"] == "yes")
        total_r = len(answer_result["rubric_decisions"])
        print(f"    {display:<22} -> {yes_count}/{total_r} rubrics satisfied")

    n_pairs = len(payload["rubrics"]) * len(payload["student_answers"])
    print(f"\n  Timing: {elapsed:.2f}s total | {n_pairs} pairs | "
          f"{elapsed/n_pairs:.2f}s per pair")

    if has_gt and total > 0:
        print(f"  Accuracy vs gold labels: {correct}/{total} "
              f"({100*correct/total:.0f}%)")


# =============================================================================
# MAIN
# =============================================================================
def main():
    parser = argparse.ArgumentParser(
        description="Test grader with JSON payloads or real dataset CSVs"
    )
    parser.add_argument("--url", default=BASE_URL,
                        help="Grader URL (default: http://localhost:8000)")
    parser.add_argument("--payload", default=None,
                        help="Path to a single JSON payload file")
    parser.add_argument("--dataset", default=None, nargs="+",
                        help="One or more dataset folders with questions/answers/rubrics CSVs")
    parser.add_argument("--n_questions", type=int, default=2,
                        help="Number of questions to sample from dataset (default: 2)")
    parser.add_argument("--n_answers", type=int, default=3,
                        help="Number of answers per question (default: 3)")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for sampling (default: 42)")
    args = parser.parse_args()

    # Health check
    print(f"Checking {args.url}/health...")
    try:
        resp = requests.get(f"{args.url}/health", timeout=10)
        print(f"  Service: {resp.json()}\n")
    except Exception as e:
        print(f"  ERROR: {e}")
        print(f"  Start Docker first: docker compose up --build -d\n")
        return

    if args.dataset:
        for dataset_dir in args.dataset:
            print(f"\nLoading real samples from: {dataset_dir}")
            try:
                payloads = load_dataset_payload(
                    dataset_dir,
                    n_questions=args.n_questions,
                    n_answers=args.n_answers,
                    seed=args.seed,
                )
            except FileNotFoundError as e:
                print(f"  ERROR: {e}")
                continue

            print(f"  Loaded {len(payloads)} question(s) from "
                  f"{os.path.basename(dataset_dir)}")

            for item in payloads:
                run_payload(
                    item["payload"],
                    args.url,
                    ground_truth=item["ground_truth"],
                    dataset_name=item["dataset"],
                )

    elif args.payload:
        # Single JSON file
        with open(args.payload) as f:
            payload = json.load(f)
        run_payload(payload, args.url,
                    dataset_name=os.path.basename(args.payload))

    else:
        # All built-in JSON payloads
        for path in [
            "data/example_input.json",
            "data/test_payload_nlp.json",
            "data/test_payload_word2vec.json",
            "data/test_payload_german.json",
        ]:
            if os.path.exists(path):
                with open(path) as f:
                    payload = json.load(f)
                run_payload(payload, args.url,
                            dataset_name=os.path.basename(path))
            else:
                print(f"\n  SKIP: {path} not found")

    print(f"\n{'=' * 75}")
    print("  Done.")
    print(f"{'=' * 75}\n")


if __name__ == "__main__":
    main()