#!/usr/bin/env python3
"""
evaluate_grader.py - Compute RMSE and accuracy on full dataset(s).

Sends every question from the dataset(s) to the running grader service,
collects predictions, compares against gold labels, and reports RMSE
and accuracy per dataset and overall.

Decision to score mapping:
    yes  -> 1.0
    half -> 0.5
    no   -> 0.0

RMSE   = sqrt(mean((predicted_score - gold_label)^2))
Accuracy = mean(predicted_label == gold_label)  (exact match)

Usage:
    # Evaluate on one dataset
    python3 tests/evaluate_grader.py --dataset data/NLP-SS2425

    # Evaluate on all datasets
    python3 tests/evaluate_grader.py \
        --dataset data/NLP-SS2425 data/WuS-WS25 data/DAV-SS2425 data/WuS-SS24

    # Limit answers per question (faster, good for quick checks)
    python3 tests/evaluate_grader.py --dataset data/NLP-SS2425 --max_answers 5

    # Save results to CSV
    python3 tests/evaluate_grader.py --dataset data/NLP-SS2425 --output results/eval_results.csv

NOTE: Full evaluation on all datasets takes 20-40 minutes on CPU.
      Use --max_answers to get a quick estimate first.
"""

import argparse
import os
import sys
import time

import numpy as np
import pandas as pd
import requests

BASE_URL = "http://localhost:8000"

DECISION_TO_SCORE = {"yes": 1.0, "half": 0.5, "no": 0.0}


# =============================================================================
# DATA LOADING
# =============================================================================
def load_full_dataset(dataset_dir):
    q  = pd.read_csv(os.path.join(dataset_dir, "questions.csv"))
    a  = pd.read_csv(os.path.join(dataset_dir, "answers.csv"))
    r  = pd.read_csv(os.path.join(dataset_dir, "rubrics.csv"))
    ar = pd.read_csv(os.path.join(dataset_dir, "answer_rubrics.csv"))

    # Convert all IDs to strings to match what the grader returns
    for frame in [q, a, r, ar]:
        for col in ["question_id", "answer_id", "rubric_id"]:
            if col in frame.columns:
                frame[col] = frame[col].astype(str)

    if "is_ternary" not in r.columns:
        r["is_ternary"] = True

    merged = ar.merge(
        a[["question_id", "answer_id", "answer"]], on=["question_id", "answer_id"]
    ).merge(
        r[["question_id", "rubric_id", "rubric", "is_ternary"]], on=["question_id", "rubric_id"]
    ).merge(
        q[["question_id", "question"]], on="question_id"
    )

    return merged


# =============================================================================
# EVALUATION
# =============================================================================
def evaluate_dataset(dataset_dir, base_url, max_answers=None):
    """
    Send all questions from a dataset to the grader and compute metrics.

    Returns a dict with RMSE, accuracy, and per-row predictions.
    """
    name = os.path.basename(dataset_dir)
    print(f"\n{'=' * 65}")
    print(f"  Dataset: {name}")
    print(f"  Loading data...")

    df = load_full_dataset(dataset_dir)
    total_pairs = len(df)
    n_questions = df["question_id"].nunique()
    n_answers = df["answer_id"].nunique()

    print(f"  {total_pairs} pairs | {n_questions} questions | {n_answers} answers")
    if max_answers:
        print(f"  Limiting to {max_answers} answers per question")

    gold_labels = []
    pred_scores = []
    rows_log = []

    t_start = time.time()
    q_done = 0

    for qid, q_group in df.groupby("question_id"):
        question_text = q_group["question"].iloc[0]
        rubric_ids = q_group["rubric_id"].unique()
        answer_ids = q_group["answer_id"].unique()

        if max_answers:
            answer_ids = answer_ids[:max_answers]

        rubrics = []
        seen_rids = set()
        for _, row in q_group.iterrows():
            if row["rubric_id"] not in seen_rids:
                rubrics.append({
                    "id": str(row["rubric_id"]),
                    "text": str(row["rubric"]),
                    "is_ternary": bool(row["is_ternary"]),
                })
                seen_rids.add(row["rubric_id"])

        student_answers = []
        for aid in answer_ids:
            a_row = q_group[q_group["answer_id"] == aid]
            if a_row.empty:
                continue
            student_answers.append({
                "id": str(aid),
                "text": str(a_row["answer"].iloc[0]),
            })

        if not student_answers:
            continue

        payload = {
            "question_id": str(qid),
            "question": question_text,
            "solution": None,
            "rubrics": rubrics,
            "student_answers": student_answers,
        }

        try:
            resp = requests.post(f"{base_url}/grade", json=payload, timeout=300)
            resp.raise_for_status()
        except Exception as e:
            print(f"\n  ERROR on question {qid}: {e}")
            continue

        result = resp.json()

        # Collect predictions vs gold labels
        for answer_result in result["results"]:
            aid = answer_result["answer_id"]
            decisions = {rd["rubric_id"]: rd["decision"]
                         for rd in answer_result["rubric_decisions"]}

            for rid, decision in decisions.items():
                pred = DECISION_TO_SCORE.get(decision, 0.0)

                # Gold label
                gold_rows = q_group[
                    (q_group["answer_id"] == aid) &
                    (q_group["rubric_id"] == rid)
                ]
                if gold_rows.empty:
                    continue
                gold = float(gold_rows["label"].iloc[0])

                gold_labels.append(gold)
                pred_scores.append(pred)
                rows_log.append({
                    "question_id": str(qid),
                    "answer_id": str(aid),
                    "rubric_id": str(rid),
                    "gold": gold,
                    "pred": pred,
                    "correct": int(pred == gold),
                    "is_ternary": bool(q_group[q_group["rubric_id"]==rid]["is_ternary"].iloc[0]),
                })

        q_done += 1
        elapsed = time.time() - t_start
        rate = q_done / elapsed
        remaining = (n_questions - q_done) / rate if rate > 0 else 0
        print(f"  [{q_done:>3}/{n_questions}] {question_text[:50]:<50} "
              f"| {elapsed:.0f}s elapsed, ~{remaining:.0f}s remaining",
              end="\r", flush=True)

    print()  # newline after progress

    if not gold_labels:
        print(f"  No predictions collected.")
        return None

    gold_arr = np.array(gold_labels)
    pred_arr = np.array(pred_scores)

    rmse = float(np.sqrt(np.mean((pred_arr - gold_arr) ** 2)))
    accuracy = float(np.mean(pred_arr == gold_arr))

    # Per-type breakdown
    df_log = pd.DataFrame(rows_log)
    binary_mask  = ~df_log["is_ternary"]
    ternary_mask =  df_log["is_ternary"]

    print(f"\n  Results for {name}:")
    print(f"  {'Metric':<30} {'Value':>10}")
    print(f"  {'-' * 42}")
    print(f"  {'Total pairs evaluated':<30} {len(gold_labels):>10}")
    print(f"  {'RMSE (all)':<30} {rmse:>10.4f}")
    print(f"  {'Accuracy (all)':<30} {accuracy*100:>9.1f}%")

    if binary_mask.sum() > 0:
        b_rmse = float(np.sqrt(np.mean(
            (df_log[binary_mask]["pred"] - df_log[binary_mask]["gold"]) ** 2
        )))
        b_acc = float(df_log[binary_mask]["correct"].mean())
        print(f"  {'RMSE (binary rubrics)':<30} {b_rmse:>10.4f}  (n={binary_mask.sum()})")
        print(f"  {'Accuracy (binary rubrics)':<30} {b_acc*100:>9.1f}%")

    if ternary_mask.sum() > 0:
        t_rmse = float(np.sqrt(np.mean(
            (df_log[ternary_mask]["pred"] - df_log[ternary_mask]["gold"]) ** 2
        )))
        t_acc = float(df_log[ternary_mask]["correct"].mean())
        print(f"  {'RMSE (ternary rubrics)':<30} {t_rmse:>10.4f}  (n={ternary_mask.sum()})")
        print(f"  {'Accuracy (ternary rubrics)':<30} {t_acc*100:>9.1f}%")

    # Per-label breakdown
    print(f"\n  Per gold-label accuracy:")
    for lbl in [0.0, 0.5, 1.0]:
        mask = gold_arr == lbl
        if mask.sum() > 0:
            lbl_acc = float(np.mean(pred_arr[mask] == lbl))
            name_str = {0.0: "no  (label=0.0)", 0.5: "half(label=0.5)", 1.0: "yes (label=1.0)"}[lbl]
            print(f"    {name_str}: {lbl_acc*100:>5.1f}%  (n={mask.sum()})")

    total_time = time.time() - t_start
    print(f"\n  Time: {total_time:.0f}s total | "
          f"{total_time/len(gold_labels):.2f}s per pair")

    return {
        "dataset": name,
        "n_pairs": len(gold_labels),
        "rmse": rmse,
        "accuracy": accuracy,
        "rows": rows_log,
    }


# =============================================================================
# MAIN
# =============================================================================
def main():
    parser = argparse.ArgumentParser(
        description="Evaluate grader RMSE and accuracy on full datasets"
    )
    parser.add_argument("--dataset", nargs="+", required=True,
                        help="One or more dataset folders to evaluate")
    parser.add_argument("--url", default=BASE_URL,
                        help="Grader URL (default: http://localhost:8000)")
    parser.add_argument("--max_answers", type=int, default=None,
                        help="Max answers per question (default: all). "
                             "Use 5-10 for a quick estimate.")
    parser.add_argument("--output", type=str, default=None,
                        help="Save per-row predictions to this CSV file")
    args = parser.parse_args()

    # Health check
    print(f"Checking {args.url}/health...")
    try:
        resp = requests.get(f"{args.url}/health", timeout=10)
        print(f"  Service: {resp.json()}")
    except Exception as e:
        print(f"  ERROR: {e}")
        print(f"  Start Docker first: docker compose up --build -d")
        sys.exit(1)

    # Estimate time
    if not args.max_answers:
        print(f"\n  NOTE: Full evaluation takes 20-40 min on CPU.")
        print(f"  For a quick estimate use: --max_answers 5")

    all_results = []
    all_rows = []

    for dataset_dir in args.dataset:
        if not os.path.exists(dataset_dir):
            print(f"\n  SKIP: {dataset_dir} not found")
            continue
        result = evaluate_dataset(dataset_dir, args.url, args.max_answers)
        if result:
            all_results.append(result)
            all_rows.extend(result.pop("rows"))

    # Overall summary
    if len(all_results) > 1:
        print(f"\n{'=' * 65}")
        print(f"  OVERALL SUMMARY")
        print(f"{'=' * 65}")
        print(f"  {'Dataset':<20} {'Pairs':>8} {'RMSE':>8} {'Accuracy':>10}")
        print(f"  {'-' * 50}")

        all_gold = []
        all_pred = []
        for r in all_results:
            print(f"  {r['dataset']:<20} {r['n_pairs']:>8} "
                  f"{r['rmse']:>8.4f} {r['accuracy']*100:>9.1f}%")

        df_all = pd.DataFrame(all_rows)
        mean_rmse = float(np.sqrt(np.mean((df_all["pred"] - df_all["gold"]) ** 2)))
        mean_acc  = float(df_all["correct"].mean())
        total_n   = len(df_all)

        print(f"  {'-' * 50}")
        print(f"  {'OVERALL':<20} {total_n:>8} {mean_rmse:>8.4f} {mean_acc*100:>9.1f}%")
        print(f"\n  Reference (5-fold CV on same data):")
        print(f"    v10 type-aware:  RMSE=0.2549  Acc=80.3%")
        print(f"    v8 best:         RMSE=0.2614  Acc=79.9%")

    # Save to CSV
    if args.output and all_rows:
        os.makedirs(os.path.dirname(args.output) or ".", exist_ok=True)
        pd.DataFrame(all_rows).to_csv(args.output, index=False)
        print(f"\n  Saved {len(all_rows)} rows to {args.output}")

    print(f"\n{'=' * 65}")
    print("  Evaluation complete.")
    print(f"{'=' * 65}\n")


if __name__ == "__main__":
    main()