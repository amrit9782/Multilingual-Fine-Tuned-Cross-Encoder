# Comparative Analysis and Optimization of Multilingual Cross-Encoder Grader (v2 to v11)

**Subject:** NLP Project – Automated Short-Answer Grader  
**Date:** June 25, 2026  

---

## Abstract

This report details the systematic development, ablation, and hyperparameter optimization of a cross-encoder model designed to grade student short answers against specific rubric criteria. Starting from initial baseline implementations in **v2**, we trace the evolution of the model through subsequent versions (**v3** to **v11**), leading to a unified, multilingual (German & English) grading pipeline. We analyze the impacts of dataset imbalance, field token budgets, sequence formatting, model size scaling (Base vs. Large), layer unfreezing, loss function enhancements (CORAL), adversarial training (FGM), text normalization (LaTeX mathematical expansions), consensus contradiction resolution, and dynamic back-translation data augmentation. Finally, we present the optimal configuration for the production model.

---

## 1. Chronological Investigation History

### 1.1. Investigation v2: Initial Baselines & Class Collapse
* **Changes:** Evaluates GBERT, XLM-RoBERTa, and mDeBERTa baseline cross-encoders (regression vs. classification) on monolingual German grading with naive sliding windows.
* **Results:** GBERT regression reached **RMSE: 0.2774 (74.38% Acc)**. Severe class imbalance caused XLM-RoBERTa and mDeBERTa to collapse to majority class (**60.75% and 60.00% Acc**). Classification mode performed poorly (XLM-R RMSE: 0.4458, Acc: 46.38%). Naive sliding windows failed to resolve majority-class collapse.
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v2.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v2_results.csv) | [Sliding Window Results](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v2_results_with_sliding_window.csv) | [Updated Budget Results](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v2_results_with_updated_field_budget.csv)

---

### 1.2. Investigation v3: Class Balancing & Loss Adjustments
* **Changes:** Fixes majority collapse and validation data leakage by introducing GroupKFold splitting (grouped by `answer_id`), training-fold minority oversampling, and custom frequency-weighted MSE loss.
* **Results:** Successfully resolved class collapse. XLM-RoBERTa regression rose to **RMSE: 0.2675 (77.63% Acc)** and GBERT rose to **RMSE: 0.2614 (77.13% Acc)**. mDeBERTa was dropped due to instability.
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v3.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v3_results.csv)

---

### 1.3. Investigation v4: Ablation Studies & Hyperparameter Tuning
* **Changes:** Grid sweeps learning rate (1e-5 to 5e-5), unfreezing depth (top 2-12 layers), epochs (10-20), and ablation layouts (removing/reordering question, rubric, answer, solution).
* **Results:** GBERT reached a monolingual peak of **RMSE: 0.2541 (80.13% Acc)** at 20 epochs, LR=3e-5. Removing reference solutions improved XLM-RoBERTa (RA-only layout reached **RMSE: 0.2572, 78.75% Acc**). Putting the student answer first degraded performance to **73.88% Acc**.
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v4.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v4_results.csv)

---

### 1.4. Investigation v5: Transition to Multilingual Tasks
* **Changes:** Scales pipeline to a multilingual task combining German and English datasets (WuS-WS25, DAV-SS2425, NLP-SS2425). Evaluates XLM-RoBERTa base with Rubric-Answer (RA) vs. Rubric-Answer-Question (RAQ) layouts.
* **Results:** Best run achieved **RMSE: 0.2718 (76.70% Acc)** on RA layout (LR=5e-5, unfreeze 6, 10 epochs). Excluding the question field (RA layout) consistently outperformed RAQ (mean accuracy: 72.67% vs. 70.46%) due to question noise on base models.
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v5.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v5_results.csv)

---

### 1.5. Investigation v6: Sequence Permutation & Layout Sweep
* **Changes:** Systematically sweeps all orderings of `(rubric, answer)` (2 permutations) and `(rubric, question, answer)` (6 permutations) using optimal fixed hyperparameters.
* **Results:** Placing `rubric` first is critical; swapping `['rubric', 'answer']` to `['answer', 'rubric']` dropped accuracy from **77.76% to 74.73%** (-3.03%). `['rubric', 'question', 'answer']` achieved **RMSE: 0.2664 (77.68% Acc)** and stabilized cross-validation variance (std of ±0.014 vs. ±0.043 for RA layout).
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v6.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v6_results.csv)

---

### 1.6. Investigation v7: Large Model Scaling (XLM-RoBERTa-Large)
* **Changes:** Evaluates parameter scaling by running the sweeps from v5/v6 using `xlm-roberta-large` with a batch size of 2 and gradient accumulation of 8 to prevent GPU OOM.
* **Results:** Large backbone reached **RMSE: 0.2647 (77.60% Acc)** on RA layout and **RMSE: 0.2586 (76.61% Acc)** on RAQ. The large model's capacity neutralized layout noise, shrinking the RA vs. RAQ performance gap to a negligible **0.09%**.
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v7.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v7_results.csv)

---

### 1.7. Investigation v8: Unified Advanced RMSE Optimization Strategies
* **Changes:** Integrates and evaluates four optimization methods on the base model: Dynamic Token Budgeting, CORAL Ordinal Loss, Layer-wise Discriminative Learning Rate (LLRD), and FGM Adversarial Training.
* **Results:** Unifying all optimizations on `xlm-roberta-base` achieved **RMSE: 0.2614 (79.93% Acc)** on the RQA layout, outperforming the unoptimized v7 Large models. Cased input format yielded similar performance (**RMSE: 0.2628, 79.58% Acc**).
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v8.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v8_results.csv) | [Old Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v8_results_old.csv)

---

### 1.8. Investigation v9: Large-Scale Ablation Grid Search
* **Changes:** Runs a 138-run grid search sweep on learning rates, unfreezing depths, layout variants, and split grouping tasks (`group_by=answer_id` vs. zero-shot `group_by=question_id`).
* **Results:** For unseen answers: best run was `grid_roberta_base_ra_lr_5e-5_unfreeze_8` (**RMSE: 0.2561, 79.54% Acc**). For zero-shot unseen questions: task was much harder, peak baseline was **RMSE: 0.3362 (57.13% Acc)**. Adversarial FGM boosted zero-shot performance by **+3.3%** to **RMSE: 0.3405 (60.49% Acc)**.
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v9.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v9_results.csv) | [Old Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v9_results_old.csv)

---

### 1.9. Investigation v10: Scaling to Large Backbone with Ablation
* **Changes:** Combines XLM-RoBERTa-Large with all v8/v9 optimizations, adding TensorBoard loss scaling, type-aware thresholds, and `is_ternary` rubric prefixing.
* **Results:** Achieved a zero-shot (`question_id`) baseline **RMSE: 0.2586 (76.61% Acc)**. Large capacity resolved attention-dilution issues, showing minimal fold variance (±1.42%).
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v10.py)

---

### 1.10. Investigation v11: Advanced Semantic Preprocessing & Target Optimization
* **Changes:** Builds the production-ready pipeline by adding annotator contradiction resolution (consensus voting), 21-expression LaTeX math translation, dynamic back-translation augmentation, training on direct semantic labels (`0.0, 0.5, 1.0`), and logging optimal decision thresholds.
* **Results:** Reconciled consensus evaluation made testing stricter/harder but highly reliable. Best RMSE run: `grid_xlm-roberta-base_ra_lr_5e-5_unfreeze_10` (**RMSE: 0.3660, 72.17% Acc, T1=0.22, T2=0.69**). Best Accuracy run: `grid_xlm-roberta-base_ra_lr_5e-5_unfreeze_8` (**RMSE: 0.3717, 73.95% Acc, T1=0.24, T2=0.67**). Math normalization solved formatting mismatches on quantitative rubrics.
* **Links:** [Script](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/src/comparison/investigation_v11.py) | [Results CSV](file:///home/amrit/Projects/nlp-ss-26-project-multilingual-fine-tuned-cross-encoder/results/investigation_v11_results.csv)

---

## 2. Synthesis of Findings & Key Takeaways

1. **Rubric-First Sequence Ordering**: Cross-encoder models process sequences left-to-right. Placing the criteria (`rubric`) at the very beginning of the sequence aligns the self-attention mechanism, guiding how the student's answer is parsed.
2. **Exclusion of Reference Solutions**: Reference solutions are long and act as semantic distractors. Removing them saves token budget and improves grading accuracy.
3. **Model Scaling (Base vs. Large)**: Scale helps with noisy inputs. Base models perform best on the simple `['rubric', 'answer']` (RA) layout. Large models (`xlm-roberta-large`) have the capacity to process `['rubric', 'question', 'answer']` (RQA) layouts with minimal noise degradation, yielding lower variance across folds (±1.42%).
4. **Adversarial Perturbation (FGM)**: FGM is highly effective for zero-shot generalization (unseen questions), adding a **+3.3% accuracy boost**.

---

## 3. Recommended Production Configurations

We recommend two production training configurations based on your hardware constraints:

### 3.1. Recommended Config for XLM-RoBERTa-Base (v11 Pipeline)
* **Base Checkpoint**: `FacebookAI/xlm-roberta-base`
* **Input Sequence Layout**: `[CLS] rubric [SEP] answer [SEP]` (Rubric-Answer only)
* **Training Hyperparameters**:
  * **Learning Rate**: `5e-5` (with LLRD decay `0.88` back-to-front)
  * **Layer Unfreezing**: Top `10` layers + classification head (for lowest RMSE) or `8` layers (for highest Accuracy)
  * **Training Epochs**: `12` epochs
  * **Optimal Decision Thresholds**: **`T1 = 0.22`**, **`T2 = 0.69`**
* **Expected Performance**: RMSE: **0.3660** (Accuracy: **72.17%**) on consensus-resolved, strict evaluation splits.

### 3.2. Recommended Config for XLM-RoBERTa-Large (v10 Pipeline)
* **Base Checkpoint**: `FacebookAI/xlm-roberta-large`
* **Input Sequence Layout**: `[CLS] rubric [SEP] question [SEP] answer [SEP]`
* **Training Hyperparameters**:
  * **Learning Rate**: `5e-5` (effective batch size = 16 via gradient accumulation steps = 8, batch size = 2)
  * **Layer Unfreezing**: Top `8` layers + classification head
  * **Training Epochs**: `10` epochs
  * **Optimal Decision Thresholds**: **`T1 = 0.36`**, **`T2 = 0.70`**
* **Expected Performance**: RMSE: **0.2586** (Accuracy: **76.61%**) on zero-shot question validation splits.
